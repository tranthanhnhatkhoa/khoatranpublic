#!/bin/bash

# Script to create a zip archive of the soccerdata project
# Excludes __pycache__, docs, .github, .pytest_cache, and tests folders

echo "Creating soccerdata project zip archive..."

# Create zip with exclusions
zip -r soccerdata_project.zip . \
    -x "*/__pycache__/*" \
    -x "docs/*" \
    -x ".github/*" \
    -x ".pytest_cache/*" \
    -x "tests/*"

echo "Zip archive created: soccerdata_project.zip"
echo "Size: $(du -h soccerdata_project.zip | cut -f1)" 