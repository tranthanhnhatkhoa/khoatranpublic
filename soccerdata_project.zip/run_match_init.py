from soccerdata.database.connection import get_session
from soccerdata.datasource_etl.match_etl import MatchETL

match_id = 3424
print('[DEBUG] About to call MatchETL.match_init', flush=True)
with get_session() as session:
    MatchETL.match_init(session, match_id)
print('[DEBUG] Returned from MatchETL.match_init', flush=True) 