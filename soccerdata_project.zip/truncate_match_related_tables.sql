-- Truncate only match-related tables for test resets
TRUNCATE TABLE match_player CASCADE;
TRUNCATE TABLE match_player_stats CASCADE;
TRUNCATE TABLE match_stats CASCADE;
TRUNCATE TABLE match_team_stats CASCADE;
TRUNCATE TABLE player_unavailability CASCADE; 