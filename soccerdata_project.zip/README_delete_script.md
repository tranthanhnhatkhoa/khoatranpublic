# Team and Match Data DELETION Script (Hard Delete)

This script provides a way to **PERMANENTLY DELETE** data from team-related and match-related tables in the soccerdata database.

**WARNING: This script performs a HARD DELETE. Once data is deleted, it CANNOT BE RECOVERED.**

## Features

- **Hard Delete**: Permanently removes records from the database
- **Foreign Key Handling**: Deletes data in the correct order to respect foreign key relationships
- **Flexible Deletion**: Can delete all data or specific league/season data
- **Safety Confirmation**: Requires user confirmation before deletion (unless `--force` is used)
- **Detailed Reporting**: Shows record counts before and after deletion

## Usage

### Delete All Team and Match Data

```bash
# With confirmation prompt (RECOMMENDED)
poetry run python delete_team_match_data.py --all

# Skip confirmation prompt (USE WITH CAUTION)
poetry run python delete_team_match_data.py --all --force
```

### Delete Specific League/Season Data

```bash
# Delete data for League ID 1, Season ID 1
poetry run python delete_team_match_data.py --league-id 1 --season-id 1

# Skip confirmation prompt
poetry run python delete_team_match_data.py --league-id 1 --season-id 1 --force
```

## Tables Affected

The script deletes data from the following tables in order:

### Match-Related Tables (deleted first)
1. `match_player_stats` - Player statistics per match
2. `match_team_stats` - Team statistics per match  
3. `match_stats` - General match statistics
4. `match_mapping` - External match ID mappings
5. `match` - Match records

### Team-Related Tables (deleted second)
6. `team_standing` - Team standings in leagues/seasons
7. `team_stats` - Team-level statistics
8. `team_mapping` - External team ID mappings
9. `team` - Team records

## Safety Features

- **Transaction Safety**: Uses database transactions with rollback on errors
- **Confirmation Required**: User must confirm deletion unless `--force` flag is used
- **Detailed Logging**: Shows exactly what was deleted and how many records

## Example Output

```
WARNING: This will PERMANENTLY DELETE ALL data from the following tables:
  - match_player_stats
  - match_team_stats
  - match_stats
  - match_mapping
  - match
  - team_standing
  - team_stats
  - team_mapping
  - team

THIS ACTION CANNOT BE UNDONE AND DATA CANNOT BE RECOVERED.

Are you sure you want to proceed? (yes/no): yes

Starting HARD DELETION process...
==================================================
✓ No records to delete from match_player_stats
✓ No records to delete from match_team_stats
✓ No records to delete from match_stats
Deleting 380 records from match_mapping...
✓ Permanently deleted 380 records from match_mapping
Deleting 380 records from match...
✓ Permanently deleted 380 records from match
✓ No records to delete from team_standing
✓ No records to delete from team_stats
Deleting 20 records from team_mapping...
✓ Permanently deleted 20 records from team_mapping
Deleting 20 records from team...
✓ Permanently deleted 20 records from team

==================================================
Deletion completed successfully!
Total records permanently deleted: 800
```

## Command Line Options

- `--all`: Delete all team and match data
- `--league-id`: League ID to delete data for (use with `--season-id`)
- `--season-id`: Season ID to delete data for (use with `--league-id`)
- `--force`: Skip confirmation prompts

## Notes
- **This script performs a hard delete. Data cannot be recovered.**
- All operations are wrapped in database transactions for safety. If any step fails, the entire transaction is rolled back. 