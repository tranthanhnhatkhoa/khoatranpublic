-- Disable triggers to avoid FK issues
ALTER TABLE match_player_stats DISABLE TRIGGER ALL;
ALTER TABLE match_player DISABLE TRIGGER ALL;
ALTER TABLE match_team_stats DISABLE TRIGGER ALL;
ALTER TABLE match_stats DISABLE TRIGGER ALL;
ALTER TABLE player_stats DISABLE TRIGGER ALL;
ALTER TABLE team_player DISABLE TRIGGER ALL;
ALTER TABLE player_mapping DISABLE TRIGGER ALL;
ALTER TABLE player DISABLE TRIGGER ALL;
ALTER TABLE team DISABLE TRIGGER ALL;
ALTER TABLE match DISABLE TRIGGER ALL;
-- Add team_xxx and player_xxx tables
ALTER TABLE team_standing DISABLE TRIGGER ALL;
ALTER TABLE team_mapping DISABLE TRIGGER ALL;
ALTER TABLE player_mapping DISABLE TRIGGER ALL;
ALTER TABLE player_stats DISABLE TRIGGER ALL;

-- Truncate and delete from tables
TRUNCATE TABLE match_player_stats CASCADE;
TRUNCATE TABLE match_player CASCADE;
TRUNCATE TABLE match_team_stats CASCADE;
TRUNCATE TABLE match_stats CASCADE;
TRUNCATE TABLE player_stats CASCADE;
TRUNCATE TABLE team_player CASCADE;
TRUNCATE TABLE player_mapping CASCADE;
TRUNCATE TABLE player CASCADE;
TRUNCATE TABLE team CASCADE;
TRUNCATE TABLE match CASCADE;
-- Delete from team_xxx and player_xxx tables
DELETE FROM team_standing;
DELETE FROM team_mapping;
DELETE FROM player_mapping;
DELETE FROM player_stats;

-- Re-enable triggers
ALTER TABLE match_player_stats ENABLE TRIGGER ALL;
ALTER TABLE match_player ENABLE TRIGGER ALL;
ALTER TABLE match_team_stats ENABLE TRIGGER ALL;
ALTER TABLE match_stats ENABLE TRIGGER ALL;
ALTER TABLE player_stats ENABLE TRIGGER ALL;
ALTER TABLE team_player ENABLE TRIGGER ALL;
ALTER TABLE player_mapping ENABLE TRIGGER ALL;
ALTER TABLE player ENABLE TRIGGER ALL;
ALTER TABLE team ENABLE TRIGGER ALL;
ALTER TABLE match ENABLE TRIGGER ALL;
ALTER TABLE team_standing ENABLE TRIGGER ALL;
ALTER TABLE team_mapping ENABLE TRIGGER ALL;
ALTER TABLE player_mapping ENABLE TRIGGER ALL;
ALTER TABLE player_stats ENABLE TRIGGER ALL;

-- Add position_group column to match_player
ALTER TABLE match_player ADD COLUMN IF NOT EXISTS position_group VARCHAR(32);

-- Change remark column in match_player to JSON
ALTER TABLE match_player ALTER COLUMN remark TYPE JSON USING remark::json;

-- Add new columns to team_standing
ALTER TABLE team_standing ADD COLUMN IF NOT EXISTS round INTEGER;
ALTER TABLE team_standing ADD COLUMN IF NOT EXISTS form VARCHAR(16);
ALTER TABLE team_standing ADD COLUMN IF NOT EXISTS notes VARCHAR(128);
ALTER TABLE team_standing ADD COLUMN IF NOT EXISTS source VARCHAR(32); 