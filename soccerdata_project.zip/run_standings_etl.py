#!/usr/bin/env python

from soccerdata.database.connection import get_session
from soccerdata.datasource_etl.season_etl import SeasonETL

if __name__ == "__main__":
    league_id = 1
    season_id = 1
    with get_session() as session:
        SeasonETL.etl_league_standings(session, league_id=league_id, season_id=season_id)
    print(f"Standings ETL complete for league_id={league_id}, season_id={season_id}") 