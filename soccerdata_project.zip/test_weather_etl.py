#!/usr/bin/env python3
"""
Test script for weather ETL functionality.
"""

from soccerdata.database.connection import get_session
from soccerdata.datasource_etl.weather_etl import WeatherETL
from soccerdata.database.models import Match, MatchStats
from soccerdata.database.repositories import DefStatsRepository

def test_weather_etl():
    """Test the WeatherETL.extract_and_store_weather_for_match method."""
    match_id = 2664  # Use a match_id that exists in your DB with stadium/city info
    print(f"Testing WeatherETL.extract_and_store_weather_for_match for match_id={match_id}...")
    with get_session() as session:
        result = WeatherETL.extract_and_store_weather_for_match(session, match_id)
        print(f"Result: {result}")
        # Check DB for weather stat
        def_stats_repo = DefStatsRepository(session)
        stat_id = def_stats_repo.get_stat_id('match', 'environment', 'weather')
        weather_stat = session.query(MatchStats).filter(
            MatchStats.match_id == match_id,
            MatchStats.stat_id == stat_id,
            MatchStats.is_deleted == False
        ).first()
        print("\nDatabase record after update:")
        if weather_stat:
            print(f"  Weather stat_value: {weather_stat.stat_value}")
        else:
            print("  Weather stat not found!")

if __name__ == "__main__":
    test_weather_etl() 