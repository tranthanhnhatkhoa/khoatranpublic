#!/usr/bin/env python3
"""
Test script for match ETL functionality.
"""

from soccerdata.database.connection import get_session
from soccerdata.datasource_etl.match_etl import MatchETL
from soccerdata.database.models import Match, MatchPlayer
import json

def test_match_etl():
    """Test the MatchETL.match_init method."""
    match_id = 2664
    
    print(f"Testing MatchETL.match_init for match_id={match_id}...")
    
    with get_session() as session:
        # Get FotMob external match ID for internal match_id
        from soccerdata.database.repositories import MappingRepository
        mapping_repo = MappingRepository(session)
        fotmob_match_id = mapping_repo.get_fotmob_external_id_from_match_id(match_id)
        if not fotmob_match_id:
            print(f"[ERROR] No FotMob external match ID found for internal match_id {match_id}")
            return
        # Fetch and save the raw match JSON using FotMob external ID
        from soccerdata.fotmob import FotMob
        fotmob = FotMob()
        raw_data = fotmob.read_team_match_stats_raw(match_id=fotmob_match_id)
        with open('raw_match_2664.json', 'w') as f:
            json.dump(raw_data, f, indent=2)
        print("Raw match JSON saved to raw_match_2664.json")
        # Check DB for stadium, referee, attendance
        match = session.query(Match).filter(Match.match_id == match_id).first()
        with open('stadium_debug_2664.json', 'w') as f:
            json.dump(match.stadium, f, indent=2)
        print("Stadium section saved to stadium_debug_2664.json")
        print("\nDatabase record after update:")
        print(f"  Stadium: {match.stadium}")
        print(f"  Referee: {match.referee}")
        print(f"  Attendance: {match.attendance}")
        # Print match_player records
        match_players = session.query(MatchPlayer).filter(MatchPlayer.match_id == match_id).all()
        print(f"\nMatchPlayer records for match_id={match_id}:")
        for mp in match_players:
            print(f"  match_player_id={mp.match_player_id}, team_id={mp.team_id}, player_id={mp.player_id}")

if __name__ == "__main__":
    test_match_etl() 