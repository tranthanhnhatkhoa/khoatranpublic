#!/usr/bin/env python3
"""
Test script for team match summary stat ETL functionality.
"""

import json
import sys
import os

# Add the project root to the Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from soccerdata.datasource_etl.match_etl import MatchETL
from soccerdata.database.repositories import DefStatsRepository, MatchTeamStatsRepository

def test_team_match_summary_stat_etl():
    """Test the team match summary stat ETL functionality."""
    print("=== TESTING TEAM MATCH SUMMARY STAT ETL ===\n")
    
    # Load test data
    with open('match_2284_raw.json', 'r') as f:
        match_data = json.load(f)
    
    # Set a valid match ID for testing
    match_data['id'] = 2664  # Use an existing match ID from the database
    
    # Update team IDs in the JSON to use FotMob external IDs
    content = match_data.get('content', {})
    lineup = content.get('lineup', {})
    if 'homeTeam' in lineup:
        lineup['homeTeam']['id'] = 10260  # FotMob external ID for Manchester United
        lineup['homeTeam']['name'] = 'Manchester United'
    if 'awayTeam' in lineup:
        lineup['awayTeam']['id'] = 9879  # FotMob external ID for Fulham
        lineup['awayTeam']['name'] = 'Fulham'
    # (If there are other sections in the JSON that reference teamId, update them similarly if needed)
    
    # Initialize ETL
    etl = MatchETL()
    
    # Extract team match summary stats
    print("1. Extracting team match summary stats...")
    team_stats = etl.extract_team_match_summary_stats(match_data)
    
    print(f"   Extracted {len(team_stats)} team records")
    
    # Display the extracted data
    for i, stat_record in enumerate(team_stats):
        print(f"\n2. Team {i+1} ({stat_record['team_side']}):")
        print(f"   - Team ID: {stat_record['team_id']}")
        print(f"   - Team Name: {stat_record['team_name']}")
        print(f"   - Team Side: {stat_record['team_side']}")
        
        stat_data = stat_record['stat']
        print(f"   - Formation: {stat_data.get('formation', 'N/A')}")
        print(f"   - Rating: {stat_data.get('rating', 'N/A')}")
        
        # Performance stats
        performance_stats = stat_data.get('performance_stats')
        if performance_stats:
            print(f"   - Performance Stats: {len(performance_stats)} periods")
            for period, stats in performance_stats.items():
                print(f"     {period}: {len(stats)} categories")
        
        # Recent form
        recent_form = stat_data.get('recent_form')
        if recent_form:
            print(f"   - Recent Form: {len(recent_form)} matches")
            for match in recent_form[:2]:  # Show first 2
                print(f"     {match.get('result')} vs {match.get('opponent')} ({match.get('score')})")
        
        # Match events
        match_events = stat_data.get('match_events')
        if match_events:
            print(f"   - Match Events: {len(match_events)} events")
            for event in match_events[:3]:  # Show first 3
                print(f"     {event.get('type')} - {event.get('player_name', 'N/A')} ({event.get('minute')}')")
        
        # Insights
        insights = stat_data.get('insights')
        if insights:
            print(f"   - Insights: {len(insights)} insights")
            for insight in insights:
                print(f"     - {insight.get('text')}")
        
        # Shot stats
        shot_stats = stat_data.get('shot_stats')
        if shot_stats:
            print(f"   - Shot Stats:")
            print(f"     Total: {shot_stats.get('total_shots')}")
            print(f"     On Target: {shot_stats.get('shots_on_target')}")
            print(f"     Goals: {shot_stats.get('goals')}")
            print(f"     xG: {shot_stats.get('expected_goals')}")
            print(f"     Accuracy: {shot_stats.get('shot_accuracy')}%")
        
        # Momentum data
        momentum_data = stat_data.get('momentum_data')
        if momentum_data:
            print(f"   - Momentum Data: {len(momentum_data)} points")
        
        # Match context
        match_context = stat_data.get('match_context')
        if match_context:
            print(f"   - Match Context:")
            print(f"     Tournament: {match_context.get('tournament')}")
            print(f"     Stadium: {match_context.get('stadium')}")
            print(f"     Attendance: {match_context.get('attendance')}")
        
        # Lineup summary
        lineup_summary = stat_data.get('lineup_summary')
        if lineup_summary:
            print(f"   - Lineup Summary:")
            print(f"     Total Players: {lineup_summary.get('total_players')}")
            print(f"     Starters: {lineup_summary.get('starters_count')}")
            print(f"     Subs: {lineup_summary.get('subs_count')}")
            print(f"     Average Age: {lineup_summary.get('average_age')}")
            print(f"     Captain: {lineup_summary.get('captain', 'N/A')}")
            print(f"     Player of Match: {lineup_summary.get('player_of_match', 'N/A')}")
    
    # Test database storage
    print(f"\n3. Testing database storage...")
    try:
        etl.store_team_match_summary_stats(match_data, [130, 131])
        print("   ✅ Team match summary stats stored successfully!")
    except Exception as e:
        print(f"   ❌ Failed to store team match summary stats: {e}")
        return False
    
    # Verify stored data in match_team_stats
    print(f"\n4. Verifying stored data in match_team_stats...")
    try:
        session = etl.db_session()
        def_stats_repo = DefStatsRepository(session)
        match_team_stats_repo = MatchTeamStatsRepository(session)
        stat_id = def_stats_repo.get_stat_id('summary', 'team', 'team_match_summary')
        for side, team_id in zip(['home', 'away'], [130, 131]):
            stat = match_team_stats_repo.get_by_match_team_stat(match_id=2664, team_id=team_id, stat_id=stat_id)
            assert stat is not None, f"No summary stat found for team_id {team_id}"
            print(f"   - Found summary stat for team_id {team_id} (side: {side}): keys={list(stat.stat_value.keys())}")
        session.close()
        print("   ✅ Data verification successful!")
        
    except Exception as e:
        print(f"   ❌ Failed to verify stored data: {e}")
        return False
    
    print(f"\n✅ TEAM MATCH SUMMARY STAT ETL TEST COMPLETED SUCCESSFULLY!")
    return True

if __name__ == "__main__":
    success = test_team_match_summary_stat_etl()
    sys.exit(0 if success else 1) 