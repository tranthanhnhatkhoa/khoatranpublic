#!/usr/bin/env python

from soccerdata.database.connection import get_session
from soccerdata.datasource_etl.season_etl import SeasonETL

if __name__ == "__main__":
    with get_session() as session:
        SeasonETL.season_init(session, league_id=1, season_id=1)
    print("Season initialization complete for league_id=1, season_id=1.") 