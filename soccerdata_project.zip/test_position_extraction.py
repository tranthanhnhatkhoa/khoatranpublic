#!/usr/bin/env python3
"""Test script for position data extraction."""

from soccerdata.database import get_session, InferredPosition
from soccerdata.datasource_etl.match_etl import MatchETL

def test_position_extraction():
    """Test the position data extraction for match 2664."""
    match_id = 2664
    
    print(f"Testing position extraction for match_id={match_id}...")
    
    with get_session() as session:
        # Call the MatchETL method
        MatchETL.match_init(session, match_id)
        
        # Query and display position data
        from soccerdata.database.models import MatchPlayerStats, DefStats, MatchPlayer
        
        # Get stat IDs for position stats
        position_raw_stat = session.query(DefStats).filter(
            DefStats.stat_name == 'position_raw',
            DefStats.is_deleted == False
        ).first()
        
        position_display_stat = session.query(DefStats).filter(
            DefStats.stat_name == 'position_display',
            DefStats.is_deleted == False
        ).first()
        
        age_stat = session.query(DefStats).filter(
            DefStats.stat_name == 'age',
            DefStats.is_deleted == False
        ).first()
        
        shirt_number_stat = session.query(DefStats).filter(
            DefStats.stat_name == 'shirt_number',
            DefStats.is_deleted == False
        ).first()
        
        country_stat = session.query(DefStats).filter(
            DefStats.stat_name == 'country',
            DefStats.is_deleted == False
        ).first()
        
        performance_stat = session.query(DefStats).filter(
            DefStats.stat_name == 'performance',
            DefStats.is_deleted == False
        ).first()
        
        if not all([position_raw_stat, position_display_stat, age_stat, 
                   shirt_number_stat, country_stat, performance_stat]):
            print("Some player stats not found in def_stats table!")
            return
        
        print(f"Player stats found:")
        print(f"  position_raw stat_id: {position_raw_stat.stat_id}")
        print(f"  position_display stat_id: {position_display_stat.stat_id}")
        print(f"  age stat_id: {age_stat.stat_id}")
        print(f"  shirt_number stat_id: {shirt_number_stat.stat_id}")
        print(f"  country stat_id: {country_stat.stat_id}")
        print(f"  performance stat_id: {performance_stat.stat_id}")
        
        # Query and display all player data
        all_stat_ids = [position_raw_stat.stat_id, position_display_stat.stat_id,
                       age_stat.stat_id, shirt_number_stat.stat_id, 
                       country_stat.stat_id, performance_stat.stat_id]
        
        player_stats = session.query(MatchPlayerStats).filter(
            MatchPlayerStats.match_id == match_id,
            MatchPlayerStats.stat_id.in_(all_stat_ids),
            MatchPlayerStats.is_deleted == False
        ).all()
        
        print(f"\nFound {len(player_stats)} player stat records:")
        for stat in player_stats:
            if stat.stat_id == position_raw_stat.stat_id:
                print(f"  Position Raw: {stat.stat_value}")
            elif stat.stat_id == position_display_stat.stat_id:
                print(f"  Position Display: {stat.stat_value}")
            elif stat.stat_id == age_stat.stat_id:
                print(f"  Age: {stat.stat_value}")
            elif stat.stat_id == shirt_number_stat.stat_id:
                print(f"  Shirt Number: {stat.stat_value}")
            elif stat.stat_id == country_stat.stat_id:
                print(f"  Country: {stat.stat_value}")
            elif stat.stat_id == performance_stat.stat_id:
                print(f"  Performance: {stat.stat_value}")
        
        # Query and display position data
        match_players = session.query(MatchPlayer).filter(MatchPlayer.match_id == match_id).all()
        for mp in match_players:
            print(f"Player: {mp.player_id}, Team: {mp.team_id}, Type: {mp.type}, Position Group: {mp.position_group}")

def test_inferred_position_enum():
    """Test the InferredPosition enum mapping."""
    print("\nTesting InferredPosition enum:")
    
    test_cases = [
        (11, "Goalkeeper"),
        (32, "Right Back"),
        (34, "Center Back"),
        (36, "Center Back"),
        (38, "Left Back"),
        (64, "Defensive Midfielder"),
        (66, "Central Midfielder"),
        (83, "Right Winger"),
        (85, "Attacking Midfielder"),
        (87, "Left Winger"),
        (115, "Striker"),
        (999, "Unknown"),  # Unknown position
    ]
    
    for position_id, expected in test_cases:
        result = InferredPosition.from_position_id(position_id)
        status = "✓" if result == expected else "✗"
        print(f"  {status} positionId {position_id} -> {result} (expected: {expected})")

if __name__ == "__main__":
    test_inferred_position_enum()
    test_position_extraction() 