#!/usr/bin/env python3
import json
from soccerdata.fotmob import FotMob
from soccerdata.database.repositories import MappingRepository, PlayerRepository, MatchPlayerRepository, TeamPlayerRepository
from soccerdata.database.models import Team, Player, MatchPlayer
from soccerdata._config import DATASOURCE
from datetime import datetime
import requests

class TeamETL:
    @staticmethod
    def team_init(session, team_id: int, ccode3: str = "ENG"):
        """
        Initialize and load team squad data from FotMob for a given internal team_id.
        Inserts squad players into the match_player table (pseudo match_id = -team_id).
        """
        # 1. Get FotMob external_id for the team
        mapping_repo = MappingRepository(session)
        team_mapping = session.query(MappingRepository).filter_by(team_id=team_id, data_source=DATASOURCE.FOTMOB.value).first()
        if not team_mapping:
            print(f"[ERROR] No FotMob mapping found for team_id={team_id}")
            return
        external_team_id = team_mapping.external_id
        print(f"[INFO] Found FotMob external_id for team_id={team_id}: {external_team_id}")

        # 2. Fetch squad JSON from FotMob API
        url = f"https://www.fotmob.com/api/data/teams?id={external_team_id}&ccode3={ccode3}"
        response = requests.get(url)
        if response.status_code != 200:
            print(f"[ERROR] Failed to fetch squad data from FotMob for team_id={team_id}")
            return
        team_json = response.json()
        print(f"[INFO] Fetched squad JSON for team_id={team_id}")

        # 3. Extract squad and insert into match_player (pseudo match_id = -team_id)
        squad = team_json.get('squad', [])
        if not squad:
            print(f"[WARN] No squad data found in FotMob JSON for team_id={team_id}")
            return
        player_repo = PlayerRepository(session)
        match_player_repo = MatchPlayerRepository(session)
        team_player_repo = TeamPlayerRepository(session)
        pseudo_match_id = -team_id
        for player in squad:
            player_name = player.get('name')
            if not player_name:
                continue
            # Create or get player
            db_player = player_repo.get_by_name(player_name)
            if not db_player:
                db_player = Player(name=player_name)
                session.add(db_player)
                session.flush()
            # Add to team_player (roster)
            team_player_repo.add_player_to_team(team_id, db_player.player_id)
            # Insert into match_player (pseudo match)
            match_player_repo.create_or_update(
                match_id=pseudo_match_id,
                team_id=team_id,
                player_id=db_player.player_id,
                type=None,
                remark={
                    'position': player.get('position'),
                    'shirt_number': player.get('shirtNumber'),
                    'country': player.get('country'),
                    'age': player.get('age')
                },
                position_group=None
            )
        session.commit()
        print(f"[INFO] Inserted {len(squad)} players into match_player for team_id={team_id}") 