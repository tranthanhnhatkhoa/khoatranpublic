import requests
from datetime import datetime
from typing import Dict, Any, Optional
from soccerdata.database.repositories import MatchRepository, DefStatsRepository
from soccerdata.database.models import Match, MatchStats
from sqlalchemy.orm import Session
from meteostat import Point, Hourly
import pandas as pd
from soccerdata.database.stat_enums import StatDefinition

class WeatherETL:
    @staticmethod
    def get_lat_long(stadium: str, city: str) -> Optional[Dict[str, float]]:
        """
        Use Nominatim (OpenStreetMap) to get latitude and longitude for a given stadium and city.
        """
        url = "https://nominatim.openstreetmap.org/search"
        params = {
            "q": f"{stadium}, {city}",
            "format": "json",
            "limit": 1
        }
        headers = {"User-Agent": "soccerdata-weather-etl/1.0"}
        response = requests.get(url, params=params, headers=headers)
        if response.status_code == 200 and response.json():
            data = response.json()[0]
            return {"lat": float(data["lat"]), "lon": float(data["lon"])}
        return None

    @staticmethod
    def get_weather(lat: float, lon: float, date: str) -> Optional[Dict[str, Any]]:
        """
        Use Open-Meteo API to get weather data for a given latitude, longitude, and date (YYYY-MM-DD).
        """
        url = "https://api.open-meteo.com/v1/forecast"
        params = {
            "latitude": lat,
            "longitude": lon,
            "start_date": date,
            "end_date": date,
            "hourly": "temperature_2m,precipitation,weathercode,cloudcover,windspeed_10m",
            "timezone": "auto"
        }
        response = requests.get(url, params=params)
        if response.status_code == 200:
            return response.json()
        return None

    @staticmethod
    def get_weather_meteostat(lat: float, lon: float, date: str) -> Optional[Dict[str, Any]]:
        """
        Use Meteostat to get weather data for a given latitude, longitude, and date (YYYY-MM-DD).
        """
        try:
            dt = datetime.strptime(date, "%Y-%m-%d")
            location = Point(lat, lon)
            data = Hourly(location, dt, dt)
            df = data.fetch()
            if df.empty:
                return None
            # Format to match Open-Meteo output
            result = {
                "latitude": lat,
                "longitude": lon,
                "timezone": str(df.index.tz),
                "hourly": {
                    "time": [d.isoformat() for d in df.index],
                    "temperature_2m": df["temp"].tolist() if "temp" in df else [],
                    "precipitation": df["prcp"].tolist() if "prcp" in df else [],
                    "cloudcover": df["cldc"].tolist() if "cldc" in df else [],
                    "windspeed_10m": df["wspd"].tolist() if "wspd" in df else [],
                },
                "source": "meteostat"
            }
            return result
        except Exception as e:
            print(f"[ERROR] Meteostat fallback failed: {e}")
            return None

    @classmethod
    def extract_weather(cls, stadium: dict, date: str) -> Optional[Dict[str, Any]]:
        """
        Given stadium dict and date, return weather data for that location and date.
        Uses lat/long if available, otherwise falls back to geocoding.
        """
        lat = stadium.get('lat')
        lon = stadium.get('long')
        if lat is not None and lon is not None:
            weather = cls.get_weather(lat, lon, date)
            # Fallback: if all values are None or missing, try Meteostat
            if weather:
                hourly = weather.get('hourly', {})
                if all((hourly.get(k) is None or all(v is None for v in hourly.get(k, []))) for k in ["temperature_2m", "precipitation", "cloudcover", "windspeed_10m"]):
                    print("[INFO] Open-Meteo returned all None, using Meteostat fallback")
                    weather = cls.get_weather_meteostat(lat, lon, date)
            else:
                weather = cls.get_weather_meteostat(lat, lon, date)
            return weather
        # Fallback: try geocoding
        stadium_name = stadium.get('name')
        city = stadium.get('city') or stadium.get('location')
        if not stadium_name or not city:
            print(f"Could not find lat/long or sufficient info for geocoding: {stadium}")
            return None
        location = cls.get_lat_long(stadium_name, city)
        if not location:
            print(f"Could not find location for {stadium_name}, {city}")
            return None
        weather = cls.get_weather(location["lat"], location["lon"], date)
        if weather:
            hourly = weather.get('hourly', {})
            if all((hourly.get(k) is None or all(v is None for v in hourly.get(k, []))) for k in ["temperature_2m", "precipitation", "cloudcover", "windspeed_10m"]):
                print("[INFO] Open-Meteo returned all None, using Meteostat fallback")
                weather = cls.get_weather_meteostat(location["lat"], location["lon"], date)
        else:
            weather = cls.get_weather_meteostat(location["lat"], location["lon"], date)
        return weather

    @classmethod
    def extract_and_store_weather_for_match(cls, session: Session, match_id: int) -> bool:
        """
        Extract weather data for a match and store it in match_stats table.
        - Uses match's stadium and date.
        - Adds a new stat in def_stats if not present.
        - Stores weather data in match_stats.
        Returns True if successful, False otherwise.
        """
        match_repo = MatchRepository(session)
        def_stats_repo = DefStatsRepository(session)
        match = match_repo.get_by_id(Match, match_id)
        if not match:
            print(f"[ERROR] Match {match_id} not found!")
            return False
        stadium = match.stadium or {}
        match_date = match.match_date.strftime('%Y-%m-%d')
        weather_data = cls.extract_weather(stadium, match_date)
        if not weather_data:
            print(f"[ERROR] Could not extract weather data for match {match_id}")
            return False
        # Ensure weather stat exists in def_stats
        stat_def = StatDefinition.get_weather_stat()
        stat_id = def_stats_repo.get_stat_id(stat_def['category'], stat_def['sub_category'], stat_def['stat_name'])
        if not stat_id:
            stat = def_stats_repo.create_stat(
                stat_name=stat_def['stat_name'],
                stat_category=stat_def['category'],
                stat_sub_category=stat_def['sub_category'],
                description='Weather data for the match (from Open-Meteo or Meteostat)',
            )
            session.flush()  # get stat_id
            stat_id = stat.stat_id
        # Insert into match_stats
        existing = session.query(MatchStats).filter(
            MatchStats.match_id == match_id,
            MatchStats.stat_id == stat_id,
            MatchStats.is_deleted == False
        ).first()
        if existing:
            existing.stat_value = weather_data
        else:
            new_stat = MatchStats(
                match_id=match_id,
                stat_id=stat_id,
                stat_value=weather_data
            )
            session.add(new_stat)
        session.commit()
        print(f"[INFO] Weather data stored for match {match_id}")
        return True 