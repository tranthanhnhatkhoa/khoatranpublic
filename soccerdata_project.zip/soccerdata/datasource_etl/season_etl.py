#!/usr/bin/env python3
"""
ETL logic for initializing and loading season data from FotMob.
"""
import pandas as pd
from soccerdata.fotmob import FotMob
from soccerdata.database.repositories import (
    LeagueRepository, SeasonRepository, TeamRepository, MatchRepository, MappingRepository
)
from soccerdata._config import DATASOURCE
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from soccerdata.database.models import TeamStanding, Team, League, Season, LeagueMapping, SeasonMapping
from soccerdata.database.connection import get_session
from soccerdata.database.models import TeamMapping
from datetime import datetime
from sqlalchemy import func

class SeasonETL:
    @staticmethod
    def season_init(session: Session, league_id: int, season_id: int):
        """
        Initialize and load season data from FotMob for a given league and season.
        Inserts teams, matches, and mappings into the database.
        """
        print(f"Starting season initialization for league_id={league_id}, season_id={season_id}")
        
        league_repo = LeagueRepository(session)
        season_repo = SeasonRepository(session)
        team_repo = TeamRepository(session)
        match_repo = MatchRepository(session)
        mapping_repo = MappingRepository(session)

        # 1. Get FotMob league and season codes (now using generic methods)
        fotmob_league_code = league_repo.get_external_league_code(league_id, DATASOURCE.FOTMOB.value)
        fotmob_season_code = season_repo.get_external_season_code(season_id, DATASOURCE.FOTMOB.value)

        if not fotmob_league_code or not fotmob_season_code:
            print(f"Could not find FotMob codes for league_id={league_id}, season_id={season_id}. Aborting.")
            return

        print(f"Found FotMob codes: league='{fotmob_league_code}', season='{fotmob_season_code}'")

        # 2. Fetch schedule data using the updated read_schedule method
        fotmob = FotMob(leagues=fotmob_league_code, seasons=fotmob_season_code)
        schedule_df = fotmob.read_schedule()

        if schedule_df.empty:
            print("No schedule data found. Aborting.")
            return
        
        print(f"Successfully fetched {len(schedule_df)} matches from FotMob.")

        # 3. Process and insert teams, matches, and mappings
        inserted_teams = 0
        inserted_matches = 0
        inserted_team_mappings = 0

        for _, row in schedule_df.iterrows():
            try:
                # Create or update home and away teams
                home_team = team_repo.create_or_update(name=row['home_team'], short_name=row['home_team_short'])
                away_team = team_repo.create_or_update(name=row['away_team'], short_name=row['away_team_short'])
                session.flush()  # Ensure team_ids are available

                # Insert team mappings if they don't exist
                if not mapping_repo.get_team_by_external_id(str(row['home_team_id']), DATASOURCE.FOTMOB.value):
                    mapping_repo.create_team_mapping(
                        team_id=home_team.team_id,
                        external_id=str(row['home_team_id']),
                        data_source=DATASOURCE.FOTMOB.value,
                        pageUrl=None  # No team URL available from this endpoint
                    )
                    inserted_team_mappings += 1

                if not mapping_repo.get_team_by_external_id(str(row['away_team_id']), DATASOURCE.FOTMOB.value):
                    mapping_repo.create_team_mapping(
                        team_id=away_team.team_id,
                        external_id=str(row['away_team_id']),
                        data_source=DATASOURCE.FOTMOB.value,
                        pageUrl=None  # No team URL available from this endpoint
                    )
                    inserted_team_mappings += 1

                # Create or update match
                match = match_repo.create_or_update(
                    league_id=league_id,
                    season_id=season_id,
                    home_team_id=home_team.team_id,
                    away_team_id=away_team.team_id,
                    match_date=pd.to_datetime(row['date']),
                    round=row.get('round'),
                    round_name=row.get('round_name'),
                    home_goals=row.get('home_score'),
                    away_goals=row.get('away_score'),
                    match_status=None,  # Or derive from data if available
                )
                session.flush()
                inserted_matches += 1

                # Insert match mapping
                mapping_repo.create_match_mapping(
                    match_id=match.match_id,
                    external_id=str(row['game_id']), # Use FotMob's real match ID
                    data_source=DATASOURCE.FOTMOB.value,
                    url=row.get('url')
                )

            except IntegrityError as e:
                session.rollback()
                print(f"Skipping row due to integrity error: {e}")
                continue
            except Exception as e:
                session.rollback()
                print(f"An unexpected error occurred: {e}")
                continue
        
        # Final commit
        session.commit()

        print("\n--- SEASON INIT SUMMARY ---")
        print(f"Total Matches Processed: {len(schedule_df)}")
        print(f"New Matches Inserted: {inserted_matches}")
        print(f"New Team Mappings Inserted: {inserted_team_mappings}")
        print("---------------------------\n")

    @staticmethod
    def etl_league_standings(session: Session, league_id: int, season_id: int, round_name: str = "Current"):
        """
        Extract and store the current league table for the given league and season into team_standing table.
        """
        # Get FotMob league/season external IDs
        league_mapping = session.query(LeagueMapping).filter(
            LeagueMapping.league_id == league_id,
            func.lower(LeagueMapping.data_source) == "fotmob"
        ).first()
        season_mapping = session.query(SeasonMapping).filter(
            SeasonMapping.season_id == season_id,
            func.lower(SeasonMapping.data_source) == "fotmob"
        ).first()
        if not league_mapping or not season_mapping:
            print(f"[ERROR] No mapping found for league_id={league_id} or season_id={season_id}")
            return
        fotmob_league_id = league_mapping.source_league_code
        fotmob_season_id = season_mapping.source_season_code
        fotmob = FotMob(leagues=[fotmob_league_id], seasons=[fotmob_season_id])
        df = fotmob.read_league_table()
        # Compute position as 1-based rank in the DataFrame
        df = df.reset_index()  # Remove multi-index if present
        df['position'] = df.index + 1
        for _, row in df.iterrows():
            team = session.query(Team).filter_by(name=row['team']).first()
            if not team:
                print(f"[WARN] Team not found: {row['team']}")
                continue
            standing = TeamStanding(
                league_id=league_id,
                season_id=season_id,
                team_id=team.team_id,
                round_name=round_name,
                position=row.get('position'),
                matches_played=row.get('MP'),
                wins=row.get('W'),
                draws=row.get('D'),
                losses=row.get('L'),
                goals_for=row.get('GF'),
                goals_against=row.get('GA'),
                goal_difference=row.get('GD'),
                points=row.get('Pts'),
                round=None,
                form=row.get('form'),
                notes=row.get('notes'),
                source="FOTMOB",
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow(),
                is_deleted=False
            )
            session.merge(standing)
        session.commit()
        print(f"[INFO] League standings ETL complete for league_id={league_id}, season_id={season_id}") 