#!/usr/bin/env python3
import os
import json
from tempfile import gettempdir
from soccerdata.fotmob import FotMob
from soccerdata.database.repositories import LeagueRepository, SeasonRepository, MappingRepository, MatchRepository, DefStatsRepository, PlayerRepository, MatchPlayerRepository, TeamPlayerRepository, PlayerUnavailabilityRepository, MatchTeamStatsRepository, MatchPlayerStatsRepository
from soccerdata.database.models import Match, MatchStats, Player, PlayerMapping, MatchPlayerStats, MatchPlayer, MatchTeamStats, PlayerStats, TeamMapping
from soccerdata.database.stat_enums import StatDefinition, InferredPosition, LineupType
from soccerdata._config import DATASOURCE
from typing import List, Dict
from datetime import datetime
from soccerdata.database.connection import get_session
import sys
from soccerdata.datasource_etl.weather_etl import WeatherETL

class MatchETL:
    def db_session(self):
        """Get a database session."""
        return get_session()

    @staticmethod
    def crawl_get_match_detail(session, match_id: int):
        """
        Fetch match detail from FotMob and return the JSON.
        Args:
            session: SQLAlchemy session
            match_id: internal match ID
        Returns:
            dict: match detail JSON from FotMob, or None if not found
        """
        # 1. Get season_id and league_id from match table
        match_repo = MatchRepository(session)
        match = match_repo.get_by_id(model_class=Match, id_value=match_id)
        if not match:
            return None
        league_id = match.league_id
        season_id = match.season_id

        # 2. Get external_id for season and league (FotMob)
        league_repo = LeagueRepository(session)
        season_repo = SeasonRepository(session)
        external_league_code = league_repo.get_external_league_code(league_id, DATASOURCE.FOTMOB.value)
        external_season_code = season_repo.get_external_season_code(season_id, DATASOURCE.FOTMOB.value)
        if not external_league_code or not external_season_code:
            return None

        # 3. Get external_id for match (FotMob)
        mapping_repo = MappingRepository(session)
        external_match_id = mapping_repo.get_external_id_from_match_id(match_id, DATASOURCE.FOTMOB.value)
        if not external_match_id:
            return None

        # 4. Fetch the match JSON using FotMob.read_team_match_stats_raw
        fotmob = FotMob(leagues=external_league_code, seasons=external_season_code)
        raw_data = fotmob.read_team_match_stats_raw(match_id=external_match_id)
        match_json = raw_data.get(str(external_match_id))
        if not match_json:
            return None

        # DEBUG: Print the structure of match_json
        print(f"[DEBUG] match_json top-level keys: {list(match_json.keys())}", flush=True)
        print(f"[DEBUG] match_json sample: {json.dumps(match_json, indent=2)[:500]}", flush=True)

        # Save JSON to temp file
        temp_path = os.path.join(gettempdir(), f"match_{match_id}_raw.json")
        with open(temp_path, "w", encoding="utf-8") as f:
            json.dump(match_json, f, ensure_ascii=False, indent=2)
        print(f"[DEBUG] Saved match JSON to {temp_path}", flush=True)

        return match_json

    @staticmethod
    def _extract_and_store_h2h(session, match_id: int, match_json: dict):
        """
        Extract h2h data from match JSON and store in match_stats table.
        Args:
            session: SQLAlchemy session
            match_id: internal match ID
            match_json: match data from FotMob
        """
        def_stats_repo = DefStatsRepository(session)
        h2h_def = StatDefinition.get_h2h_stat()
        h2h_stat_id = def_stats_repo.get_stat_id(
            h2h_def['category'],
            h2h_def['sub_category'],
            h2h_def['stat_name']
        )
        if not h2h_stat_id:
            print(f"[WARNING] h2h stat ID not found in def_stats table")
            return
        print(f"[DEBUG] Using h2h stat ID: {h2h_stat_id}", flush=True)
        h2h_data = match_json.get('content', {}).get('h2h', None)
        if not h2h_data:
            print(f"[DEBUG] No h2h data found in match")
            return
        print(f"[DEBUG] Found h2h data, storing in match_stats")
        existing = session.query(MatchStats).filter(
            MatchStats.match_id == match_id,
            MatchStats.stat_id == h2h_stat_id,
            MatchStats.is_deleted == False
        ).first()
        if existing:
            print(f"[DEBUG] Updating existing h2h data")
            existing.stat_value = {
                'h2h': h2h_data,
                'data_source': 'fotmob'
            }
            session.add(existing)
        else:
            print(f"[DEBUG] Creating new h2h data")
            new_h2h = MatchStats(
                match_id=match_id,
                stat_id=h2h_stat_id,
                stat_value={
                    'h2h': h2h_data,
                    'data_source': 'fotmob'
                }
            )
            session.add(new_h2h)
        session.commit()
        print(f"[DEBUG] h2h data stored successfully")

    @staticmethod
    def _extract_and_store_momentum(session, match_id: int, match_json: dict):
        """
        Extract momentum data from match JSON and store in match_stats table.
        Args:
            session: SQLAlchemy session
            match_id: internal match ID
            match_json: match data from FotMob
        """
        def_stats_repo = DefStatsRepository(session)
        momentum_def = StatDefinition.get_momentum_stat()
        momentum_stat_id = def_stats_repo.get_stat_id(
            momentum_def['category'],
            momentum_def['sub_category'],
            momentum_def['stat_name']
        )
        if not momentum_stat_id:
            print(f"[WARNING] Momentum stat ID not found in def_stats table")
            return
        print(f"[DEBUG] Using momentum stat ID: {momentum_stat_id}", flush=True)
        momentum_data = match_json.get('content', {}).get('momentum', None)
        if not momentum_data:
            print(f"[DEBUG] No momentum data found in match")
            return
        print(f"[DEBUG] Found momentum data, storing in match_stats")
        existing = session.query(MatchStats).filter(
            MatchStats.match_id == match_id,
            MatchStats.stat_id == momentum_stat_id,
            MatchStats.is_deleted == False
        ).first()
        if existing:
            print(f"[DEBUG] Updating existing momentum data")
            existing.stat_value = {
                'momentum': momentum_data,
                'data_source': 'fotmob'
            }
            session.add(existing)
        else:
            print(f"[DEBUG] Creating new momentum data")
            new_momentum = MatchStats(
                match_id=match_id,
                stat_id=momentum_stat_id,
                stat_value={
                    'momentum': momentum_data,
                    'data_source': 'fotmob'
                }
            )
            session.add(new_momentum)
        session.commit()
        print(f"[DEBUG] Momentum data stored successfully")

    @staticmethod
    def _extract_and_store_comprehensive_team_stats(session, match_id: int, match_json: dict):
        """
        Extract comprehensive team stats from content->stats->Periods for All, FirstHalf, and SecondHalf.
        Args:
            session: SQLAlchemy session
            match_id: internal match ID
            match_json: match data from FotMob
        """
        def_stats_repo = DefStatsRepository(session)
        match_team_stats_repo = MatchTeamStatsRepository(session)
        
        # Get team IDs from match
        match = session.query(Match).filter(Match.match_id == match_id).first()
        if not match:
            print(f"[ERROR] Match {match_id} not found!")
            return
        
        team_map = {
            'home': match.home_team_id,
            'away': match.away_team_id
        }
        
        # Get stats from content->stats->Periods
        stats_content = match_json.get('content', {}).get('stats', {})
        periods = stats_content.get('Periods', {})
        
        # Track processed stats to avoid duplicates
        processed_stats = set()
        
        # Process each period
        for period_name, period_data in periods.items():
            if period_name not in ['All', 'FirstHalf', 'SecondHalf']:
                continue
                
            print(f"[DEBUG] Processing period: {period_name}")
            
            # Get stats array for this period
            stats_array = period_data.get('stats', [])
            if not stats_array:
                continue
            
            # Process each stat category (Top stats, Shots, Expected goals, etc.)
            for stat_category in stats_array:
                category_title = stat_category.get('title', '')
                category_stats = stat_category.get('stats', [])
                
                if not isinstance(category_stats, list):
                    continue
                
                # Process each stat in the category
                for stat_item in category_stats:
                    if not isinstance(stat_item, dict):
                        continue
                    
                    stat_title = stat_item.get('title', '')
                    stat_key = stat_item.get('key', '')
                    stat_values = stat_item.get('stats', [])
                    stat_type = stat_item.get('type', '')
                    
                    if not stat_title or not stat_key or not isinstance(stat_values, list) or len(stat_values) != 2:
                        continue
                    
                    # Determine the stat name based on period
                    if period_name == 'All':
                        stat_name = stat_key.lower()
                    elif period_name == 'FirstHalf':
                        stat_name = f"first_half_{stat_key.lower()}"
                    elif period_name == 'SecondHalf':
                        stat_name = f"second_half_{stat_key.lower()}"
                    else:
                        continue
                    
                    # Create unique key to avoid duplicates
                    stat_unique_key = f"{period_name}_{stat_name}"
                    if stat_unique_key in processed_stats:
                        print(f"[DEBUG] Skipping duplicate stat: {stat_unique_key}")
                        continue
                    
                    # Get stat ID
                    stat_id = def_stats_repo.get_stat_id('team', 'basic', stat_name)
                    if not stat_id:
                        # Try advanced category
                        stat_id = def_stats_repo.get_stat_id('team', 'advanced', stat_name)
                    
                    if not stat_id:
                        print(f"[DEBUG] Stat ID not found for: {stat_name}")
                        continue
                    
                    # Process home and away team values
                    home_value = stat_values[0]
                    away_value = stat_values[1]
                    
                    # Store home team stat with cleaner JSON format
                    if home_value is not None:
                        # Store as simple key-value format: {"stat_name": "value"}
                        stat_value = {stat_name: home_value}
                        match_team_stats_repo.create_or_update(
                            match_id=match_id,
                            team_id=team_map['home'],
                            stat_id=stat_id,
                            stat_value=stat_value
                        )
                    
                    # Store away team stat with cleaner JSON format
                    if away_value is not None:
                        # Store as simple key-value format: {"stat_name": "value"}
                        stat_value = {stat_name: away_value}
                        match_team_stats_repo.create_or_update(
                            match_id=match_id,
                            team_id=team_map['away'],
                            stat_id=stat_id,
                            stat_value=stat_value
                        )
                    
                    # Mark as processed
                    processed_stats.add(stat_unique_key)
        
        session.commit()
        print(f"[DEBUG] Comprehensive team stats stored successfully for match_id={match_id}")

    @staticmethod
    def _extract_and_store_player_match_stats(session, match_id: int, match_json: dict):
        """
        Extract comprehensive player match statistics from multiple sections and store as a single summary stat.
        
        This method captures ALL player-related data from:
        - content->playerStats: Performance statistics (Top stats, Attack, Defense, Duels)
        - content->playerStats->funFacts: Player achievements and insights
        - content->matchFacts->events: Cards, substitutions, goals, other events
        - content->matchFacts->playerOfTheMatch: Player of match recognition
        - content->matchFacts->topPlayers: Top player recognition
        - content->matchFacts->insights: Player-specific insights (when playerId is not null)
        
        Args:
            session: SQLAlchemy session
            match_id: internal match ID
            match_json: match data from FotMob
        """
        def_stats_repo = DefStatsRepository(session)
        match_player_stats_repo = MatchPlayerStatsRepository(session)
        
        # Get the stat ID for player_match_summary_stat
        stat_def = StatDefinition.get_player_match_summary_stat()
        stat_id = def_stats_repo.get_stat_id(stat_def['category'], stat_def['sub_category'], stat_def['stat_name'])
        if not stat_id:
            print("[ERROR] Stat 'player_match_summary_stat' not found!")
            return
        
        # Get team mappings
        team_mappings = {}
        for team_mapping in session.query(TeamMapping).filter(
            TeamMapping.data_source == 'FotMob',
            TeamMapping.is_deleted == False
        ).all():
            team_mappings[team_mapping.external_id] = team_mapping.team_id
        
        # Extract events data for later use
        events_data = match_json.get('content', {}).get('matchFacts', {}).get('events', {}).get('events', [])
        
        # Extract player of match data
        player_of_match = match_json.get('content', {}).get('matchFacts', {}).get('playerOfTheMatch', {})
        player_of_match_id = player_of_match.get('id') if player_of_match else None
        
        # Extract top players data
        top_players = match_json.get('content', {}).get('matchFacts', {}).get('topPlayers', {})
        top_player_ids = set()
        for team_players in [top_players.get('homeTopPlayers', []), top_players.get('awayTopPlayers', [])]:
            for player in team_players:
                top_player_ids.add(player.get('playerId'))
        
        # Extract insights data
        insights = match_json.get('content', {}).get('matchFacts', {}).get('insights', [])
        player_insights = {}
        for insight in insights:
            player_id = insight.get('playerId')
            if player_id is not None:  # Only player-specific insights
                if player_id not in player_insights:
                    player_insights[player_id] = []
                player_insights[player_id].append({
                    'type': insight.get('type'),
                    'text': insight.get('text'),
                    'priority': insight.get('priority'),
                    'localized_text_id': insight.get('localizedTextId')
                })
        
        # Process player stats
        player_stats = match_json.get('content', {}).get('playerStats', {})
        processed_count = 0
        
        for player_external_id, player_data in player_stats.items():
            player_external_id = str(player_external_id)
            player_name = player_data.get('name')
            player_team_id_external = player_data.get('teamId')
            
            if not player_name or not player_team_id_external:
                continue
            
            # Get internal team ID from external team ID
            team_mapping = session.query(TeamMapping).filter(
                TeamMapping.external_id == str(player_team_id_external),
                TeamMapping.data_source == 'FotMob',
                TeamMapping.is_deleted == False
            ).first()
            
            if not team_mapping:
                print(f"[DEBUG] Team mapping not found for external team ID: {player_team_id_external}")
                continue
            
            team_id = team_mapping.team_id
            
            # Get internal player ID from external player ID
            mapping = session.query(PlayerMapping).filter(
                PlayerMapping.external_id == str(player_external_id),
                PlayerMapping.data_source == DATASOURCE.FOTMOB.value
            ).first()
            
            if not mapping:
                print(f"[DEBUG] Player mapping not found for external player ID: {player_external_id}")
                continue
            
            player_id = mapping.player_id
            
            # Build comprehensive player match summary
            player_summary = {
                'player_info': {
                    'external_id': player_external_id,
                    'name': player_name,
                    'team_id': team_id
                },
                'performance_stats': {},
                'match_events': {
                    'cards': [],
                    'substitutions': [],
                    'goals': [],
                    'other_events': []
                },
                'recognition': {
                    'is_player_of_match': False,
                    'is_top_player': False,
                    'rating': None,
                    'position': None
                },
                'fun_facts': [],
                'insights': []
            }
            
            # 1. Extract performance stats from playerStats
            stats = player_data.get('stats', [])
            for stat_section in stats:
                section_title = stat_section.get('title', 'Unknown')
                section_stats = stat_section.get('stats', {})
                
                if section_title not in player_summary['performance_stats']:
                    player_summary['performance_stats'][section_title] = {}
                
                for stat_name, stat_data in section_stats.items():
                    if isinstance(stat_data, dict) and 'stat' in stat_data:
                        stat_value = stat_data['stat'].get('value')
                        if stat_value is not None:
                            player_summary['performance_stats'][section_title][stat_name] = stat_value
            
            # 2. Extract fun facts
            fun_facts = player_data.get('funFacts', [])
            for fun_fact in fun_facts:
                player_summary['fun_facts'].append({
                    'key': fun_fact.get('key'),
                    'text': fun_fact.get('fallback'),
                    'input_values': fun_fact.get('inputValues', [])
                })
            
            # 3. Extract match events for this player
            for event in events_data:
                event_player_id = event.get('playerId')
                if event_player_id and str(event_player_id) == player_external_id:
                    event_type = event.get('type')
                    event_data = {
                        'type': event_type,
                        'time': event.get('time'),
                        'is_home': event.get('isHome')
                    }
                    
                    if event_type == 'Card':
                        event_data.update({
                            'card_type': event.get('card'),
                            'card_description': event.get('cardDescription')
                        })
                        player_summary['match_events']['cards'].append(event_data)
                    
                    elif event_type == 'Substitution':
                        swap = event.get('swap', [])
                        if len(swap) == 2:
                            event_data.update({
                                'incoming_player': swap[0].get('name'),
                                'outgoing_player': swap[1].get('name')
                            })
                        player_summary['match_events']['substitutions'].append(event_data)
                    
                    elif event_type == 'Goal':
                        event_data.update({
                            'goal_type': event.get('goalType'),
                            'assist': event.get('assist')
                        })
                        player_summary['match_events']['goals'].append(event_data)
                    
                    else:
                        player_summary['match_events']['other_events'].append(event_data)
            
            # 4. Set recognition data
            if player_of_match_id and str(player_of_match_id) == player_external_id:
                player_summary['recognition']['is_player_of_match'] = True
                player_summary['recognition']['rating'] = player_of_match.get('rating', {}).get('num')
                player_summary['recognition']['position'] = player_of_match.get('teamData', {}).get('home' if player_of_match.get('isHomeTeam') else 'away', {}).get('positionLabel', {}).get('label')
            
            if int(player_external_id) in top_player_ids:
                player_summary['recognition']['is_top_player'] = True
                # Find the player in top players to get rating
                for team_players in [top_players.get('homeTopPlayers', []), top_players.get('awayTopPlayers', [])]:
                    for player in team_players:
                        if player and player.get('playerId') == int(player_external_id):
                            player_summary['recognition']['rating'] = player.get('playerRating')
                            position_label = player.get('positionLabel', {})
                            if position_label:
                                player_summary['recognition']['position'] = position_label.get('label')
                            break
            
            # 5. Add player-specific insights
            if player_external_id in player_insights:
                player_summary['insights'] = player_insights[player_external_id]
            
            # Store the comprehensive player match summary
            match_player_stats_repo.create_or_update(
                match_id=match_id,
                team_id=team_id,
                player_id=player_id,
                stat_id=stat_id,
                stat_value=player_summary
            )
            
            processed_count += 1
        
        session.commit()
        print(f"[DEBUG] Enhanced player match stats stored successfully for {processed_count} players in match_id={match_id}")

    @staticmethod
    def match_init(session, match_id: int):
        print(f"[DEBUG] Entered match_init for match_id={match_id}", flush=True)
        try:
            # Step 1: Crawl and save JSON
            MatchETL.crawl_get_match_detail(session, match_id)
            temp_path = os.path.join(gettempdir(), f"match_{match_id}_raw.json")
            if not os.path.exists(temp_path):
                print(f"[ERROR] Temp file {temp_path} not found!", flush=True)
                return
            with open(temp_path, "r", encoding="utf-8") as f:
                match_json = json.load(f)
            # Handle extra root key (FotMob match ID as string)
            if len(match_json) == 1 and isinstance(next(iter(match_json.values())), dict):
                match_json = next(iter(match_json.values()))
            print(f"[DEBUG] match_json keys: {list(match_json.keys())}", flush=True)
            content = match_json.get('content', {})
            print(f"[DEBUG] content keys: {list(content.keys())}", flush=True)
            match_facts = content.get('matchFacts', {})
            print(f"[DEBUG] matchFacts keys: {list(match_facts.keys())}", flush=True)
            info_box = match_facts.get('infoBox', {})
            print(f"[DEBUG] infoBox keys: {list(info_box.keys())}", flush=True)
            stadium_json = info_box.get('Stadium', None)
            referee_json = info_box.get('Referee', None)
            match_date_str = info_box.get('Match Date', {}).get('utcTime')
            attendance = info_box.get('Attendance')
            match = session.query(Match).filter(Match.match_id == match_id).first()
            print(f"[DEBUG] DB match object: {match}", flush=True)
            try:
                updated = False
                if match:
                    if stadium_json:
                        print(f"[DEBUG] Saving stadium to DB for match_id={match_id}", flush=True)
                        match.stadium = stadium_json
                        updated = True
                    if referee_json:
                        print(f"[DEBUG] Saving referee to DB for match_id={match_id}", flush=True)
                        match.referee = referee_json
                        updated = True
                    if match_date_str:
                        try:
                            match.match_date = datetime.fromisoformat(match_date_str.replace('Z', '+00:00'))
                            print(f"[DEBUG] Saving match_date to DB for match_id={match_id}: {match_date_str}", flush=True)
                            updated = True
                        except Exception as e:
                            print(f"[WARNING] Could not parse match_date: {match_date_str} ({e})", flush=True)
                    if attendance is not None:
                        print(f"[DEBUG] Saving attendance to DB for match_id={match_id}: {attendance}", flush=True)
                        match.attendance = attendance
                        updated = True
                    if updated:
                        session.add(match)
                        session.commit()
                        print(f"[DEBUG] Saved match info (stadium/referee/date/attendance) for match_id={match_id}", flush=True)
                else:
                    print(f"[DEBUG] Not saving match info: match={match}, stadium_json={stadium_json}", flush=True)
            except Exception as e:
                import traceback
                print(f"[ERROR] Exception while saving match info: {e}", flush=True)
                traceback.print_exc()
            # Step 2: Extract and store
            MatchETL._extract_and_store_shotmap(session, match_id, match_json)
            MatchETL._extract_and_store_events(session, match_id, match_json)
            MatchETL._extract_and_store_h2h(session, match_id, match_json)
            MatchETL._extract_and_store_momentum(session, match_id, match_json)
            MatchETL._extract_and_store_match_players(session, match_id, match_json)
            MatchETL._extract_and_store_team_stats(session, match_id, match_json)
            MatchETL._extract_and_store_comprehensive_team_stats(session, match_id, match_json)
            MatchETL._extract_and_store_player_match_stats(session, match_id, match_json)
            # Store team match summary stats (new combined method)
            MatchETL.extract_and_store_team_match_summary_stats(session, match_id, match_json)
            # Store weather data (move to bottom of extract and store section)
            WeatherETL.extract_and_store_weather_for_match(session, match_id)
            print(f"[DEBUG] match_init completed for match_id={match_id}", flush=True)
        except Exception as e:
            import traceback
            print(f"[ERROR] Exception in match_init: {e}", flush=True)
            traceback.print_exc()

    @staticmethod
    def _extract_and_store_shotmap(session, match_id: int, match_json: dict):
        """
        Extract shotmap data from match JSON and store in match_stats table.
        Args:
            session: SQLAlchemy session
            match_id: internal match ID
            match_json: match data from FotMob
        """
        def_stats_repo = DefStatsRepository(session)
        
        # Get shotmap stat ID
        shotmap_def = StatDefinition.get_shotmap_stat()
        shotmap_stat_id = def_stats_repo.get_stat_id(
            shotmap_def['category'],
            shotmap_def['sub_category'],
            shotmap_def['stat_name']
        )
        
        if not shotmap_stat_id:
            print(f"[WARNING] Shotmap stat ID not found in def_stats table")
            return
        
        print(f"[DEBUG] Found shotmap stat ID: {shotmap_stat_id}")
        
        # Extract all shotmap data from player stats
        all_shots = []
        
        # Look for shotmap data in playerStats section
        player_stats = match_json.get('content', {}).get('playerStats', {})
        if player_stats:
            for player_id, player_data in player_stats.items():
                if isinstance(player_data, dict) and 'shotmap' in player_data:
                    player_shots = player_data.get('shotmap', [])
                    if player_shots:
                        print(f"[DEBUG] Found {len(player_shots)} shots for player {player_id}")
                        all_shots.extend(player_shots)
        
        if not all_shots:
            print(f"[DEBUG] No shotmap data found in match")
            return
        
        print(f"[DEBUG] Total shots found: {len(all_shots)}")
        
        # Check if shotmap data already exists for this match
        existing_shotmap = session.query(MatchStats).filter(
            MatchStats.match_id == match_id,
            MatchStats.stat_id == shotmap_stat_id,
            MatchStats.is_deleted == False
        ).first()
        
        if existing_shotmap:
            print(f"[DEBUG] Updating existing shotmap data")
            existing_shotmap.stat_value = {
                'shots': all_shots,
                'total_shots': len(all_shots),
                'data_source': 'fotmob'
            }
            session.add(existing_shotmap)
        else:
            print(f"[DEBUG] Creating new shotmap data")
            new_shotmap = MatchStats(
                match_id=match_id,
                stat_id=shotmap_stat_id,
                stat_value={
                    'shots': all_shots,
                    'total_shots': len(all_shots),
                    'data_source': 'fotmob'
                }
            )
            session.add(new_shotmap)
        
        session.commit()
        print(f"[DEBUG] Shotmap data stored successfully")

    @staticmethod
    def _extract_and_store_events(session, match_id: int, match_json: dict):
        """
        Extract events data from match JSON and store in match_stats table.
        Args:
            session: SQLAlchemy session
            match_id: internal match ID
            match_json: match data from FotMob
        """
        def_stats_repo = DefStatsRepository(session)
        
        # Get events stat ID using the repository and stat definition
        events_def = StatDefinition.get_events_stat()
        events_stat_id = def_stats_repo.get_stat_id(
            events_def['category'],
            events_def['sub_category'],
            events_def['stat_name']
        )
        if not events_stat_id:
            print(f"[WARNING] Events stat ID not found in def_stats table")
            return
        print(f"[DEBUG] Using events stat ID: {events_stat_id}")
        
        # Extract events data from matchFacts section
        events_data = match_json.get('content', {}).get('matchFacts', {}).get('events', {})
        
        if not events_data:
            print(f"[DEBUG] No events data found in match")
            return
        
        print(f"[DEBUG] Found events data with keys: {list(events_data.keys())}")
        
        # Count total events
        total_events = 0
        for event_type, events in events_data.items():
            if isinstance(events, dict):
                for player_name, player_events in events.items():
                    if isinstance(player_events, list):
                        total_events += len(player_events)
            elif isinstance(events, list):
                total_events += len(events)
        
        print(f"[DEBUG] Total events found: {total_events}")
        
        # Check if events data already exists for this match
        existing_events = session.query(MatchStats).filter(
            MatchStats.match_id == match_id,
            MatchStats.stat_id == events_stat_id,
            MatchStats.is_deleted == False
        ).first()
        
        if existing_events:
            print(f"[DEBUG] Updating existing events data")
            existing_events.stat_value = {
                'events': events_data,
                'total_events': total_events,
                'data_source': 'fotmob'
            }
            session.add(existing_events)
        else:
            print(f"[DEBUG] Creating new events data")
            new_events = MatchStats(
                match_id=match_id,
                stat_id=events_stat_id,
                stat_value={
                    'events': events_data,
                    'total_events': total_events,
                    'data_source': 'fotmob'
                }
            )
            session.add(new_events)
        
        session.commit()
        print(f"[DEBUG] Events data stored successfully")

    @staticmethod
    def _extract_and_store_match_players(session, match_id: int, match_json: dict):
        """
        Extract lineup data from match JSON and store in player, player_mapping, match_player, and match_player_stats tables.
        Args:
            session: SQLAlchemy session
            match_id: internal match ID
            match_json: match data from FotMob
        """
        mapping_repo = MappingRepository(session)
        player_repo = PlayerRepository(session)
        match_player_repo = MatchPlayerRepository(session)
        def_stats_repo = DefStatsRepository(session)
        team_player_repo = TeamPlayerRepository(session)
        player_unavailability_repo = PlayerUnavailabilityRepository(session)
        
        # Get position stat IDs
        position_raw_def = StatDefinition.get_position_raw_stat()
        position_display_def = StatDefinition.get_position_display_stat()
        age_def = StatDefinition.get_age_stat()
        shirt_number_def = StatDefinition.get_shirt_number_stat()
        country_def = StatDefinition.get_country_stat()
        performance_def = StatDefinition.get_performance_stat()
        
        position_raw_stat_id = def_stats_repo.get_stat_id(
            position_raw_def['category'],
            position_raw_def['sub_category'],
            position_raw_def['stat_name']
        )
        position_display_stat_id = def_stats_repo.get_stat_id(
            position_display_def['category'],
            position_display_def['sub_category'],
            position_display_def['stat_name']
        )
        age_stat_id = def_stats_repo.get_stat_id(
            age_def['category'],
            age_def['sub_category'],
            age_def['stat_name']
        )
        shirt_number_stat_id = def_stats_repo.get_stat_id(
            shirt_number_def['category'],
            shirt_number_def['sub_category'],
            shirt_number_def['stat_name']
        )
        country_stat_id = def_stats_repo.get_stat_id(
            country_def['category'],
            country_def['sub_category'],
            country_def['stat_name']
        )
        performance_stat_id = def_stats_repo.get_stat_id(
            performance_def['category'],
            performance_def['sub_category'],
            performance_def['stat_name']
        )
        
        if not all([position_raw_stat_id, position_display_stat_id, age_stat_id, 
                   shirt_number_stat_id, country_stat_id, performance_stat_id]):
            print(f"[WARNING] Some stat IDs not found in def_stats table")
            return
        
        # Get team IDs from match
        match = session.query(Match).filter(Match.match_id == match_id).first()
        if not match:
            print(f"[ERROR] Match {match_id} not found!")
            return
        team_map = {
            'homeTeam': match.home_team_id,
            'awayTeam': match.away_team_id
        }
        lineup = match_json.get('content', {}).get('lineup', {})
        for side in ['homeTeam', 'awayTeam']:
            team_id = team_map.get(side)
            # Process starters
            starters = lineup.get(side, {}).get('starters', [])
            for player in starters:
                player_id = str(player.get('id'))
                player_name = player.get('name')
                position_id = player.get('positionId')
                usual_position_id = player.get('usualPlayingPositionId')
                age = player.get('age')
                shirt_number = player.get('shirtNumber')
                country_name = player.get('countryName')
                country_code = player.get('countryCode')
                performance = player.get('performance', {})
                
                if not player_id:
                    continue
                
                # 1. Check if player mapping exists
                mapping = session.query(PlayerMapping).filter(
                    PlayerMapping.external_id == str(player_id),
                    PlayerMapping.data_source == DATASOURCE.FOTMOB.value
                ).first()
                if mapping:
                    player_id = mapping.player_id
                else:
                    # Try to find player by FotMob external_id in player_mapping
                    existing_mapping = session.query(PlayerMapping).filter(
                        PlayerMapping.external_id == str(player.get('id')),
                        PlayerMapping.data_source == DATASOURCE.FOTMOB.value
                    ).first()
                    if existing_mapping:
                        player_id = existing_mapping.player_id
                    else:
                        # Insert player if not exist
                        player_obj = Player(name=player_name)
                        session.add(player_obj)
                        session.flush()  # get player_id
                        player_id = player_obj.player_id
                        # Insert player mapping with correct external_id as string
                        mapping_repo.create_player_mapping(
                            player_id=player_id,
                            external_id=str(player.get('id')),
                            data_source=DATASOURCE.FOTMOB.value
                        )
                
                # 4. Insert into match_player
                # Determine position_group
                if position_id is not None:
                    position_name = InferredPosition.from_position_id(position_id)
                    position_group = InferredPosition.to_group(position_name)
                else:
                    position_group = "Unknown"
                match_player_repo.create_or_update(
                    match_id=match_id,
                    team_id=team_id,
                    player_id=player_id,
                    type=LineupType.STARTERS.value,
                    position_group=position_group
                )
                
                # 5. Store position data in match_player_stats
                if position_id is not None and usual_position_id is not None:
                    # Create position_raw value as object with position_id and usualPlayingPositionId
                    position_raw_obj = {
                        'position_id': position_id,
                        'usualPlayingPositionId': usual_position_id
                    }
                    
                    # Get inferred position name
                    position_name = InferredPosition.from_position_id(position_id)
                    
                    # Store position_raw stat
                    existing_raw = session.query(MatchPlayerStats).filter(
                        MatchPlayerStats.match_id == match_id,
                        MatchPlayerStats.team_id == team_id,
                        MatchPlayerStats.player_id == player_id,
                        MatchPlayerStats.stat_id == position_raw_stat_id,
                        MatchPlayerStats.is_deleted == False
                    ).first()
                    
                    if existing_raw:
                        existing_raw.stat_value = {
                            'position_raw': position_raw_obj
                        }
                        session.add(existing_raw)
                    else:
                        new_raw = MatchPlayerStats(
                            match_id=match_id,
                            team_id=team_id,
                            player_id=player_id,
                            stat_id=position_raw_stat_id,
                            stat_value={
                                'position_raw': position_raw_obj
                            }
                        )
                        session.add(new_raw)
                    
                    # Store position_display stat
                    existing_name = session.query(MatchPlayerStats).filter(
                        MatchPlayerStats.match_id == match_id,
                        MatchPlayerStats.team_id == team_id,
                        MatchPlayerStats.player_id == player_id,
                        MatchPlayerStats.stat_id == position_display_stat_id,
                        MatchPlayerStats.is_deleted == False
                    ).first()
                    
                    if existing_name:
                        existing_name.stat_value = {
                            'position_display': position_name
                        }
                        session.add(existing_name)
                    else:
                        new_name = MatchPlayerStats(
                            match_id=match_id,
                            team_id=team_id,
                            player_id=player_id,
                            stat_id=position_display_stat_id,
                            stat_value={
                                'position_display': position_name
                            }
                        )
                        session.add(new_name)
                    
                    # Store age stat
                    if age is not None:
                        existing_age = session.query(MatchPlayerStats).filter(
                            MatchPlayerStats.match_id == match_id,
                            MatchPlayerStats.team_id == team_id,
                            MatchPlayerStats.player_id == player_id,
                            MatchPlayerStats.stat_id == age_stat_id,
                            MatchPlayerStats.is_deleted == False
                        ).first()
                        
                        if existing_age:
                            existing_age.stat_value = {'age': age}
                            session.add(existing_age)
                        else:
                            new_age = MatchPlayerStats(
                                match_id=match_id,
                                team_id=team_id,
                                player_id=player_id,
                                stat_id=age_stat_id,
                                stat_value={'age': age}
                            )
                            session.add(new_age)
                    
                    # Store shirt_number stat
                    if shirt_number is not None:
                        existing_shirt = session.query(MatchPlayerStats).filter(
                            MatchPlayerStats.match_id == match_id,
                            MatchPlayerStats.team_id == team_id,
                            MatchPlayerStats.player_id == player_id,
                            MatchPlayerStats.stat_id == shirt_number_stat_id,
                            MatchPlayerStats.is_deleted == False
                        ).first()
                        
                        if existing_shirt:
                            existing_shirt.stat_value = {'shirt_number': shirt_number}
                            session.add(existing_shirt)
                        else:
                            new_shirt = MatchPlayerStats(
                                match_id=match_id,
                                team_id=team_id,
                                player_id=player_id,
                                stat_id=shirt_number_stat_id,
                                stat_value={'shirt_number': shirt_number}
                            )
                            session.add(new_shirt)
                    
                    # Store country stat
                    if country_name and country_code:
                        country_obj = {
                            'country_name': country_name,
                            'country_code': country_code
                        }
                        # Check if player_stats already has this stat for this player
                        existing_country = session.query(PlayerStats).filter(
                            PlayerStats.player_id == player_id,
                            PlayerStats.stat_id == country_stat_id,
                            PlayerStats.is_deleted == False
                        ).first()
                        if not existing_country:
                            new_country = PlayerStats(
                                player_id=player_id,
                                stat_id=country_stat_id,
                                stat_value={'country': country_obj}
                            )
                            session.add(new_country)
                    
                    # Store performance stat
                    if performance:
                        existing_perf = session.query(MatchPlayerStats).filter(
                            MatchPlayerStats.match_id == match_id,
                            MatchPlayerStats.team_id == team_id,
                            MatchPlayerStats.player_id == player_id,
                            MatchPlayerStats.stat_id == performance_stat_id,
                            MatchPlayerStats.is_deleted == False
                        ).first()
                        
                        if existing_perf:
                            existing_perf.stat_value = {'performance': performance}
                            session.add(existing_perf)
                        else:
                            new_perf = MatchPlayerStats(
                                match_id=match_id,
                                team_id=team_id,
                                player_id=player_id,
                                stat_id=performance_stat_id,
                                stat_value={'performance': performance}
                            )
                            session.add(new_perf)
                # Add player to team_player roster
                team_player_repo.add_player_to_team(team_id, player_id)
                # Mark player as available (close any open unavailability)
                player_unavailability_repo.mark_available(player_id, team_id, match.match_date)
            # Process subs
            subs = lineup.get(side, {}).get('subs', [])
            for player in subs:
                player_id = str(player.get('id'))
                player_name = player.get('name')
                position_id = player.get('positionId', None)
                usual_position_id = player.get('usualPlayingPositionId', None)
                age = player.get('age', None)
                shirt_number = player.get('shirtNumber', None)
                country_name = player.get('countryName', None)
                country_code = player.get('countryCode', None)
                performance = player.get('performance', {})
                if not player_id:
                    continue
                mapping = session.query(PlayerMapping).filter(
                    PlayerMapping.external_id == str(player_id),
                    PlayerMapping.data_source == DATASOURCE.FOTMOB.value
                ).first()
                if mapping:
                    player_id = mapping.player_id
                else:
                    player_obj = player_repo.get_by_name(player_name)
                    if not player_obj:
                        player_obj = Player(name=player_name)
                        session.add(player_obj)
                        session.flush()
                    player_id = player_obj.player_id
                    mapping_repo.create_player_mapping(
                        player_id=player_id,
                        external_id=str(player.get('id')),
                        data_source=DATASOURCE.FOTMOB.value
                    )
                # 4. Insert into match_player
                # Determine position_group
                if position_id is not None:
                    position_name = InferredPosition.from_position_id(position_id)
                    position_group = InferredPosition.to_group(position_name)
                else:
                    position_group = "Unknown"
                match_player_repo.create_or_update(
                    match_id=match_id,
                    team_id=team_id,
                    player_id=player_id,
                    type=LineupType.SUBS.value,
                    position_group=position_group
                )
                # Store country stat for subs
                if country_name and country_code:
                    country_obj = {
                        'country_name': country_name,
                        'country_code': country_code
                    }
                    existing_country = session.query(PlayerStats).filter(
                        PlayerStats.player_id == player_id,
                        PlayerStats.stat_id == country_stat_id,
                        PlayerStats.is_deleted == False
                    ).first()
                    if not existing_country:
                        new_country = PlayerStats(
                            player_id=player_id,
                            stat_id=country_stat_id,
                            stat_value={'country': country_obj}
                        )
                        session.add(new_country)
                # Store performance stat for subs
                if performance:
                    existing_perf = session.query(MatchPlayerStats).filter(
                        MatchPlayerStats.match_id == match_id,
                        MatchPlayerStats.team_id == team_id,
                        MatchPlayerStats.player_id == player_id,
                        MatchPlayerStats.stat_id == performance_stat_id,
                        MatchPlayerStats.is_deleted == False
                    ).first()
                    if existing_perf:
                        existing_perf.stat_value = {'performance': performance}
                        session.add(existing_perf)
                    else:
                        new_perf = MatchPlayerStats(
                            match_id=match_id,
                            team_id=team_id,
                            player_id=player_id,
                            stat_id=performance_stat_id,
                            stat_value={'performance': performance}
                        )
                        session.add(new_perf)
                # Add player to team_player roster
                team_player_repo.add_player_to_team(team_id, player_id)
                # Mark player as available (close any open unavailability)
                player_unavailability_repo.mark_available(player_id, team_id, match.match_date)
            # Process unavailable
            unavailable = lineup.get(side, {}).get('unavailable', [])
            for player in unavailable:
                player_id = str(player.get('id'))
                player_name = player.get('name')
                age = player.get('age', None)
                shirt_number = player.get('shirtNumber', None)
                country_name = player.get('countryName', None)
                country_code = player.get('countryCode', None)
                # Extract unavailability data
                unavailability_data = player.get('unavailability', {})
                remark_data = None
                if unavailability_data:
                    remark_data = {
                        'unavailability': {
                            'injury_id': unavailability_data.get('injuryId'),
                            'type': unavailability_data.get('type'),
                            'expected_return': unavailability_data.get('expectedReturn')
                        }
                    }
                if not player_id:
                    continue
                mapping = session.query(PlayerMapping).filter(
                    PlayerMapping.external_id == str(player_id),
                    PlayerMapping.data_source == DATASOURCE.FOTMOB.value
                ).first()
                if mapping:
                    player_id = mapping.player_id
                else:
                    player_obj = player_repo.get_by_name(player_name)
                    if not player_obj:
                        player_obj = Player(name=player_name)
                        session.add(player_obj)
                        session.flush()
                    player_id = player_obj.player_id
                    mapping_repo.create_player_mapping(
                        player_id=player_id,
                        external_id=str(player.get('id')),
                        data_source=DATASOURCE.FOTMOB.value
                    )
                match_player_repo.create_or_update(
                    match_id=match_id,
                    team_id=team_id,
                    player_id=player_id,
                    type=LineupType.UNAVAILABLE.value,
                    remark=remark_data
                )
                # Store country stat for unavailable
                if country_name and country_code:
                    country_obj = {
                        'country_name': country_name,
                        'country_code': country_code
                    }
                    existing_country = session.query(PlayerStats).filter(
                        PlayerStats.player_id == player_id,
                        PlayerStats.stat_id == country_stat_id,
                        PlayerStats.is_deleted == False
                    ).first()
                    if not existing_country:
                        new_country = PlayerStats(
                            player_id=player_id,
                            stat_id=country_stat_id,
                            stat_value={'country': country_obj}
                        )
                        session.add(new_country)
                # Add player to team_player roster
                team_player_repo.add_player_to_team(team_id, player_id)
                # Mark player as unavailable (open a new unavailability if not already open)
                player_unavailability_repo.mark_unavailable(
                    player_id=player_id,
                    team_id=team_id,
                    start_date=match.match_date,
                    reason=unavailability_data.get('type') if unavailability_data else None,
                    details=remark_data
                )
        
        session.commit()
        print(f"[DEBUG] match_player and position data stored successfully for match_id={match_id}")

    @staticmethod
    def _extract_and_store_team_stats(session, match_id: int, match_json: dict):
        """
        Extract team stats (coach, rating, formation) from match JSON and store in match_team_stats table.
        Args:
            session: SQLAlchemy session
            match_id: internal match ID
            match_json: match data from FotMob
        """
        from soccerdata.database.models import MatchTeamStats
        
        def_stats_repo = DefStatsRepository(session)
        
        # Get stat definitions
        coach_def = StatDefinition.get_team_coach_stat()
        rating_def = StatDefinition.get_team_rating_stat()
        formation_def = StatDefinition.get_team_formation_stat()
        average_starter_age_def = StatDefinition.get_team_average_starter_age_stat()
        
        # Get stat IDs
        coach_stat_id = def_stats_repo.get_stat_id(
            coach_def['category'],
            coach_def['sub_category'],
            coach_def['stat_name']
        )
        rating_stat_id = def_stats_repo.get_stat_id(
            rating_def['category'],
            rating_def['sub_category'],
            rating_def['stat_name']
        )
        formation_stat_id = def_stats_repo.get_stat_id(
            formation_def['category'],
            formation_def['sub_category'],
            formation_def['stat_name']
        )
        average_starter_age_stat_id = def_stats_repo.get_stat_id(
            average_starter_age_def['category'],
            average_starter_age_def['sub_category'],
            average_starter_age_def['stat_name']
        )
        
        if not all([coach_stat_id, rating_stat_id, formation_stat_id, average_starter_age_stat_id]):
            print(f"[WARNING] Some team stat IDs not found in def_stats table")
            return
        
        # Get team IDs from match
        match = session.query(Match).filter(Match.match_id == match_id).first()
        if not match:
            print(f"[ERROR] Match {match_id} not found!")
            return
        
        team_map = {
            'homeTeam': match.home_team_id,
            'awayTeam': match.away_team_id
        }
        
        lineup = match_json.get('content', {}).get('lineup', {})
        
        for team_type, team_id in team_map.items():
            team_data = lineup.get(team_type, {})
            if not team_data:
                continue
                
            print(f"[DEBUG] Processing {team_type} (team_id: {team_id})")
            
            # Extract coach information
            coach_data = team_data.get('coach', {})
            if coach_data:
                coach_obj = {
                    'id': coach_data.get('id'),
                    'name': coach_data.get('name'),
                    'age': coach_data.get('age'),
                    'country_name': coach_data.get('countryName'),
                    'country_code': coach_data.get('countryCode'),
                    'first_name': coach_data.get('firstName'),
                    'last_name': coach_data.get('lastName'),
                    'primary_team_id': coach_data.get('primaryTeamId'),
                    'primary_team_name': coach_data.get('primaryTeamName')
                }
                
                # Store coach stat
                existing_coach = session.query(MatchTeamStats).filter(
                    MatchTeamStats.match_id == match_id,
                    MatchTeamStats.team_id == team_id,
                    MatchTeamStats.stat_id == coach_stat_id,
                    MatchTeamStats.is_deleted == False
                ).first()
                
                if existing_coach:
                    existing_coach.stat_value = {'coach': coach_obj}
                    session.add(existing_coach)
                else:
                    new_coach = MatchTeamStats(
                        match_id=match_id,
                        team_id=team_id,
                        stat_id=coach_stat_id,
                        stat_value={'coach': coach_obj}
                    )
                    session.add(new_coach)
            
            # Extract rating
            rating = team_data.get('rating')
            if rating is not None:
                # Store rating stat
                existing_rating = session.query(MatchTeamStats).filter(
                    MatchTeamStats.match_id == match_id,
                    MatchTeamStats.team_id == team_id,
                    MatchTeamStats.stat_id == rating_stat_id,
                    MatchTeamStats.is_deleted == False
                ).first()
                
                if existing_rating:
                    existing_rating.stat_value = {'rating': rating}
                    session.add(existing_rating)
                else:
                    new_rating = MatchTeamStats(
                        match_id=match_id,
                        team_id=team_id,
                        stat_id=rating_stat_id,
                        stat_value={'rating': rating}
                    )
                    session.add(new_rating)
            
            # Extract formation
            formation = team_data.get('formation')
            if formation:
                # Store formation stat
                existing_formation = session.query(MatchTeamStats).filter(
                    MatchTeamStats.match_id == match_id,
                    MatchTeamStats.team_id == team_id,
                    MatchTeamStats.stat_id == formation_stat_id,
                    MatchTeamStats.is_deleted == False
                ).first()
                
                if existing_formation:
                    existing_formation.stat_value = {'formation': formation}
                    session.add(existing_formation)
                else:
                    new_formation = MatchTeamStats(
                        match_id=match_id,
                        team_id=team_id,
                        stat_id=formation_stat_id,
                        stat_value={'formation': formation}
                    )
                    session.add(new_formation)
            
            # Extract average starter age
            average_starter_age = team_data.get('averageStarterAge')
            if average_starter_age is not None:
                # Store average starter age stat
                existing_age = session.query(MatchTeamStats).filter(
                    MatchTeamStats.match_id == match_id,
                    MatchTeamStats.team_id == team_id,
                    MatchTeamStats.stat_id == average_starter_age_stat_id,
                    MatchTeamStats.is_deleted == False
                ).first()
                
                if existing_age:
                    existing_age.stat_value = {'average_starter_age': average_starter_age}
                    session.add(existing_age)
                else:
                    new_age = MatchTeamStats(
                        match_id=match_id,
                        team_id=team_id,
                        stat_id=average_starter_age_stat_id,
                        stat_value={'average_starter_age': average_starter_age}
                    )
                    session.add(new_age)
        
        session.commit()
        print(f"[DEBUG] Team stats stored successfully")

    @staticmethod
    def _extract_team_performance_stats(content):
        """
        Extract performance stats for both home and away teams from the match content.
        Returns a dict: {team_id: performance_stats_dict}
        """
        lineup = content.get('lineup', {})
        stats = {}
        for side in ['homeTeam', 'awayTeam']:
            team = lineup.get(side, {})
            team_id = team.get('id')
            if not team_id:
                continue
            # Extract whatever stats are needed for the team
            performance = team.get('performance', {})
            stats[team_id] = performance
        return stats

    @staticmethod
    def extract_and_store_team_match_summary_stats(session, match_id: int, match_json: dict):
        """
        Extract and store comprehensive team match summary stats for both teams in match_team_stats table.
        Args:
            session: SQLAlchemy session
            match_id: internal match ID
            match_json: match data from FotMob
        """
        def_stats_repo = DefStatsRepository(session)
        match_team_stats_repo = MatchTeamStatsRepository(session)
        stat_def = StatDefinition.get_team_match_summary_stat()
        stat_id = def_stats_repo.get_stat_id(stat_def['category'], stat_def['sub_category'], stat_def['stat_name'])
        if not stat_id:
            print(f"[ERROR] Stat definition for team_match_summary_stat not found!")
            return
        # Get internal team IDs from match
        match = session.query(Match).filter(Match.match_id == match_id).first()
        if not match:
            print(f"[ERROR] Match {match_id} not found!")
            return
        team_map = {
            'homeTeam': match.home_team_id,
            'awayTeam': match.away_team_id
        }
        lineup = match_json.get('content', {}).get('lineup', {})
        content = match_json.get('content', {})
        performance_stats_dict = MatchETL._extract_team_performance_stats(content)
        for team_side, team_id in team_map.items():
            team_data = lineup.get(team_side, {})
            if not team_data or not team_id:
                continue
            performance_stats = performance_stats_dict.get(team_data.get('id')) or {}
            formation = team_data.get('formation')
            rating = team_data.get('rating')
            recent_form = MatchETL._extract_team_recent_form(content, team_side)
            match_events = MatchETL._extract_team_match_events(content, team_id)
            insights = MatchETL._extract_team_insights(content, team_id)
            shot_stats = MatchETL._extract_team_shot_stats(content, team_id)
            momentum_data = MatchETL._extract_team_momentum(content, team_side)
            match_context = MatchETL._extract_team_match_context(content, team_side)
            lineup_summary = MatchETL._extract_team_lineup_summary(team_data)
            team_match_summary = {
                'performance_stats': performance_stats,
                'formation': formation,
                'rating': rating,
                'recent_form': recent_form,
                'match_events': match_events,
                'insights': insights,
                'shot_stats': shot_stats,
                'momentum_data': momentum_data,
                'match_context': match_context,
                'lineup_summary': lineup_summary
            }
            team_match_summary = {k: v for k, v in team_match_summary.items() if v is not None}
            match_team_stats_repo.create_or_update(
                match_id=match_id,
                team_id=team_id,
                stat_id=stat_id,
                stat_value=team_match_summary
            )
            print(f"[DEBUG] Stored team match summary stat for match {match_id}, team {team_id}")
        session.commit()
        print(f"[DEBUG] Team match summary stats stored successfully for match_id={match_id}")

    @staticmethod
    def _extract_team_recent_form(content: dict, team_side: str) -> list:
        """Extract team recent form from content->matchFacts->teamForm."""
        team_form = content.get('matchFacts', {}).get('teamForm', [])
        if not team_form or len(team_form) < 2:
            return None
        # team_side: 'home' -> index 0, 'away' -> index 1
        team_index = 0 if team_side == 'home' else 1
        form_matches = team_form[team_index] if team_index < len(team_form) else []
        if not form_matches:
            return None
        # Simplify form data to essential info
        simplified_form = []
        for match in form_matches:
            simplified_match = {
                'result': match.get('resultString'),
                'score': match.get('score'),
                'opponent': match.get('away', {}).get('name') if match.get('home', {}).get('isOurTeam') else match.get('home', {}).get('name'),
                'date': match.get('date', {}).get('utcTime'),
                'is_home': match.get('home', {}).get('isOurTeam', False)
            }
            simplified_form.append(simplified_match)
        return simplified_form
    
    @staticmethod
    def _extract_team_match_events(content: dict, team_id: int) -> list:
        """Extract team-specific match events from content->matchFacts->events."""
        events = content.get('matchFacts', {}).get('events', {}).get('events', [])
        if not events:
            return None
        team_events = []
        for event in events:
            event_team_id = event.get('teamId')
            if event_team_id == team_id:
                simplified_event = {
                    'type': event.get('type'),
                    'minute': event.get('minute'),
                    'player_name': event.get('playerName'),
                    'description': event.get('description'),
                    'event_id': event.get('eventId')
                }
                team_events.append(simplified_event)
        return team_events if team_events else None
    
    @staticmethod
    def _extract_team_insights(content: dict, team_id: int) -> list:
        """Extract team-specific insights from content->matchFacts->insights."""
        insights = content.get('matchFacts', {}).get('insights', [])
        if not insights:
            return None
        team_insights = []
        for insight in insights:
            if insight.get('type') == 'team' and insight.get('teamId') == team_id:
                simplified_insight = {
                    'text': insight.get('text'),
                    'priority': insight.get('priority'),
                    'localized_text_id': insight.get('localizedTextId')
                }
                team_insights.append(simplified_insight)
        return team_insights if team_insights else None
    
    @staticmethod
    def _extract_team_shot_stats(content: dict, team_id: int) -> dict:
        """Extract team shot statistics from content->shotmap."""
        shotmap = content.get('shotmap', {})
        if not shotmap:
            return None
        shots = shotmap.get('shots', [])
        if not shots:
            return None
        team_shots = [s for s in shots if s.get('teamId') == team_id]
        if not team_shots:
            return None
        # Calculate shot statistics
        total_shots = len(team_shots)
        shots_on_target = len([s for s in team_shots if s.get('isOnTarget', False)])
        shots_off_target = len([s for s in team_shots if not s.get('isOnTarget', False)])
        goals = len([s for s in team_shots if s.get('eventType') == 'Goal'])
        expected_goals = sum(s.get('expectedGoals', 0) for s in team_shots)
        shot_stats = {
            'total_shots': total_shots,
            'shots_on_target': shots_on_target,
            'shots_off_target': shots_off_target,
            'goals': goals,
            'expected_goals': round(expected_goals, 3),
            'shot_accuracy': round(shots_on_target / total_shots * 100, 1) if total_shots > 0 else 0
        }
        return shot_stats
    
    @staticmethod
    def _extract_team_momentum(content: dict, team_side: str) -> list:
        """Extract team momentum data from content->matchFacts->momentum."""
        momentum = content.get('matchFacts', {}).get('momentum', {})
        if not momentum:
            return None
        main_data = momentum.get('main', {})
        if not main_data:
            return None
        data_points = main_data.get('data', [])
        if not data_points:
            return None
        # Simplify momentum data (keep every 10th point to reduce size)
        simplified_momentum = []
        for i, point in enumerate(data_points):
            if i % 10 == 0:  # Sample every 10th point
                simplified_point = {
                    'minute': point.get('minute'),
                    'value': point.get('value')
                }
                simplified_momentum.append(simplified_point)
        return simplified_momentum if simplified_momentum else None
    
    @staticmethod
    def _extract_team_match_context(content: dict, team_side: str) -> dict:
        """Extract team match context from content->matchFacts->infoBox."""
        info_box = content.get('matchFacts', {}).get('infoBox', {})
        if not info_box:
            return None
        # Save the entire Stadium JSON
        match_context = {
            'tournament': info_box.get('Tournament', {}).get('leagueName'),
            'round': info_box.get('Tournament', {}).get('roundName'),
            'stadium': info_box.get('Stadium', {}),
            'attendance': info_box.get('Attendance'),
            'referee': info_box.get('Referee', {}).get('text'),
            'match_date': info_box.get('Match Date', {}).get('utcTime')
        }
        # Clean up None values
        match_context = {k: v for k, v in match_context.items() if v is not None}
        return match_context if match_context else None
    
    @staticmethod
    def _extract_team_lineup_summary(team_data: dict) -> dict:
        """Extract team lineup summary from content->lineup."""
        if not team_data:
            return None
        starters = team_data.get('starters', [])
        subs = team_data.get('subs', [])
        # Use averageStarterAge if available, else calculate
        if 'averageStarterAge' in team_data and team_data['averageStarterAge'] is not None:
            average_age = team_data['averageStarterAge']
        else:
            average_age = MatchETL._calculate_average_age(starters + subs)
        lineup_summary = {
            'total_players': len(starters) + len(subs),
            'starters_count': len(starters),
            'subs_count': len(subs),
            'average_age': average_age,
            'captain': next((p.get('name') for p in starters if p.get('isCaptain')), None),
            'player_of_match': next((p.get('name') for p in starters + subs 
                                   if p.get('performance', {}).get('playerOfTheMatch')), None)
        }
        return lineup_summary
    
    @staticmethod
    def _calculate_average_age(players: list) -> float:
        """Calculate average age of players."""
        if not players:
            return None
        
        ages = [p.get('age') for p in players if p.get('age') is not None]
        if not ages:
            return None
        
        return round(sum(ages) / len(ages), 1) 