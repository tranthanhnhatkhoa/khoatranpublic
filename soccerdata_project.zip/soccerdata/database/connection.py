"""Database connection management for soccerdata."""

import os
from typing import Optional
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.pool import StaticPool


class DatabaseConnection:
    """Manages database connections and sessions."""
    
    def __init__(self, database_url: Optional[str] = None):
        """Initialize database connection.
        
        Args:
            database_url: SQLAlchemy database URL. If None, uses default PostgreSQL.
        """
        if database_url is None:
            # Default to PostgreSQL with user's credentials
            database_url = "postgresql://khoatran@localhost:5432/soccerdata"
        
        self.database_url = database_url
        self.engine = None
        self.SessionLocal = None
        self._create_engine()
    
    def _create_engine(self):
        """Create SQLAlchemy engine with appropriate configuration."""
        if self.database_url.startswith("sqlite"):
            # SQLite specific configuration
            self.engine = create_engine(
                self.database_url,
                connect_args={"check_same_thread": False},
                poolclass=StaticPool,
                echo=False  # Set to True for SQL debugging
            )
        else:
            # PostgreSQL/MySQL configuration
            self.engine = create_engine(
                self.database_url,
                echo=True,  # Set to True to see SQL queries
                pool_pre_ping=True
            )
        
        self.SessionLocal = sessionmaker(
            autocommit=False,
            autoflush=False,
            bind=self.engine
        )
    
    def get_session(self) -> Session:
        """Get a new database session.
        
        Returns:
            SQLAlchemy session
        """
        return self.SessionLocal()
    
    def create_tables(self):
        """Create all tables defined in models."""
        from .models import Base
        Base.metadata.create_all(bind=self.engine)
    
    def drop_tables(self):
        """Drop all tables. Use with caution!"""
        from .models import Base
        Base.metadata.drop_all(bind=self.engine)
    
    def close(self):
        """Close the database connection."""
        if self.engine:
            self.engine.dispose()


# Global database connection instance
_db_connection: Optional[DatabaseConnection] = None


def get_database_connection() -> DatabaseConnection:
    """Get the global database connection instance.
    
    Returns:
        DatabaseConnection instance
    """
    global _db_connection
    if _db_connection is None:
        _db_connection = DatabaseConnection()
    return _db_connection


def get_session() -> Session:
    """Get a database session from the global connection.
    
    Returns:
        SQLAlchemy session
    """
    return get_database_connection().get_session() 