"""Repository classes for database operations."""

from typing import List, Optional
from datetime import datetime
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, desc, func
from .models import (
    League, Season, Team, Player, Match,
    MatchMapping, TeamMapping, PlayerMapping, LeagueMapping, SeasonMapping, TeamStanding, DefStats, MatchPlayer, TeamPlayer, PlayerUnavailability, MatchTeamStats, MatchPlayerStats
)
from soccerdata._config import DATASOURCE
from .stat_enums import LineupType


class BaseRepository:
    """Base repository with common CRUD operations."""

    def __init__(self, session: Session):
        self.session = session

    def get_by_id(self, model_class, id_value):
        """Get entity by ID."""
        return self.session.query(model_class).filter(
            model_class.__table__.primary_key.columns[0] == id_value
        ).first()

    def get_all(self, model_class, limit: Optional[int] = None):
        """Get all entities."""
        query = self.session.query(model_class)
        if limit:
            query = query.limit(limit)
        return query.all()

    def create(self, entity):
        """Create a new entity."""
        self.session.add(entity)
        return entity

    def update(self, entity):
        """Update an existing entity."""
        entity.updated_at = datetime.utcnow()
        self.session.add(entity)
        return entity

    def delete(self, entity):
        """Hard delete an entity."""
        self.session.delete(entity)

class LeagueRepository(BaseRepository):
    """Repository for League operations."""

    def get_by_name(self, name: str) -> Optional[League]:
        """Get league by name."""
        return self.session.query(League).filter(League.name == name).first()

    def get_external_league_code(self, league_id: int, data_source: str) -> Optional[str]:
        mapping = self.session.query(LeagueMapping).filter(
            and_(
                LeagueMapping.league_id == league_id,
                func.lower(LeagueMapping.data_source) == data_source.lower()
            )
        ).first()
        return mapping.source_league_code if mapping else None


class SeasonRepository(BaseRepository):
    """Repository for Season operations."""

    def get_by_name(self, name: str) -> Optional[Season]:
        """Get season by name."""
        return self.session.query(Season).filter(Season.name == name).first()

    def get_external_season_code(self, season_id: int, data_source: str) -> Optional[str]:
        mapping = self.session.query(SeasonMapping).filter(
            and_(
                SeasonMapping.season_id == season_id,
                func.lower(SeasonMapping.data_source) == data_source.lower()
            )
        ).first()
        return mapping.source_season_code if mapping else None


class TeamRepository(BaseRepository):
    """Repository for Team operations."""

    def get_by_name(self, name: str) -> Optional[Team]:
        """Get team by name."""
        return self.session.query(Team).filter(Team.name == name).first()

    def create_or_update(self, name: str, short_name: Optional[str] = None) -> Team:
        """Create a new team or update an existing one if short_name differs."""
        team = self.get_by_name(name)
        if team:
            if short_name and team.short_name != short_name:
                team.short_name = short_name
                return self.update(team)
        else:
            team = Team(name=name, short_name=short_name)
            return self.create(team)
        return team


class MatchRepository(BaseRepository):
    """Repository for Match operations."""

    def get_by_teams_and_date(self, home_team_id: int, away_team_id: int, match_date: datetime) -> Optional[Match]:
        """Get match by teams and date."""
        return self.session.query(Match).filter(
            and_(
                Match.home_team_id == home_team_id,
                Match.away_team_id == away_team_id,
                Match.match_date == match_date
            )
        ).first()

    def create_or_update(
        self,
        league_id: int,
        season_id: int,
        home_team_id: int,
        away_team_id: int,
        match_date: datetime,
        **kwargs
    ) -> Match:
        """Create a new match or update an existing one."""
        match = self.get_by_teams_and_date(home_team_id, away_team_id, match_date)
        if match:
            changed = False
            for key, value in kwargs.items():
                if hasattr(match, key) and getattr(match, key) != value:
                    setattr(match, key, value)
                    changed = True
            if changed:
                return self.update(match)
        else:
            match = Match(
                league_id=league_id,
                season_id=season_id,
                home_team_id=home_team_id,
                away_team_id=away_team_id,
                match_date=match_date,
                **kwargs
            )
            return self.create(match)
        return match


class MappingRepository(BaseRepository):
    """Repository for mapping operations."""

    def get_team_by_external_id(self, external_id: str, data_source: str) -> Optional[Team]:
        """Get a team by its external ID and data source."""
        mapping = self.session.query(TeamMapping).filter(
            and_(
                TeamMapping.external_id == external_id,
                func.lower(TeamMapping.data_source) == data_source.lower()
            )
        ).first()
        return mapping.team if mapping else None

    def create_team_mapping(self, team_id: int, external_id: str, data_source: str, pageUrl: Optional[str] = None) -> TeamMapping:
        """Create a new team mapping."""
        mapping = TeamMapping(
            team_id=team_id,
            external_id=external_id,
            data_source=data_source,
            pageUrl=pageUrl
        )
        return self.create(mapping)

    def create_match_mapping(self, match_id: int, external_id: str, data_source: str, url: Optional[str] = None) -> MatchMapping:
        """Create a new match mapping."""
        mapping = MatchMapping(
            match_id=match_id,
            external_id=external_id,
            data_source=data_source,
            url=url
        )
        return self.create(mapping)

    def get_external_id_from_match_id(self, match_id: int, data_source: str) -> Optional[str]:
        """Get the external match ID for a given internal match_id and data source."""
        mapping = self.session.query(MatchMapping).filter(
            and_(
                MatchMapping.match_id == match_id,
                func.lower(MatchMapping.data_source) == data_source.lower()
            )
        ).first()
        return mapping.external_id if mapping else None

    def get_fotmob_external_id_from_match_id(self, match_id: int) -> Optional[str]:
        """Get the external FotMob match ID for a given internal match_id."""
        return self.get_external_id_from_match_id(match_id, DATASOURCE.FOTMOB.value)

    def create_player_mapping(self, player_id: int, external_id: str, data_source: str) -> PlayerMapping:
        """Create a new player mapping."""
        mapping = PlayerMapping(
            player_id=player_id,
            external_id=external_id,
            data_source=data_source
        )
        return self.create(mapping)

class PlayerRepository(BaseRepository):
    """Repository for Player operations."""
    def get_by_name(self, name: str) -> Optional[Player]:
        """Get player by name."""
        return self.session.query(Player).filter(Player.name == name).first()

class DefStatsRepository(BaseRepository):
    """Repository for DefStats operations."""

    def get_stat_id(self, stat_category: str, stat_sub_category: str, stat_name: str) -> Optional[int]:
        """Get stat_id by category, sub_category, and stat_name."""
        stat = self.session.query(DefStats).filter(
            and_(
                DefStats.stat_category == stat_category,
                DefStats.stat_sub_category == stat_sub_category,
                DefStats.stat_name == stat_name,
                DefStats.is_deleted == False
            )
        ).first()
        return stat.stat_id if stat else None

    def get_stat_by_id(self, stat_id: int) -> Optional[DefStats]:
        """Get stat by ID."""
        return self.session.query(DefStats).filter(
            and_(
                DefStats.stat_id == stat_id,
                DefStats.is_deleted == False
            )
        ).first()

    def get_stats_by_category(self, stat_category: str) -> List[DefStats]:
        """Get all stats for a given category."""
        return self.session.query(DefStats).filter(
            and_(
                DefStats.stat_category == stat_category,
                DefStats.is_deleted == False
            )
        ).all()

    def get_stats_by_category_and_subcategory(self, stat_category: str, stat_sub_category: str) -> List[DefStats]:
        """Get all stats for a given category and sub-category."""
        return self.session.query(DefStats).filter(
            and_(
                DefStats.stat_category == stat_category,
                DefStats.stat_sub_category == stat_sub_category,
                DefStats.is_deleted == False
            )
        ).all()

    def create_stat(self, stat_name: str, stat_category: str, stat_sub_category: str, 
                   datasource: Optional[str] = None, description: Optional[str] = None) -> DefStats:
        """Create a new stat definition."""
        stat = DefStats(
            stat_name=stat_name,
            stat_category=stat_category,
            stat_sub_category=stat_sub_category,
            datasource=datasource,
            description=description
        )
        return self.create(stat)

class MatchPlayerRepository(BaseRepository):
    """Repository for MatchPlayer operations."""
    
    VALID_TYPES = [LineupType.STARTERS.value, LineupType.SUBS.value, LineupType.UNAVAILABLE.value]
    
    def get_by_match_team_player(self, match_id: int, team_id: int, player_id: int):
        return self.session.query(MatchPlayer).filter(
            MatchPlayer.match_id == match_id,
            MatchPlayer.team_id == team_id,
            MatchPlayer.player_id == player_id
        ).first()

    def create_or_update(self, match_id: int, team_id: int, player_id: int, **kwargs):
        match_player = self.get_by_match_team_player(match_id, team_id, player_id)
        if match_player:
            changed = False
            for key, value in kwargs.items():
                if hasattr(match_player, key) and getattr(match_player, key) != value:
                    setattr(match_player, key, value)
                    changed = True
            if changed:
                return self.update(match_player)
        else:
            match_player = MatchPlayer(
                match_id=match_id,
                team_id=team_id,
                player_id=player_id,
                **kwargs
            )
            return self.create(match_player)
        return match_player
    
    def get_by_match_and_type(self, match_id: int, type: LineupType) -> List[MatchPlayer]:
        """Get all players of a specific type for a match."""
        if type.value not in self.VALID_TYPES:
            raise ValueError(f"Invalid type '{type}'. Must be one of: {self.VALID_TYPES}")
        
        return self.session.query(MatchPlayer).filter(
            MatchPlayer.match_id == match_id,
            MatchPlayer.type == type.value,
            MatchPlayer.is_deleted == False
        ).all()
    
    def get_by_match_team_and_type(self, match_id: int, team_id: int, type: LineupType) -> List[MatchPlayer]:
        """Get all players of a specific type for a team in a match."""
        if type.value not in self.VALID_TYPES:
            raise ValueError(f"Invalid type '{type}'. Must be one of: {self.VALID_TYPES}")
        
        return self.session.query(MatchPlayer).filter(
            MatchPlayer.match_id == match_id,
            MatchPlayer.team_id == team_id,
            MatchPlayer.type == type.value,
            MatchPlayer.is_deleted == False
        ).all()
    
    def update_player_type(self, match_id: int, team_id: int, player_id: int, type: LineupType) -> MatchPlayer:
        """Update the type of a specific player in a match."""
        if type.value not in self.VALID_TYPES:
            raise ValueError(f"Invalid type '{type}'. Must be one of: {self.VALID_TYPES}")
        
        match_player = self.get_by_match_team_player(match_id, team_id, player_id)
        if match_player:
            match_player.type = type.value
            return self.update(match_player)
        else:
            raise ValueError(f"MatchPlayer not found for match_id={match_id}, team_id={team_id}, player_id={player_id}") 

class TeamPlayerRepository(BaseRepository):
    """Repository for TeamPlayer operations."""
    def get_by_team_and_player(self, team_id: int, player_id: int):
        return self.session.query(TeamPlayer).filter(
            TeamPlayer.team_id == team_id,
            TeamPlayer.player_id == player_id,
            TeamPlayer.is_deleted == False
        ).first()

    def add_player_to_team(self, team_id: int, player_id: int):
        existing = self.get_by_team_and_player(team_id, player_id)
        if existing:
            return existing
        new_team_player = TeamPlayer(
            team_id=team_id,
            player_id=player_id
        )
        self.session.add(new_team_player)
        self.session.commit()
        return new_team_player

    def remove_player_from_team(self, team_id: int, player_id: int):
        existing = self.get_by_team_and_player(team_id, player_id)
        if existing:
            existing.is_deleted = True
            self.session.add(existing)
            self.session.commit()
            return True
        return False 

class PlayerUnavailabilityRepository(BaseRepository):
    """Repository for PlayerUnavailability operations."""

    def get_current_unavailability(self, team_id: int = None) -> List[PlayerUnavailability]:
        """Get all currently unavailable players (end_date is NULL). Optionally filter by team."""
        query = self.session.query(PlayerUnavailability).filter(PlayerUnavailability.end_date == None)
        if team_id is not None:
            query = query.filter(PlayerUnavailability.team_id == team_id)
        return query.all()

    def get_unavailability_for_player(self, player_id: int) -> List[PlayerUnavailability]:
        """Get all unavailability records for a player."""
        return self.session.query(PlayerUnavailability).filter(PlayerUnavailability.player_id == player_id).all()

    def mark_unavailable(self, player_id: int, team_id: int, start_date, reason: str = None, details: dict = None) -> PlayerUnavailability:
        """Mark a player as unavailable (if not already open)."""
        open_record = self.session.query(PlayerUnavailability).filter(
            PlayerUnavailability.player_id == player_id,
            PlayerUnavailability.team_id == team_id,
            PlayerUnavailability.end_date == None
        ).first()
        if open_record:
            return open_record
        record = PlayerUnavailability(
            player_id=player_id,
            team_id=team_id,
            start_date=start_date,
            reason=reason,
            details=details
        )
        self.session.add(record)
        return record

    def mark_available(self, player_id: int, team_id: int, end_date) -> Optional[PlayerUnavailability]:
        """Mark a player as available (close open unavailability record)."""
        open_record = self.session.query(PlayerUnavailability).filter(
            PlayerUnavailability.player_id == player_id,
            PlayerUnavailability.team_id == team_id,
            PlayerUnavailability.end_date == None
        ).first()
        if open_record:
            open_record.end_date = end_date
            self.session.add(open_record)
            return open_record
        return None 

class MatchTeamStatsRepository(BaseRepository):
    """Repository for MatchTeamStats operations."""
    
    def get_by_match_team_stat(self, match_id: int, team_id: int, stat_id: int):
        """Get match team stat by match_id, team_id, and stat_id."""
        return self.session.query(MatchTeamStats).filter(
            MatchTeamStats.match_id == match_id,
            MatchTeamStats.team_id == team_id,
            MatchTeamStats.stat_id == stat_id,
            MatchTeamStats.is_deleted == False
        ).first()
    
    def create_or_update(self, match_id: int, team_id: int, stat_id: int, stat_value: dict):
        """Create or update a match team stat."""
        match_team_stat = self.get_by_match_team_stat(match_id, team_id, stat_id)
        if match_team_stat:
            match_team_stat.stat_value = stat_value
            return self.update(match_team_stat)
        else:
            match_team_stat = MatchTeamStats(
                match_id=match_id,
                team_id=team_id,
                stat_id=stat_id,
                stat_value=stat_value
            )
            return self.create(match_team_stat)
    
    def get_by_match_and_team(self, match_id: int, team_id: int) -> List[MatchTeamStats]:
        """Get all stats for a specific team in a match."""
        return self.session.query(MatchTeamStats).filter(
            MatchTeamStats.match_id == match_id,
            MatchTeamStats.team_id == team_id,
            MatchTeamStats.is_deleted == False
        ).all()
    
    def get_by_match(self, match_id: int) -> List[MatchTeamStats]:
        """Get all team stats for a match."""
        return self.session.query(MatchTeamStats).filter(
            MatchTeamStats.match_id == match_id,
            MatchTeamStats.is_deleted == False
        ).all()


class MatchPlayerStatsRepository(BaseRepository):
    """Repository for MatchPlayerStats operations."""
    
    def get_by_match_player_stat(self, match_id: int, team_id: int, player_id: int, stat_id: int):
        """Get match player stat by match_id, team_id, player_id, and stat_id."""
        return self.session.query(MatchPlayerStats).filter(
            MatchPlayerStats.match_id == match_id,
            MatchPlayerStats.team_id == team_id,
            MatchPlayerStats.player_id == player_id,
            MatchPlayerStats.stat_id == stat_id,
            MatchPlayerStats.is_deleted == False
        ).first()
    
    def create_or_update(self, match_id: int, team_id: int, player_id: int, stat_id: int, stat_value: dict):
        """Create or update a match player stat."""
        match_player_stat = self.get_by_match_player_stat(match_id, team_id, player_id, stat_id)
        if match_player_stat:
            match_player_stat.stat_value = stat_value
            return self.update(match_player_stat)
        else:
            match_player_stat = MatchPlayerStats(
                match_id=match_id,
                team_id=team_id,
                player_id=player_id,
                stat_id=stat_id,
                stat_value=stat_value
            )
            return self.create(match_player_stat)
    
    def get_by_match_and_player(self, match_id: int, player_id: int) -> List[MatchPlayerStats]:
        """Get all stats for a specific player in a match."""
        return self.session.query(MatchPlayerStats).filter(
            MatchPlayerStats.match_id == match_id,
            MatchPlayerStats.player_id == player_id,
            MatchPlayerStats.is_deleted == False
        ).all()
    
    def get_by_match_and_team(self, match_id: int, team_id: int) -> List[MatchPlayerStats]:
        """Get all player stats for a specific team in a match."""
        return self.session.query(MatchPlayerStats).filter(
            MatchPlayerStats.match_id == match_id,
            MatchPlayerStats.team_id == team_id,
            MatchPlayerStats.is_deleted == False
        ).all()
    
    def get_by_match(self, match_id: int) -> List[MatchPlayerStats]:
        """Get all player stats for a match."""
        return self.session.query(MatchPlayerStats).filter(
            MatchPlayerStats.match_id == match_id,
            MatchPlayerStats.is_deleted == False
        ).all() 