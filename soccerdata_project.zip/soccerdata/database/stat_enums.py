"""Enums for stat categories, sub-categories, and stat names."""

from enum import Enum


class StatCategory(Enum):
    """Stat categories."""
    MATCH = "match"
    PLAYER = "player"
    TEAM = "team"


class StatSubCategory(Enum):
    """Stat sub-categories."""
    BASIC = "basic"
    ADVANCED = "advanced"


class InferredPosition(Enum):
    """Inferred positions based on positionId from FotMob data."""
    # Goalkeeper
    GOALKEEPER = "Goalkeeper"
    
    # Defenders
    RIGHT_BACK = "Right Back"
    CENTER_BACK = "Center Back"
    LEFT_BACK = "Left Back"
    
    # Midfielders
    DEFENSIVE_MIDFIELDER = "Defensive Midfielder"
    CENTRAL_MIDFIELDER = "Central Midfielder"
    ATTACKING_MIDFIELDER = "Attacking Midfielder"
    
    # Forwards
    RIGHT_WINGER = "Right Winger"
    LEFT_WINGER = "Left Winger"
    STRIKER = "Striker"
    
    # Unknown/Other
    UNKNOWN = "Unknown"
    
    @classmethod
    def from_position_id(cls, position_id: int) -> str:
        """Get inferred position name from positionId."""
        position_mapping = {
            11: cls.GOALKEEPER.value,
            32: cls.RIGHT_BACK.value,
            34: cls.CENTER_BACK.value,
            36: cls.CENTER_BACK.value,
            38: cls.LEFT_BACK.value,
            64: cls.DEFENSIVE_MIDFIELDER.value,
            66: cls.CENTRAL_MIDFIELDER.value,
            83: cls.RIGHT_WINGER.value,
            85: cls.ATTACKING_MIDFIELDER.value,
            87: cls.LEFT_WINGER.value,
            115: cls.STRIKER.value,
        }
        return position_mapping.get(position_id, cls.UNKNOWN.value)

    @classmethod
    def to_group(cls, position_name: str) -> str:
        """Map position name to position group (Goalkeeper, Defense, Midfield, Attack, Unknown)."""
        if position_name == cls.GOALKEEPER.value:
            return "Goalkeeper"
        elif position_name in [cls.RIGHT_BACK.value, cls.CENTER_BACK.value, cls.LEFT_BACK.value]:
            return "Defense"
        elif position_name in [cls.DEFENSIVE_MIDFIELDER.value, cls.CENTRAL_MIDFIELDER.value, cls.ATTACKING_MIDFIELDER.value]:
            return "Midfield"
        elif position_name in [cls.RIGHT_WINGER.value, cls.LEFT_WINGER.value, cls.STRIKER.value]:
            return "Attack"
        else:
            return "Unknown"


class StatName(Enum):
    """Stat names by category and sub-category."""
    
    # Match stats
    MATCH_TIMING_CHART = "timing_chart"
    MATCH_COMMENTARY = "commentary"
    MATCH_SHOTMAP = "shotmap"
    MATCH_EVENTS = "events"
    MATCH_H2H = "h2h"
    MATCH_MOMENTUM = "momentum"
    
    # Player stats - Basic
    PLAYER_POS = "pos"
    PLAYER_MIN = "min"
    PLAYER_SH = "sh"
    PLAYER_G = "g"
    PLAYER_KP = "kp"
    PLAYER_A = "a"
    
    # Player stats - Advanced
    PLAYER_XG = "expected_goals"
    PLAYER_XA = "expected_assists"
    PLAYER_XGOT = "expected_goals_on_target"
    PLAYER_XG_NON_PENALTY = "expected_goals_non_penalty"
    PLAYER_XG_AND_XA = "xg_and_xa"
    PLAYER_FANTASY_POINTS = "fantasy_points"
    PLAYER_RATING = "rating"
    PLAYER_TOUCHES = "touches"
    PLAYER_TOUCHES_OPP_BOX = "touches_opp_box"
    PLAYER_ACCURATE_PASSES = "accurate_passes"
    PLAYER_LONG_BALLS_ACCURATE = "long_balls_accurate"
    PLAYER_DISPOSSESSED = "dispossessed"
    PLAYER_TACKLES_SUCCEEDED = "tackles_succeeded"
    PLAYER_CLEARANCES = "clearances"
    PLAYER_HEADED_CLEARANCE = "headed_clearance"
    PLAYER_INTERCEPTIONS = "interceptions"
    PLAYER_DEFENSIVE_ACTIONS = "defensive_actions"
    PLAYER_RECOVERIES = "recoveries"
    PLAYER_DRIBBLED_PAST = "dribbled_past"
    PLAYER_DUEL_WON = "duel_won"
    PLAYER_DUEL_LOST = "duel_lost"
    PLAYER_GROUND_DUELS_WON = "ground_duels_won"
    PLAYER_AERIALS_WON = "aerials_won"
    PLAYER_WAS_FOULED = "was_fouled"
    PLAYER_FOULS = "fouls"
    PLAYER_SHOTS_ON_TARGET = "ShotsOnTarget"
    PLAYER_DRIBBLES_SUCCEEDED = "dribbles_succeeded"
    PLAYER_PASSES_INTO_FINAL_THIRD = "passes_into_final_third"
    PLAYER_SAVES = "saves"
    PLAYER_GOALS_CONCEDED = "goals_conceded"
    PLAYER_EXPECTED_GOALS_ON_TARGET_FACED = "expected_goals_on_target_faced"
    PLAYER_GOALS_PREVENTED = "goals_prevented"
    PLAYER_KEEPER_DIVING_SAVE = "keeper_diving_save"
    PLAYER_SAVES_INSIDE_BOX = "saves_inside_box"
    PLAYER_KEEPER_SWEEPER = "keeper_sweeper"
    
    # Player position stats
    PLAYER_POSITION_RAW = "position_raw"
    PLAYER_POSITION_DISPLAY = "position_display"
    
    # Player match stats
    PLAYER_AGE = "age"
    PLAYER_SHIRT_NUMBER = "shirt_number"
    PLAYER_COUNTRY = "country"
    PLAYER_PERFORMANCE = "performance"
    
    # Team stats - Basic
    TEAM_POSSESSION = "possession"
    TEAM_SHOTS = "shots"
    TEAM_SHOTS_ON_TARGET = "shots_on_target"
    TEAM_GOALS = "goals"
    TEAM_GOALS_CONCEDED = "goals_conceded"
    TEAM_CORNERS = "corners"
    TEAM_FOULS = "fouls"
    TEAM_YELLOW_CARDS = "yellow_cards"
    TEAM_RED_CARDS = "red_cards"
    TEAM_COACH = "coach"
    TEAM_RATING = "rating"
    TEAM_FORMATION = "formation"
    TEAM_AVERAGE_STARTER_AGE = "average_starter_age"
    
    # Team stats - Advanced
    TEAM_SHOTMAP = "shotmap"
    TEAM_EXPECTED_GOALS = "expected_goals"
    TEAM_EXPECTED_GOALS_CONCEDED = "expected_goals_conceded"
    TEAM_PASSES = "passes"
    TEAM_ACCURATE_PASSES = "accurate_passes"
    TEAM_PASS_ACCURACY = "pass_accuracy"
    TEAM_LONG_BALLS = "long_balls"
    TEAM_ACCURATE_LONG_BALLS = "accurate_long_balls"
    TEAM_CROSSES = "crosses"
    TEAM_ACCURATE_CROSSES = "accurate_crosses"
    TEAM_DRIBBLES = "dribbles"
    TEAM_SUCCESSFUL_DRIBBLES = "successful_dribbles"
    TEAM_TACKLES = "tackles"
    TEAM_SUCCESSFUL_TACKLES = "successful_tackles"
    TEAM_INTERCEPTIONS = "interceptions"
    TEAM_CLEARANCES = "clearances"
    TEAM_AERIALS_WON = "aerials_won"
    TEAM_DUELS_WON = "duels_won"
    TEAM_SAVES = "saves"
    TEAM_BIG_CHANCES = "big_chances"
    TEAM_BIG_CHANCES_MISSED = "big_chances_missed"
    TEAM_HIT_WOODWORK = "hit_woodwork"


class StatDefinition:
    """Helper class to get stat definitions."""
    
    @staticmethod
    def get_shotmap_stat():
        """Get shotmap stat definition."""
        return {
            'category': StatCategory.MATCH.value,
            'sub_category': StatSubCategory.ADVANCED.value,
            'stat_name': StatName.MATCH_SHOTMAP.value
        }
    
    @staticmethod
    def get_events_stat():
        """Get events stat definition."""
        return {
            'category': StatCategory.MATCH.value,
            'sub_category': StatSubCategory.BASIC.value,
            'stat_name': StatName.MATCH_EVENTS.value
        }
    
    @staticmethod
    def get_h2h_stat():
        return {
            'category': StatCategory.MATCH.value,
            'sub_category': StatSubCategory.BASIC.value,
            'stat_name': StatName.MATCH_H2H.value
        }
    
    @staticmethod
    def get_team_shotmap_stat():
        """Get team shotmap stat definition."""
        return {
            'category': StatCategory.TEAM.value,
            'sub_category': StatSubCategory.ADVANCED.value,
            'stat_name': StatName.TEAM_SHOTMAP.value
        }
    
    @staticmethod
    def get_momentum_stat():
        return {
            'category': StatCategory.MATCH.value,
            'sub_category': StatSubCategory.ADVANCED.value,
            'stat_name': StatName.MATCH_MOMENTUM.value
        }
    
    @staticmethod
    def get_position_raw_stat():
        """Get position_raw stat definition."""
        return {
            'category': StatCategory.PLAYER.value,
            'sub_category': StatSubCategory.ADVANCED.value,
            'stat_name': StatName.PLAYER_POSITION_RAW.value
        }
    
    @staticmethod
    def get_position_display_stat():
        """Get position_display stat definition."""
        return {
            'category': StatCategory.PLAYER.value,
            'sub_category': StatSubCategory.ADVANCED.value,
            'stat_name': StatName.PLAYER_POSITION_DISPLAY.value
        }
    
    @staticmethod
    def get_age_stat():
        """Get age stat definition."""
        return {
            'category': StatCategory.PLAYER.value,
            'sub_category': StatSubCategory.ADVANCED.value,
            'stat_name': StatName.PLAYER_AGE.value
        }
    
    @staticmethod
    def get_shirt_number_stat():
        """Get shirt_number stat definition."""
        return {
            'category': StatCategory.PLAYER.value,
            'sub_category': StatSubCategory.ADVANCED.value,
            'stat_name': StatName.PLAYER_SHIRT_NUMBER.value
        }
    
    @staticmethod
    def get_country_stat():
        """Get country stat definition."""
        return {
            'category': StatCategory.PLAYER.value,
            'sub_category': StatSubCategory.ADVANCED.value,
            'stat_name': StatName.PLAYER_COUNTRY.value
        }
    
    @staticmethod
    def get_performance_stat():
        """Get performance stat definition."""
        return {
            'category': StatCategory.PLAYER.value,
            'sub_category': StatSubCategory.ADVANCED.value,
            'stat_name': StatName.PLAYER_PERFORMANCE.value
        }
    
    @staticmethod
    def get_team_coach_stat():
        """Get team coach stat definition."""
        return {
            'category': StatCategory.TEAM.value,
            'sub_category': StatSubCategory.BASIC.value,
            'stat_name': StatName.TEAM_COACH.value
        }
    
    @staticmethod
    def get_team_rating_stat():
        """Get team rating stat definition."""
        return {
            'category': StatCategory.TEAM.value,
            'sub_category': StatSubCategory.BASIC.value,
            'stat_name': StatName.TEAM_RATING.value
        }
    
    @staticmethod
    def get_team_formation_stat():
        """Get team formation stat definition."""
        return {
            'category': StatCategory.TEAM.value,
            'sub_category': StatSubCategory.BASIC.value,
            'stat_name': StatName.TEAM_FORMATION.value
        }
    
    @staticmethod
    def get_team_average_starter_age_stat():
        """Get team average starter age stat definition."""
        return {
            'category': StatCategory.TEAM.value,
            'sub_category': StatSubCategory.BASIC.value,
            'stat_name': StatName.TEAM_AVERAGE_STARTER_AGE.value
        }

    @staticmethod
    def get_player_match_summary_stat():
        return {
            'category': StatCategory.PLAYER.value,
            'sub_category': StatSubCategory.ADVANCED.value,
            'stat_name': 'player_match_summary_stat'
        }

    @staticmethod
    def get_team_match_summary_stat():
        return {
            'category': StatCategory.TEAM.value,
            'sub_category': StatSubCategory.ADVANCED.value,
            'stat_name': 'team_match_summary'
        }

    @staticmethod
    def get_weather_stat():
        return {
            'category': StatCategory.MATCH.value,
            'sub_category': StatSubCategory.BASIC.value,
            'stat_name': 'weather'
        }


class LineupType(Enum):
    STARTERS = 'starters'
    SUBS = 'subs'
    UNAVAILABLE = 'unavailable' 