"""SQLAlchemy ORM models for soccerdata database."""

from datetime import datetime
from typing import Optional, List, Dict, Any
from sqlalchemy import (
    Boolean, DateTime, ForeignKey, ForeignKeyConstraint, Integer, PrimaryKeyConstraint, Text, UniqueConstraint, text, String, JSON
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship
from sqlalchemy.sql import func
from .stat_enums import LineupType


class Base(DeclarativeBase):
    pass


class DefStats(Base):
    """Definition of statistics (matches actual DB schema)."""
    __tablename__ = "def_stats"
    __table_args__ = (
        PrimaryKeyConstraint('stat_id', name='def_stats_pkey'),
        UniqueConstraint('stat_name', 'stat_category', name='def_stats_stat_name_stat_category_key')
    )

    stat_id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    stat_name: Mapped[str] = mapped_column(Text, nullable=False)
    stat_category: Mapped[str] = mapped_column(Text, nullable=False)
    stat_sub_category: Mapped[str] = mapped_column(Text, nullable=False)
    datasource: Mapped[Optional[str]] = mapped_column(Text)
    description: Mapped[Optional[str]] = mapped_column(Text)
    created_at: Mapped[Optional[datetime]] = mapped_column(DateTime, server_default=text('CURRENT_TIMESTAMP'))
    updated_at: Mapped[Optional[datetime]] = mapped_column(DateTime, server_default=text('CURRENT_TIMESTAMP'))
    is_deleted: Mapped[Optional[bool]] = mapped_column(Boolean, server_default=text('false'))

    match_stats: Mapped[List["MatchStats"]] = relationship('MatchStats', back_populates='stat')
    match_team_stats: Mapped[List["MatchTeamStats"]] = relationship('MatchTeamStats', back_populates='stat')


class League(Base):
    """League model (matches actual DB schema)."""
    __tablename__ = "league"
    __table_args__ = (
        PrimaryKeyConstraint('league_id', name='league_pkey'),
        UniqueConstraint('name', name='league_name_key')
    )

    league_id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(Text, nullable=False)
    nation_code: Mapped[str] = mapped_column(Text, nullable=False)
    season_start: Mapped[Optional[str]] = mapped_column(Text)
    season_end: Mapped[Optional[str]] = mapped_column(Text)
    season_code: Mapped[Optional[str]] = mapped_column(Text)
    created_at: Mapped[Optional[datetime]] = mapped_column(DateTime, server_default=text('CURRENT_TIMESTAMP'))
    updated_at: Mapped[Optional[datetime]] = mapped_column(DateTime, server_default=text('CURRENT_TIMESTAMP'))
    is_deleted: Mapped[Optional[bool]] = mapped_column(Boolean, server_default=text('false'))

    league_mapping: Mapped[List["LeagueMapping"]] = relationship('LeagueMapping', back_populates='league')
    match: Mapped[List["Match"]] = relationship('Match', back_populates='league')
    team_standing: Mapped[List["TeamStanding"]] = relationship('TeamStanding', back_populates='league')


class Season(Base):
    """Season model (matches actual DB schema)."""
    __tablename__ = "season"
    __table_args__ = (
        PrimaryKeyConstraint('season_id', name='season_pkey'),
        UniqueConstraint('name', name='season_name_key')
    )
    season_id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(Text, nullable=False)
    created_at: Mapped[Optional[datetime]] = mapped_column(DateTime, server_default=text('CURRENT_TIMESTAMP'))
    updated_at: Mapped[Optional[datetime]] = mapped_column(DateTime, server_default=text('CURRENT_TIMESTAMP'))
    is_deleted: Mapped[Optional[bool]] = mapped_column(Boolean, server_default=text('false'))

    match: Mapped[List["Match"]] = relationship('Match', back_populates='season')
    season_mapping: Mapped[List["SeasonMapping"]] = relationship('SeasonMapping', back_populates='season')
    team_standing: Mapped[List["TeamStanding"]] = relationship('TeamStanding', back_populates='season')


class Team(Base):
    """Team model (matches actual DB schema)."""
    __tablename__ = "team"
    __table_args__ = (
        PrimaryKeyConstraint('team_id', name='team_pkey'),
        UniqueConstraint('name', name='team_name_key')
    )
    team_id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(Text, nullable=False)
    short_name: Mapped[Optional[str]] = mapped_column(Text)
    created_at: Mapped[Optional[datetime]] = mapped_column(DateTime, server_default=text('CURRENT_TIMESTAMP'))
    updated_at: Mapped[Optional[datetime]] = mapped_column(DateTime, server_default=text('CURRENT_TIMESTAMP'))
    is_deleted: Mapped[Optional[bool]] = mapped_column(Boolean, server_default=text('false'))
    imageURL: Mapped[Optional[str]] = mapped_column(Text)

    matches_as_home_team: Mapped[List["Match"]] = relationship('Match', foreign_keys='[Match.home_team_id]', back_populates='home_team')
    matches_as_away_team: Mapped[List["Match"]] = relationship('Match', foreign_keys='[Match.away_team_id]', back_populates='away_team')
    team_mappings: Mapped[List["TeamMapping"]] = relationship('TeamMapping', back_populates='team')
    standings: Mapped[List["TeamStanding"]] = relationship('TeamStanding', back_populates='team')
    match_player_stats: Mapped[List["MatchPlayerStats"]] = relationship('MatchPlayerStats', back_populates='team')
    match_team_stats: Mapped[List["MatchTeamStats"]] = relationship('MatchTeamStats', back_populates='team')


class Player(Base):
    """Player model (matches actual DB schema)."""
    __tablename__ = "player"
    __table_args__ = (
        PrimaryKeyConstraint('player_id', name='player_pkey'),
    )

    player_id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(Text, nullable=False)
    created_at: Mapped[Optional[datetime]] = mapped_column(DateTime, server_default=text('CURRENT_TIMESTAMP'))
    updated_at: Mapped[Optional[datetime]] = mapped_column(DateTime, server_default=text('CURRENT_TIMESTAMP'))
    is_deleted: Mapped[Optional[bool]] = mapped_column(Boolean, server_default=text('false'))

    player_mapping: Mapped[List["PlayerMapping"]] = relationship('PlayerMapping', back_populates='player')
    match_player_stats: Mapped[List["MatchPlayerStats"]] = relationship('MatchPlayerStats', back_populates='player')


class Match(Base):
    """Match model (matches actual DB schema)."""
    __tablename__ = "match"
    __table_args__ = (
        ForeignKeyConstraint(['away_team_id'], ['team.team_id'], name='match_away_team_id_fkey'),
        ForeignKeyConstraint(['home_team_id'], ['team.team_id'], name='match_home_team_id_fkey'),
        ForeignKeyConstraint(['league_id'], ['league.league_id'], name='match_league_id_fkey'),
        ForeignKeyConstraint(['season_id'], ['season.season_id'], name='match_season_id_fkey'),
        PrimaryKeyConstraint('match_id', name='match_pkey'),
        UniqueConstraint('league_id', 'season_id', 'home_team_id', 'away_team_id', 'match_date', name='match_league_id_season_id_home_team_id_away_team_id_match_d_key')
    )

    match_id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    league_id: Mapped[int] = mapped_column(Integer)
    season_id: Mapped[int] = mapped_column(Integer)
    home_team_id: Mapped[int] = mapped_column(Integer)
    away_team_id: Mapped[int] = mapped_column(Integer)
    match_date: Mapped[datetime] = mapped_column(DateTime)
    home_goals: Mapped[Optional[int]] = mapped_column(Integer)
    away_goals: Mapped[Optional[int]] = mapped_column(Integer)
    match_status: Mapped[Optional[str]] = mapped_column(Text, server_default=text("'scheduled'::text"))
    stadium: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    referee: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    attendance: Mapped[Optional[int]] = mapped_column(Integer)
    created_at: Mapped[Optional[datetime]] = mapped_column(DateTime, server_default=text('CURRENT_TIMESTAMP'))
    updated_at: Mapped[Optional[datetime]] = mapped_column(DateTime, server_default=text('CURRENT_TIMESTAMP'))
    is_deleted: Mapped[Optional[bool]] = mapped_column(Boolean, server_default=text('false'))
    round: Mapped[Optional[int]] = mapped_column(Integer)
    round_name: Mapped[Optional[str]] = mapped_column(Text)

    home_team: Mapped["Team"] = relationship('Team', foreign_keys=[home_team_id], back_populates='matches_as_home_team')
    away_team: Mapped["Team"] = relationship('Team', foreign_keys=[away_team_id], back_populates='matches_as_away_team')
    league: Mapped["League"] = relationship('League', back_populates='match')
    season: Mapped["Season"] = relationship('Season', back_populates='match')
    match_mapping: Mapped[List["MatchMapping"]] = relationship('MatchMapping', back_populates='match')
    match_player_stats: Mapped[List["MatchPlayerStats"]] = relationship('MatchPlayerStats', back_populates='match')
    match_team_stats: Mapped[List["MatchTeamStats"]] = relationship('MatchTeamStats', back_populates='match')


class MatchTeamStats(Base):
    """Team statistics per match (matches actual DB schema)."""
    __tablename__ = "match_team_stats"
    __table_args__ = (
        ForeignKeyConstraint(['match_id'], ['match.match_id'], name='match_team_stats_match_id_fkey'),
        ForeignKeyConstraint(['stat_id'], ['def_stats.stat_id'], name='match_team_stats_stat_id_fkey'),
        ForeignKeyConstraint(['team_id'], ['team.team_id'], name='match_team_stats_team_id_fkey'),
        UniqueConstraint('match_id', 'team_id', 'stat_id', name='match_team_stats_match_id_team_id_stat_id_key')
    )
    match_team_stats_id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    match_id: Mapped[int] = mapped_column(Integer)
    team_id: Mapped[int] = mapped_column(Integer)
    stat_id: Mapped[int] = mapped_column(Integer)
    stat_value: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    created_at: Mapped[Optional[datetime]] = mapped_column(DateTime, server_default=text('CURRENT_TIMESTAMP'))
    updated_at: Mapped[Optional[datetime]] = mapped_column(DateTime, server_default=text('CURRENT_TIMESTAMP'))
    is_deleted: Mapped[Optional[bool]] = mapped_column(Boolean, server_default=text('false'))

    match: Mapped["Match"] = relationship('Match', back_populates='match_team_stats')
    team: Mapped["Team"] = relationship('Team', back_populates='match_team_stats')
    stat: Mapped["DefStats"] = relationship('DefStats', back_populates='match_team_stats')


class MatchPlayerStats(Base):
    """Player statistics per match (matches actual DB schema)."""
    __tablename__ = "match_player_stats"
    __table_args__ = (
        ForeignKeyConstraint(['match_id'], ['match.match_id'], name='match_player_stats_match_id_fkey'),
        ForeignKeyConstraint(['player_id'], ['player.player_id'], name='match_player_stats_player_id_fkey'),
        ForeignKeyConstraint(['team_id'], ['team.team_id'], name='match_player_stats_team_id_fkey'),
        PrimaryKeyConstraint('match_player_stats_id', name='match_player_stats_pkey'),
        UniqueConstraint('match_id', 'team_id', 'player_id', 'stat_id', name='match_player_stats_unique_combination')
    )

    match_player_stats_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    match_id: Mapped[int] = mapped_column(Integer)
    player_id: Mapped[int] = mapped_column(Integer)
    team_id: Mapped[int] = mapped_column(Integer)
    stat_id: Mapped[int] = mapped_column(Integer)
    stat_value: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    created_at: Mapped[Optional[datetime]] = mapped_column(DateTime, server_default=text('CURRENT_TIMESTAMP'))
    updated_at: Mapped[Optional[datetime]] = mapped_column(DateTime, server_default=text('CURRENT_TIMESTAMP'))
    is_deleted: Mapped[Optional[bool]] = mapped_column(Boolean, server_default=text('false'))

    match: Mapped["Match"] = relationship('Match', back_populates='match_player_stats')
    player: Mapped["Player"] = relationship('Player', back_populates='match_player_stats')
    team: Mapped["Team"] = relationship('Team', back_populates='match_player_stats')


class MatchStats(Base):
    """Match statistics (matches actual DB schema)."""
    __tablename__ = "match_stats"
    __table_args__ = (
        ForeignKeyConstraint(['match_id'], ['match.match_id'], name='match_stats_match_id_fkey'),
        ForeignKeyConstraint(['stat_id'], ['def_stats.stat_id'], name='match_stats_stat_id_fkey'),
        UniqueConstraint('match_id', 'stat_id', name='match_stats_match_id_stat_id_key')
    )
    match_stats_id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    match_id: Mapped[int] = mapped_column(Integer)
    stat_id: Mapped[int] = mapped_column(Integer)
    stat_value: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    created_at: Mapped[Optional[datetime]] = mapped_column(DateTime, server_default=text('CURRENT_TIMESTAMP'))
    updated_at: Mapped[Optional[datetime]] = mapped_column(DateTime, server_default=text('CURRENT_TIMESTAMP'))
    is_deleted: Mapped[Optional[bool]] = mapped_column(Boolean, server_default=text('false'))

    stat: Mapped["DefStats"] = relationship('DefStats', back_populates='match_stats')


class PlayerStats(Base):
    """Player statistics (matches actual DB schema)."""
    __tablename__ = "player_stats"
    __table_args__ = (
        ForeignKeyConstraint(['player_id'], ['player.player_id'], name='player_stats_player_id_fkey'),
        ForeignKeyConstraint(['stat_id'], ['def_stats.stat_id'], name='player_stats_stat_id_fkey'),
        PrimaryKeyConstraint('player_id', 'stat_id', name='player_stats_pkey')
    )
    player_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    stat_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    stat_value: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    created_at: Mapped[Optional[datetime]] = mapped_column(DateTime, server_default=text('CURRENT_TIMESTAMP'))
    updated_at: Mapped[Optional[datetime]] = mapped_column(DateTime, server_default=text('CURRENT_TIMESTAMP'))
    is_deleted: Mapped[Optional[bool]] = mapped_column(Boolean, server_default=text('false'))


class PlayerStatsSeason(Base):
    """Player statistics per season (matches actual DB schema)."""
    __tablename__ = "player_stats_season"
    __table_args__ = (
        ForeignKeyConstraint(['player_id'], ['player.player_id'], name='player_stats_season_player_id_fkey'),
        ForeignKeyConstraint(['season_id'], ['season.season_id'], name='player_stats_season_season_id_fkey'),
        ForeignKeyConstraint(['stat_id'], ['def_stats.stat_id'], name='player_stats_season_stat_id_fkey'),
        PrimaryKeyConstraint('player_id', 'season_id', 'stat_id', name='player_stats_season_pkey')
    )
    player_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    season_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    stat_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    stat_value: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    created_at: Mapped[Optional[datetime]] = mapped_column(DateTime, server_default=text('CURRENT_TIMESTAMP'))
    updated_at: Mapped[Optional[datetime]] = mapped_column(DateTime, server_default=text('CURRENT_TIMESTAMP'))
    is_deleted: Mapped[Optional[bool]] = mapped_column(Boolean, server_default=text('false'))


class TeamStats(Base):
    """Team statistics (matches actual DB schema)."""
    __tablename__ = "team_stats"
    __table_args__ = (
        ForeignKeyConstraint(['team_id'], ['team.team_id'], name='team_stats_team_id_fkey'),
        ForeignKeyConstraint(['stat_id'], ['def_stats.stat_id'], name='team_stats_stat_id_fkey'),
        PrimaryKeyConstraint('team_id', 'stat_id', name='team_stats_pkey')
    )
    team_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    stat_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    stat_value: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    created_at: Mapped[Optional[datetime]] = mapped_column(DateTime, server_default=text('CURRENT_TIMESTAMP'))
    updated_at: Mapped[Optional[datetime]] = mapped_column(DateTime, server_default=text('CURRENT_TIMESTAMP'))
    is_deleted: Mapped[Optional[bool]] = mapped_column(Boolean, server_default=text('false'))


class TeamStanding(Base):
    """Team standings in leagues and seasons (matches actual DB schema)."""
    __tablename__ = "team_standing"
    __table_args__ = (
        ForeignKeyConstraint(['league_id'], ['league.league_id'], name='team_standing_league_id_fkey'),
        ForeignKeyConstraint(['season_id'], ['season.season_id'], name='team_standing_season_id_fkey'),
        ForeignKeyConstraint(['team_id'], ['team.team_id'], name='team_standing_team_id_fkey'),
        PrimaryKeyConstraint('standing_id', name='team_standing_pkey'),
        UniqueConstraint('league_id', 'season_id', 'team_id', 'round_name', name='team_standing_unique_combination')
    )
    standing_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    league_id: Mapped[int] = mapped_column(Integer)
    season_id: Mapped[int] = mapped_column(Integer)
    team_id: Mapped[int] = mapped_column(Integer)
    round_name: Mapped[Optional[str]] = mapped_column(Text)
    position: Mapped[int] = mapped_column(Integer)
    matches_played: Mapped[int] = mapped_column(Integer)
    wins: Mapped[int] = mapped_column(Integer)
    draws: Mapped[int] = mapped_column(Integer)
    losses: Mapped[int] = mapped_column(Integer)
    goals_for: Mapped[int] = mapped_column(Integer)
    goals_against: Mapped[int] = mapped_column(Integer)
    goal_difference: Mapped[int] = mapped_column(Integer)
    points: Mapped[int] = mapped_column(Integer)
    round: Mapped[Optional[int]] = mapped_column(Integer)
    form: Mapped[Optional[str]] = mapped_column(String(16))
    notes: Mapped[Optional[str]] = mapped_column(String(128))
    source: Mapped[Optional[str]] = mapped_column(String(32))
    created_at: Mapped[Optional[datetime]] = mapped_column(DateTime, server_default=text('CURRENT_TIMESTAMP'))
    updated_at: Mapped[Optional[datetime]] = mapped_column(DateTime, server_default=text('CURRENT_TIMESTAMP'))
    is_deleted: Mapped[Optional[bool]] = mapped_column(Boolean, server_default=text('false'))

    league: Mapped["League"] = relationship('League', back_populates='team_standing')
    season: Mapped["Season"] = relationship('Season', back_populates='team_standing')
    team: Mapped["Team"] = relationship('Team', back_populates='standings')


class MatchMapping(Base):
    """Maps internal match IDs to external data sources (matches actual DB schema)."""
    __tablename__ = "match_mapping"
    __table_args__ = (
        ForeignKeyConstraint(['match_id'], ['match.match_id'], name='match_mapping_match_id_fkey'),
        PrimaryKeyConstraint('mapping_id', name='match_mapping_pkey')
    )
    mapping_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    match_id: Mapped[int] = mapped_column(Integer)
    data_source: Mapped[str] = mapped_column(Text)
    external_id: Mapped[str] = mapped_column(Text)
    url: Mapped[Optional[str]] = mapped_column(Text)
    created_at: Mapped[Optional[datetime]] = mapped_column(DateTime, server_default=text('CURRENT_TIMESTAMP'))
    updated_at: Mapped[Optional[datetime]] = mapped_column(DateTime, server_default=text('CURRENT_TIMESTAMP'))
    is_deleted: Mapped[Optional[bool]] = mapped_column(Boolean, server_default=text('false'))

    match: Mapped["Match"] = relationship('Match', back_populates='match_mapping')


class TeamMapping(Base):
    """Maps internal team IDs to external data sources (matches actual DB schema)."""
    __tablename__ = "team_mapping"
    __table_args__ = (
        ForeignKeyConstraint(['team_id'], ['team.team_id'], name='team_mapping_team_id_fkey'),
        PrimaryKeyConstraint('mapping_id', name='team_mapping_pkey')
    )
    mapping_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    team_id: Mapped[int] = mapped_column(Integer)
    data_source: Mapped[str] = mapped_column(Text)
    external_id: Mapped[str] = mapped_column(Text)
    pageUrl: Mapped[Optional[str]] = mapped_column(Text)
    created_at: Mapped[Optional[datetime]] = mapped_column(DateTime, server_default=text('CURRENT_TIMESTAMP'))
    updated_at: Mapped[Optional[datetime]] = mapped_column(DateTime, server_default=text('CURRENT_TIMESTAMP'))
    is_deleted: Mapped[Optional[bool]] = mapped_column(Boolean, server_default=text('false'))

    team: Mapped["Team"] = relationship('Team', back_populates='team_mappings')


class PlayerMapping(Base):
    """Maps internal player IDs to external data sources (matches actual DB schema)."""
    __tablename__ = "player_mapping"
    __table_args__ = (
        ForeignKeyConstraint(['player_id'], ['player.player_id'], name='player_id_mapping_player_id_fkey'),
        PrimaryKeyConstraint('mapping_id', name='player_id_mapping_pkey')
    )
    mapping_id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    player_id: Mapped[int] = mapped_column(Integer)
    data_source: Mapped[str] = mapped_column(Text)
    external_id: Mapped[str] = mapped_column(Text)
    created_at: Mapped[Optional[datetime]] = mapped_column(DateTime, server_default=text('CURRENT_TIMESTAMP'))
    updated_at: Mapped[Optional[datetime]] = mapped_column(DateTime, server_default=text('CURRENT_TIMESTAMP'))
    is_deleted: Mapped[Optional[bool]] = mapped_column(Boolean, server_default=text('false'))

    player: Mapped["Player"] = relationship('Player', back_populates='player_mapping')


class LeagueMapping(Base):
    """Maps internal league IDs to external data sources (matches actual DB schema)."""
    __tablename__ = "league_mapping"
    __table_args__ = (
        ForeignKeyConstraint(['league_id'], ['league.league_id'], name='league_datasource_mapping_league_id_fkey'),
        PrimaryKeyConstraint('mapping_id', name='league_datasource_mapping_pkey'),
        UniqueConstraint('league_id', 'data_source', name='league_datasource_mapping_league_id_data_source_key')
    )
    mapping_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    league_id: Mapped[int] = mapped_column(Integer)
    data_source: Mapped[str] = mapped_column(Text)
    source_league_code: Mapped[str] = mapped_column(Text)
    created_at: Mapped[Optional[datetime]] = mapped_column(DateTime, server_default=text('CURRENT_TIMESTAMP'))
    updated_at: Mapped[Optional[datetime]] = mapped_column(DateTime, server_default=text('CURRENT_TIMESTAMP'))
    is_deleted: Mapped[Optional[bool]] = mapped_column(Boolean, server_default=text('false'))

    league: Mapped["League"] = relationship('League', back_populates='league_mapping')


class SeasonMapping(Base):
    """Maps internal season IDs to external data sources (matches actual DB schema)."""
    __tablename__ = "season_mapping"
    __table_args__ = (
        ForeignKeyConstraint(['season_id'], ['season.season_id'], name='season_mapping_season_id_fkey'),
        PrimaryKeyConstraint('mapping_id', name='season_mapping_pkey')
    )
    mapping_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    season_id: Mapped[int] = mapped_column(Integer)
    data_source: Mapped[str] = mapped_column(Text)
    source_season_code: Mapped[str] = mapped_column(Text)
    created_at: Mapped[Optional[datetime]] = mapped_column(DateTime, server_default=text('CURRENT_TIMESTAMP'))
    updated_at: Mapped[Optional[datetime]] = mapped_column(DateTime, server_default=text('CURRENT_TIMESTAMP'))
    is_deleted: Mapped[Optional[bool]] = mapped_column(Boolean, server_default=text('false'))

    season: Mapped["Season"] = relationship('Season', back_populates='season_mapping')


class MatchPlayer(Base):
    """Indicates a player who played in a match (lineup/appearance)."""
    __tablename__ = "match_player"
    __table_args__ = (
        ForeignKeyConstraint(['match_id'], ['match.match_id'], name='match_player_match_id_fkey'),
        ForeignKeyConstraint(['team_id'], ['team.team_id'], name='match_player_team_id_fkey'),
        ForeignKeyConstraint(['player_id'], ['player.player_id'], name='match_player_player_id_fkey'),
        PrimaryKeyConstraint('match_player_id', name='match_player_pkey'),
        UniqueConstraint('match_id', 'team_id', 'player_id', name='match_player_unique_combination')
    )
    match_player_id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    match_id: Mapped[int] = mapped_column(Integer)
    team_id: Mapped[int] = mapped_column(Integer)
    player_id: Mapped[int] = mapped_column(Integer)
    type: Mapped[Optional[str]] = mapped_column(String(20))
    remark: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    created_at: Mapped[Optional[datetime]] = mapped_column(DateTime, server_default=text('CURRENT_TIMESTAMP'))
    updated_at: Mapped[Optional[datetime]] = mapped_column(DateTime, server_default=text('CURRENT_TIMESTAMP'))
    is_deleted: Mapped[Optional[bool]] = mapped_column(Boolean, server_default=text('false'))
    position_group: Mapped[Optional[str]] = mapped_column(String(32))

    match: Mapped["Match"] = relationship('Match')
    team: Mapped["Team"] = relationship('Team')
    player: Mapped["Player"] = relationship('Player')


class TeamPlayer(Base):
    """Stores the current roster of each team."""
    __tablename__ = "team_player"
    __table_args__ = (
        ForeignKeyConstraint(['team_id'], ['team.team_id'], name='team_player_team_id_fkey'),
        ForeignKeyConstraint(['player_id'], ['player.player_id'], name='team_player_player_id_fkey'),
        UniqueConstraint('team_id', 'player_id', name='team_player_team_id_player_id_unique'),
    )
    team_player_id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    team_id: Mapped[int] = mapped_column(Integer, nullable=False)
    player_id: Mapped[int] = mapped_column(Integer, nullable=False)
    is_deleted: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    team: Mapped["Team"] = relationship('Team')
    player: Mapped["Player"] = relationship('Player')


class PlayerUnavailability(Base):
    """Tracks periods of player unavailability for each team."""
    __tablename__ = "player_unavailability"
    __table_args__ = (
        ForeignKeyConstraint(['player_id'], ['player.player_id'], name='player_unavailability_player_id_fkey'),
        ForeignKeyConstraint(['team_id'], ['team.team_id'], name='player_unavailability_team_id_fkey'),
        PrimaryKeyConstraint('player_unavailability_id', name='player_unavailability_pkey'),
    )
    player_unavailability_id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    player_id: Mapped[int] = mapped_column(Integer, nullable=False)
    team_id: Mapped[int] = mapped_column(Integer, nullable=False)
    start_date: Mapped[Any] = mapped_column(DateTime, nullable=False)
    end_date: Mapped[Optional[Any]] = mapped_column(DateTime)
    reason: Mapped[Optional[str]] = mapped_column(String(64))
    details: Mapped[Optional[dict]] = mapped_column(JSONB)
    created_at: Mapped[Optional[datetime]] = mapped_column(DateTime, server_default=text('CURRENT_TIMESTAMP'))
    updated_at: Mapped[Optional[datetime]] = mapped_column(DateTime, server_default=text('CURRENT_TIMESTAMP'))

    player: Mapped["Player"] = relationship('Player')
    team: Mapped["Team"] = relationship('Team') 