import psycopg2

# Database connection details
db_config = {
    'host': 'localhost',
    'port': 5432,
    'database': 'soccerdata',
    'user': 'khoatran',
    'password': 'khoatran'
}

# SQL statements to drop tables
drop_tables_sql = [
    "DROP TABLE IF EXISTS player_last_update CASCADE;",
    "DROP TABLE IF EXISTS player_stats_revisions CASCADE;",
    "DROP TABLE IF EXISTS player_stats CASCADE;",
    "DROP TABLE IF EXISTS players CASCADE;",
    "DROP TABLE IF EXISTS player_meta CASCADE;"
]

# Function to execute SQL statements
def drop_tables():
    conn = psycopg2.connect(**db_config)
    cursor = conn.cursor()
    try:
        for sql in drop_tables_sql:
            cursor.execute(sql)
        conn.commit()
        print("Tables dropped successfully.")
    except Exception as e:
        conn.rollback()
        print(f"Error dropping tables: {e}")
    finally:
        cursor.close()
        conn.close()

if __name__ == "__main__":
    drop_tables() 