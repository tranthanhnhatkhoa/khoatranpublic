import psycopg2
from psycopg2.extras import DictCursor

# Database connection details
db_config = {
    'host': 'localhost',
    'port': 5432,
    'database': 'soccerdata',
    'user': 'khoatran',
    'password': 'khoatran'
}

# SQL statements to recreate tables
create_tables_sql = [
    """
    CREATE TABLE IF NOT EXISTS players (
        id SERIAL PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        team VARCHAR(100) NOT NULL,
        position VARCHAR(50),
        date_of_birth TIMESTAMP,
        nationality VARCHAR(100),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(name, team)
    );
    """,
    """
    CREATE TABLE IF NOT EXISTS player_stats (
        id SERIAL PRIMARY KEY,
        player_id INTEGER REFERENCES players(id) ON DELETE CASCADE,
        category VARCHAR(50) NOT NULL,
        stat_name VARCHAR(100) NOT NULL,
        stat_value JSONB NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(player_id, category, stat_name)
    );
    """,
    """
    CREATE TABLE IF NOT EXISTS player_stats_revisions (
        revision_id SERIAL PRIMARY KEY,
        player_id INTEGER REFERENCES players(id) ON DELETE CASCADE,
        category VARCHAR(50) NOT NULL,
        comment TEXT,
        stats JSONB NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        created_by VARCHAR(100)
    );
    """,
    """
    CREATE TABLE IF NOT EXISTS player_last_update (
        player_id INTEGER PRIMARY KEY REFERENCES players(id),
        last_update TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        last_season VARCHAR(10),
        last_team VARCHAR(100),
        update_frequency INTERVAL DEFAULT '1 day'::interval,
        UNIQUE(player_id)
    );
    """,
    """
    CREATE INDEX IF NOT EXISTS idx_player_stats_player_id ON player_stats(player_id);
    CREATE INDEX IF NOT EXISTS idx_player_stats_category ON player_stats(category);
    CREATE INDEX IF NOT EXISTS idx_player_stats_revisions_player_id ON player_stats_revisions(player_id);
    """
]

# Function to execute SQL statements
def recreate_tables():
    conn = psycopg2.connect(**db_config)
    cursor = conn.cursor()
    try:
        for sql in create_tables_sql:
            cursor.execute(sql)
        conn.commit()
        print("Tables recreated successfully.")
    except Exception as e:
        conn.rollback()
        print(f"Error recreating tables: {e}")
    finally:
        cursor.close()
        conn.close()

if __name__ == "__main__":
    recreate_tables() 