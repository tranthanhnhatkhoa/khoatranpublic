import psycopg2
from psycopg2.extras import DictCursor

# Database connection details
db_config = {
    'host': 'localhost',
    'port': 5432,
    'database': 'soccerdata',
    'user': 'khoatran',
    'password': 'khoatran'
}

# SQL statements to create new schema
create_tables_sql = [
    """
    -- Drop existing tables if they exist
    DROP TABLE IF EXISTS player_stats CASCADE;
    DROP TABLE IF EXISTS players CASCADE;
    """,
    """
    -- Create players table
    CREATE TABLE IF NOT EXISTS players (
        id SERIAL PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        team VARCHAR(100) NOT NULL,
        position VARCHAR(50),
        date_of_birth TIMESTAMP,
        nationality VARCHAR(100),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(name, team)
    );
    """,
    """
    -- Create unified player_stats table
    CREATE TABLE IF NOT EXISTS player_stats (
        id SERIAL PRIMARY KEY,
        player_id INTEGER REFERENCES players(id) ON DELETE CASCADE,
        stat_type VARCHAR(20) NOT NULL CHECK (stat_type IN ('overall', 'season', 'match')),
        category VARCHAR(50) NOT NULL CHECK (category IN ('general', 'attack', 'defense', 'others')),
        stat_name VARCHAR(100) NOT NULL,
        stat_value JSONB NOT NULL,
        -- Optional fields for season and match stats
        season VARCHAR(10),
        team VARCHAR(100),
        match_id VARCHAR(50),
        opponent VARCHAR(100),
        match_date TIMESTAMP,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        -- Constraints based on stat_type
        CONSTRAINT valid_season_stats CHECK (
            (stat_type = 'season' AND season IS NOT NULL AND team IS NOT NULL) OR
            (stat_type != 'season')
        ),
        CONSTRAINT valid_match_stats CHECK (
            (stat_type = 'match' AND match_id IS NOT NULL AND season IS NOT NULL AND 
             team IS NOT NULL AND opponent IS NOT NULL AND match_date IS NOT NULL) OR
            (stat_type != 'match')
        )
    );
    """,
    """
    -- Create unique indexes for each stat type
    CREATE UNIQUE INDEX idx_unique_overall_stats 
    ON player_stats (player_id, category, stat_name) 
    WHERE stat_type = 'overall';
    
    CREATE UNIQUE INDEX idx_unique_season_stats 
    ON player_stats (player_id, season, team, category, stat_name) 
    WHERE stat_type = 'season';
    
    CREATE UNIQUE INDEX idx_unique_match_stats 
    ON player_stats (player_id, match_id, category, stat_name) 
    WHERE stat_type = 'match';
    """,
    """
    -- Create additional indexes for better query performance
    CREATE INDEX IF NOT EXISTS idx_player_stats_player_id ON player_stats(player_id);
    CREATE INDEX IF NOT EXISTS idx_player_stats_stat_type ON player_stats(stat_type);
    CREATE INDEX IF NOT EXISTS idx_player_stats_category ON player_stats(category);
    CREATE INDEX IF NOT EXISTS idx_player_stats_season ON player_stats(season);
    CREATE INDEX IF NOT EXISTS idx_player_stats_match_id ON player_stats(match_id);
    """
]

def create_new_schema():
    """Create the new database schema."""
    conn = psycopg2.connect(**db_config)
    cursor = conn.cursor()
    try:
        for sql in create_tables_sql:
            cursor.execute(sql)
        conn.commit()
        print("New schema created successfully.")
    except Exception as e:
        conn.rollback()
        print(f"Error creating new schema: {e}")
    finally:
        cursor.close()
        conn.close()

if __name__ == "__main__":
    create_new_schema() 