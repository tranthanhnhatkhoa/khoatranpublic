"""Script to fix imports in data source files."""

import os
from pathlib import Path

def fix_imports():
    data_sources_dir = Path("soccerdata/data_sources")
    
    # Files to update
    files = [
        "clubelo.py",
        "espn.py",
        "fbref.py",
        "fotmob.py",
        "match_history.py",
        "sofascore.py",
        "sofifa.py",
        "understat.py",
        "whoscored.py"
    ]
    
    for file in files:
        file_path = data_sources_dir / file
        if file_path.exists():
            with open(file_path, 'r') as f:
                content = f.read()
            
            # Replace the import statement
            content = content.replace(
                "from ._common import",
                "from ..core._common import"
            )
            content = content.replace(
                "from ._config import",
                "from ..core._config import"
            )
            
            with open(file_path, 'w') as f:
                f.write(content)
            
            print(f"Updated imports in {file}")

if __name__ == "__main__":
    fix_imports() 