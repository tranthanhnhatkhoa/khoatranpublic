"""Test script for data integration."""

import os
import logging
import psycopg2
from datetime import datetime
from tabulate import tabulate
from soccerdata.database.schema import DatabaseSchema
from soccerdata.data_integration import DataIntegrator

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def display_player_stats(stats: dict, season: str):
    """Display player stats in a formatted table."""
    if not stats:
        return "No stats available"
    
    # Group stats by category
    categories = {
        'Basic': ['position', 'age', 'minutes_played', 'games_played'],
        'Goals': ['goals', 'assists', 'goals_per_90', 'assists_per_90'],
        'Shooting': ['shots', 'shots_on_target', 'shot_accuracy', 'goals_per_shot'],
        'Passing': ['passes_completed', 'pass_accuracy', 'key_passes', 'through_balls'],
        'Defensive': ['tackles', 'interceptions', 'clearances', 'blocks'],
        'Advanced': ['xg', 'xa', 'progressive_passes', 'progressive_carries']
    }
    
    tables = []
    for category, fields in categories.items():
        # Filter stats that exist in the data
        category_stats = {k: stats.get(k, 'N/A') for k in fields if k in stats}
        if category_stats:
            table = tabulate(
                [[k, v] for k, v in category_stats.items()],
                headers=[category, 'Value'],
                tablefmt='grid'
            )
            tables.append(table)
    
    return f"\nSeason: {season}\n" + "\n".join(tables)

def test_data_integration():
    """Test the data integration functionality."""
    # Database connection
    conn = psycopg2.connect(
        dbname="soccerdata",
        user=os.getenv("DB_USER", os.getenv("USER", "khoatran")),
        password=os.getenv("DB_PASSWORD", ""),
        host="localhost",
        port="5432"
    )
    
    try:
        # Initialize schema
        schema = DatabaseSchema(conn)
        schema.create_tables()
        
        # Initialize data integrator
        integrator = DataIntegrator(conn)
        
        # Test players with their seasons
        test_players = [
            {
                'name': 'Erling Haaland',
                'team': 'Manchester City',
                'seasons': ['2223', '2324']
            },
            {
                'name': 'Kevin De Bruyne',
                'team': 'Manchester City',
                'seasons': ['2223', '2324']
            },
            {
                'name': 'Mohamed Salah',
                'team': 'Liverpool',
                'seasons': ['2223', '2324']
            }
        ]
        
        # Process each player
        for player in test_players:
            logger.info(f"\nProcessing {player['name']}...")
            
            for season in player['seasons']:
                logger.info(f"\nSeason: {season}")
                
                # Integrate player data
                result = integrator.integrate_player_data(
                    player['name'],
                    player['team'],
                    season
                )
                
                if result:
                    logger.info("Integration successful!")
                    logger.info("Merged data values:")
                    for stat, value in result.items():
                        logger.info(f"  {stat}: {value}")
                else:
                    logger.error("Integration failed!")
        
        # Display version history for the first player
        if test_players:
            first_player = test_players[0]
            cursor = conn.cursor()
            cursor.execute("""
                SELECT id FROM players 
                WHERE name = %s AND team = %s
            """, (first_player['name'], first_player['team']))
            player_id = cursor.fetchone()[0]
            
            logger.info(f"\nVersion history for {first_player['name']}:")
            cursor.execute("""
                SELECT revision_id, category, created_at, comment, stats
                FROM player_stats_revisions
                WHERE player_id = %s
                ORDER BY created_at DESC
            """, (player_id,))
            
            for row in cursor.fetchall():
                revision_id, category, created_at, comment, stats = row
                logger.info(f"\nRevision ID: {revision_id}")
                logger.info(f"Category: {category}")
                logger.info(f"Created At: {created_at}")
                logger.info(f"Comment: {comment}")
                logger.info("Stats:")
                logger.info(tabulate([[k, v] for k, v in stats.items()], 
                                   headers=['Stat', 'Value'], 
                                   tablefmt='grid'))
        
    except Exception as e:
        logger.error(f"Error during testing: {str(e)}")
        raise
    finally:
        conn.close()

if __name__ == "__main__":
    test_data_integration() 