"""Test suite for the soccerdata package."""
