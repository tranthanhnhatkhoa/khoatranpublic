import psycopg2
from psycopg2.extras import DictCursor

# Database connection details
db_config = {
    'host': 'localhost',
    'port': 5432,
    'database': 'soccerdata',
    'user': 'khoatran',
    'password': 'khoatran'
}

# Sample player data
player_data = {
    'name': 'Erling Haaland',
    'team': 'Manchester City',
    'position': 'FW',
    'date_of_birth': '2000-07-21',
    'nationality': 'NOR',
    'stats': {
        'goals': 27,
        'assists': 5,
        'minutes': 2581,
        'yellow_cards': 1,
        'red_cards': 0,
        'shots': 122,
        'xg': 31.65,
        'xa': 4.75,
        'xg_chain': 30.20,
        'xg_buildup': 3.13
    }
}

# Function to save player data to the database
def save_player_data():
    conn = psycopg2.connect(**db_config)
    cursor = conn.cursor()
    try:
        # Insert player
        cursor.execute("""
            INSERT INTO players (name, team, position, date_of_birth, nationality)
            VALUES (%s, %s, %s, %s, %s)
            RETURNING id
        """, (player_data['name'], player_data['team'], player_data['position'], 
              player_data['date_of_birth'], player_data['nationality']))
        player_id = cursor.fetchone()[0]
        
        # Insert stats
        for stat_name, stat_value in player_data['stats'].items():
            cursor.execute("""
                INSERT INTO player_stats (player_id, category, stat_name, stat_value)
                VALUES (%s, %s, %s, %s)
            """, (player_id, 'general', stat_name, stat_value))
        
        conn.commit()
        print("Player data saved successfully.")
    except Exception as e:
        conn.rollback()
        print(f"Error saving player data: {e}")
    finally:
        cursor.close()
        conn.close()

if __name__ == "__main__":
    save_player_data() 