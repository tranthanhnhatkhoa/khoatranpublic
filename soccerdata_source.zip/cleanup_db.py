"""Script to clean up and optimize database tables."""

import os
import logging
import psycopg2
from datetime import datetime, timedelta
from soccerdata.database.schema import DatabaseSchema

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def cleanup_database():
    """Clean up and optimize database tables."""
    # Database connection
    conn = psycopg2.connect(
        dbname="soccerdata",
        user=os.getenv("DB_USER", os.getenv("USER", "khoatran")),
        password=os.getenv("DB_PASSWORD", ""),
        host="localhost",
        port="5432"
    )
    
    try:
        cursor = conn.cursor()
        
        # 1. Remove orphaned records
        logger.info("Removing orphaned records...")
        
        # Remove stats for non-existent players
        cursor.execute("""
            DELETE FROM player_stats 
            WHERE player_id NOT IN (SELECT id FROM players)
        """)
        logger.info(f"Removed {cursor.rowcount} orphaned player stats")
        
        # Remove revisions for non-existent players
        cursor.execute("""
            DELETE FROM player_stats_revisions 
            WHERE player_id NOT IN (SELECT id FROM players)
        """)
        logger.info(f"Removed {cursor.rowcount} orphaned player revisions")
        
        # Remove last_update records for non-existent players
        cursor.execute("""
            DELETE FROM player_last_update 
            WHERE player_id NOT IN (SELECT id FROM players)
        """)
        logger.info(f"Removed {cursor.rowcount} orphaned last_update records")
        
        # 2. Clean up old revisions
        logger.info("Cleaning up old revisions...")
        # Keep only the last 10 revisions per player per category
        cursor.execute("""
            WITH ranked_revisions AS (
                SELECT revision_id,
                       ROW_NUMBER() OVER (
                           PARTITION BY player_id, category 
                           ORDER BY created_at DESC
                       ) as rn
                FROM player_stats_revisions
            )
            DELETE FROM player_stats_revisions
            WHERE revision_id IN (
                SELECT revision_id 
                FROM ranked_revisions 
                WHERE rn > 10
            )
        """)
        logger.info(f"Removed {cursor.rowcount} old revisions")
        
        # 3. Clean up duplicate stats
        logger.info("Cleaning up duplicate stats...")
        # Keep only the most recent stat value for each player/category/stat_name
        cursor.execute("""
            WITH ranked_stats AS (
                SELECT id,
                       ROW_NUMBER() OVER (
                           PARTITION BY player_id, category, stat_name 
                           ORDER BY updated_at DESC
                       ) as rn
                FROM player_stats
            )
            DELETE FROM player_stats
            WHERE id IN (
                SELECT id 
                FROM ranked_stats 
                WHERE rn > 1
            )
        """)
        logger.info(f"Removed {cursor.rowcount} duplicate stats")
        
        # 4. Clean up old last_update records
        logger.info("Cleaning up old last_update records...")
        # Remove last_update records older than 1 year
        cursor.execute("""
            DELETE FROM player_last_update
            WHERE last_update < CURRENT_TIMESTAMP - INTERVAL '1 year'
        """)
        logger.info(f"Removed {cursor.rowcount} old last_update records")
        
        # Commit changes and close main connection before vacuuming
        conn.commit()
        cursor.close()
        conn.close()

        # 5. Vacuum analyze tables using a new autocommit connection
        logger.info("Vacuuming and analyzing tables...")
        vacuum_conn = psycopg2.connect(
            dbname="soccerdata",
            user=os.getenv("DB_USER", os.getenv("USER", "khoatran")),
            password=os.getenv("DB_PASSWORD", ""),
            host="localhost",
            port="5432"
        )
        vacuum_conn.autocommit = True
        vacuum_cursor = vacuum_conn.cursor()
        vacuum_cursor.execute("VACUUM ANALYZE players")
        vacuum_cursor.execute("VACUUM ANALYZE player_stats")
        vacuum_cursor.execute("VACUUM ANALYZE player_stats_revisions")
        vacuum_cursor.execute("VACUUM ANALYZE player_last_update")
        vacuum_cursor.close()
        vacuum_conn.close()

        # 6. Update statistics
        logger.info("Updating table statistics...")
        analyze_conn = psycopg2.connect(
            dbname="soccerdata",
            user=os.getenv("DB_USER", os.getenv("USER", "khoatran")),
            password=os.getenv("DB_PASSWORD", ""),
            host="localhost",
            port="5432"
        )
        analyze_cursor = analyze_conn.cursor()
        analyze_cursor.execute("ANALYZE players")
        analyze_cursor.execute("ANALYZE player_stats")
        analyze_cursor.execute("ANALYZE player_stats_revisions")
        analyze_cursor.execute("ANALYZE player_last_update")
        analyze_conn.commit()
        analyze_cursor.close()
        analyze_conn.close()
        
        logger.info("Database cleanup completed successfully!")
        
    except Exception as e:
        logger.error(f"Error during database cleanup: {str(e)}")
        conn.rollback()
        raise
    finally:
        conn.close()

if __name__ == "__main__":
    cleanup_database() 