import psycopg2
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def wipe_database():
    conn = None
    try:
        conn = psycopg2.connect(
            dbname="soccerdata",
            user="khoatran",
            password="khoatran",
            host="localhost",
            port="5432"
        )
        conn.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
        cur = conn.cursor()
        tables = [
            "player_stats",
            "player_revisions",
            "last_update"
        ]
        for table in tables:
            cur.execute(f"TRUNCATE TABLE {table} RESTART IDENTITY CASCADE;")
            logging.info(f"Wiped data from table: {table}")
        logging.info("Database wipe completed successfully!")
    except Exception as e:
        logging.error(f"Error wiping database: {e}")
    finally:
        if conn:
            conn.close()

if __name__ == "__main__":
    wipe_database() 