"""Soccer data collection and analysis package."""

from .data_sources import DataSource, STAT_SOURCE_MAPPING, get_stats_for_source
from .player.player import Player
from .data_integration import DataIntegrator
from .database.schema import DatabaseSchema
from .database.db_handler import DatabaseHandler
from .database.validator import PlayerValidator
from .database.batch import PlayerBatch
from .database.version import PlayerStatsVersion
from .database.cache import PlayerCache
from .fbref import FBref
from .understat import Understat

__all__ = [
    'DataSource',
    'STAT_SOURCE_MAPPING',
    'get_stats_for_source',
    'Player',
    'DataIntegrator',
    'DatabaseSchema',
    'DatabaseHandler',
    'PlayerValidator',
    'PlayerBatch',
    'PlayerStatsVersion',
    'PlayerCache',
    'FBref',
    'Understat'
]
