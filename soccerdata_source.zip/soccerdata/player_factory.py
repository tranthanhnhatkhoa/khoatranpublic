"""Player factory for creating player objects from different data sources."""

from typing import Dict, Any, Optional
from dataclasses import dataclass
from datetime import datetime

@dataclass
class Player:
    """Base player class with common attributes."""
    name: str
    team: str
    position: str
    age: Optional[int] = None
    minutes_played: Optional[int] = None
    games_played: Optional[int] = None
    goals: Optional[int] = None
    assists: Optional[int] = None
    goals_per_90: Optional[float] = None
    assists_per_90: Optional[float] = None
    shots: Optional[int] = None
    shots_on_target: Optional[int] = None
    shot_accuracy: Optional[float] = None
    goals_per_shot: Optional[float] = None
    passes_completed: Optional[int] = None
    pass_accuracy: Optional[float] = None
    key_passes: Optional[int] = None
    through_balls: Optional[int] = None
    tackles: Optional[int] = None
    interceptions: Optional[int] = None
    clearances: Optional[int] = None
    blocks: Optional[int] = None
    xG: Optional[float] = None
    xA: Optional[float] = None
    progressive_passes: Optional[int] = None
    progressive_carries: Optional[int] = None

class PlayerFactory:
    """Factory class for creating player objects from different data sources."""
    
    @staticmethod
    def from_fbref(data: Dict[str, Any]) -> Player:
        """Create a player object from FBref data."""
        return Player(
            name=data.get('name', ''),
            team=data.get('team', ''),
            position=data.get('position', 'Unknown'),
            age=data.get('age'),
            minutes_played=data.get('minutes_played'),
            games_played=data.get('games_played'),
            goals=data.get('goals'),
            assists=data.get('assists'),
            goals_per_90=data.get('goals_per_90'),
            assists_per_90=data.get('assists_per_90'),
            shots=data.get('shots'),
            shots_on_target=data.get('shots_on_target'),
            shot_accuracy=data.get('shot_accuracy'),
            goals_per_shot=data.get('goals_per_shot'),
            passes_completed=data.get('passes_completed'),
            pass_accuracy=data.get('pass_accuracy'),
            key_passes=data.get('key_passes'),
            through_balls=data.get('through_balls'),
            tackles=data.get('tackles'),
            interceptions=data.get('interceptions'),
            clearances=data.get('clearances'),
            blocks=data.get('blocks'),
            xG=data.get('xG'),
            xA=data.get('xA'),
            progressive_passes=data.get('progressive_passes'),
            progressive_carries=data.get('progressive_carries')
        )
    
    @staticmethod
    def from_understat(data: Dict[str, Any]) -> Player:
        """Create a player object from Understat data."""
        return Player(
            name=data.get('name', ''),
            team=data.get('team', ''),
            position=data.get('position', 'Unknown'),
            age=data.get('age'),
            minutes_played=data.get('minutes_played'),
            games_played=data.get('games_played'),
            goals=data.get('goals'),
            assists=data.get('assists'),
            goals_per_90=data.get('goals_per_90'),
            assists_per_90=data.get('assists_per_90'),
            shots=data.get('shots'),
            shots_on_target=data.get('shots_on_target'),
            shot_accuracy=data.get('shot_accuracy'),
            goals_per_shot=data.get('goals_per_shot'),
            passes_completed=data.get('passes_completed'),
            pass_accuracy=data.get('pass_accuracy'),
            key_passes=data.get('key_passes'),
            through_balls=data.get('through_balls'),
            tackles=data.get('tackles'),
            interceptions=data.get('interceptions'),
            clearances=data.get('clearances'),
            blocks=data.get('blocks'),
            xG=data.get('xG'),
            xA=data.get('xA'),
            progressive_passes=data.get('progressive_passes'),
            progressive_carries=data.get('progressive_carries')
        ) 