"""Data integration module for combining FBref and Understat data."""

from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
import logging
from .database.schema import DatabaseSchema
from .database.validator import PlayerValidator
from .database.batch import PlayerBatch
from .database.version import PlayerStatsVersion
from .database.cache import PlayerCache
from .player_factory import PlayerFactory, Player
from .fbref import FBref
from .understat import Understat
from .data_sources import DataSource, STAT_SOURCE_MAPPING, get_stats_for_source

logger = logging.getLogger(__name__)

class DataIntegrator:
    """Integrates data from multiple sources into the database."""
    
    def __init__(self, db_connection):
        """Initialize with database connection."""
        self.conn = db_connection
        self.schema = DatabaseSchema(self.conn)
        self.validator = PlayerValidator()
        self.cache = PlayerCache()
        self.fbref = FBref()
        self.understat = Understat()
        
        # Ensure we have the last_update table
        self._ensure_last_update_table()
    
    def _ensure_last_update_table(self):
        """Ensure the last_update table exists."""
        cursor = self.conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS player_last_update (
                player_id INTEGER PRIMARY KEY REFERENCES players(id),
                last_update TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
                last_season VARCHAR(10),
                last_team VARCHAR(100),
                update_frequency INTERVAL DEFAULT '1 day'::interval,
                UNIQUE(player_id)
            )
        """)
        self.conn.commit()
    
    def get_last_update(self, player_id: int) -> Optional[Dict[str, Any]]:
        """Get the last update information for a player."""
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT last_update, last_season, last_team, update_frequency
            FROM player_last_update
            WHERE player_id = %s
        """, (player_id,))
        result = cursor.fetchone()
        if result:
            return {
                'last_update': result[0],
                'last_season': result[1],
                'last_team': result[2],
                'update_frequency': result[3]
            }
        return None
    
    def update_last_update(self, player_id: int, season: str, team: str):
        """Update the last update timestamp for a player."""
        cursor = self.conn.cursor()
        cursor.execute("""
            INSERT INTO player_last_update (player_id, last_update, last_season, last_team)
            VALUES (%s, CURRENT_TIMESTAMP, %s, %s)
            ON CONFLICT (player_id) DO UPDATE
            SET last_update = CURRENT_TIMESTAMP,
                last_season = EXCLUDED.last_season,
                last_team = EXCLUDED.last_team
        """, (player_id, season, team))
        self.conn.commit()
    
    def needs_update(self, player_id: int) -> bool:
        """Check if a player's data needs to be updated."""
        last_update = self.get_last_update(player_id)
        if not last_update:
            return True
        
        update_frequency = last_update['update_frequency']
        next_update = last_update['last_update'] + update_frequency
        return datetime.now(next_update.tzinfo) >= next_update
    
    def batch_update_player_history(self, player_name: str, team: str, seasons: List[str]) -> Dict[str, Any]:
        """Batch update player history for multiple seasons."""
        try:
            # First, ensure player exists and get their ID
            cursor = self.conn.cursor()
            cursor.execute("""
                INSERT INTO players (name, team, position)
                VALUES (%s, %s, 'Unknown')
                ON CONFLICT (name, team) DO UPDATE
                SET team = EXCLUDED.team
                RETURNING id
            """, (player_name, team))
            player_id = cursor.fetchone()[0]
            self.conn.commit()
            
            # Comment out the last_update check to always process all seasons
            # last_update = self.get_last_update(player_id)
            # if last_update:
            #     # Filter seasons to only those after last update
            #     last_season = last_update['last_season']
            #     seasons = [s for s in seasons if s > last_season]
            
            if not seasons:
                logger.info(f"No new seasons to update for {player_name}")
                return {'status': 'no_update_needed', 'player_id': player_id}
            
            # Process each season
            results = []
            for season in seasons:
                logger.info(f"Processing {player_name} for season {season}")
                
                # Get data from sources
                fbref_data = self.fbref.get_player_data(player_name, team, season)
                understat_data = self.understat.get_player_data(player_name, team, season)
                
                if not fbref_data and not understat_data:
                    logger.warning(f"No data found for {player_name} in {season}")
                    continue
                
                # Create player objects
                fbref_player = PlayerFactory.from_fbref(fbref_data) if fbref_data else None
                understat_player = PlayerFactory.from_understat(understat_data) if understat_data else None
                
                # Merge data
                merged_data = self._merge_player_data(fbref_player, understat_player)
                print(f"[DEBUG] Merged data for {player_name} ({team}) {season}: {merged_data}")
                
                # Validate
                if not self.validator.validate_stats(merged_data):
                    logger.error(f"Invalid data for {player_name} in {season}")
                    continue
                
                # Store in database
                with PlayerBatch(self.conn) as batch:
                    batch.add_multiple_stats(player_id, merged_data, category=f'season_{season}')
                    batch.flush()
                
                # Create revision
                with PlayerStatsVersion(self.conn) as version:
                    version.create_revision(
                        player_id,
                        merged_data,
                        category=f'season_{season}',
                        comment=f"Season {season} data from FBref and Understat"
                    )
                
                # Update last update timestamp
                self.update_last_update(player_id, season, team)
                
                results.append({
                    'season': season,
                    'status': 'success',
                    'data_sources': {
                        'fbref': bool(fbref_data),
                        'understat': bool(understat_data)
                    }
                })
            
            # Cache the latest data
            if results:
                latest_season = max(seasons)
                with PlayerBatch(self.conn) as batch:
                    latest_stats = batch.get_stats_batch([player_id], category=f'season_{latest_season}')
                    if player_id in latest_stats:
                        self.cache.set_player_stats(player_id, latest_stats[player_id])
            
            return {
                'status': 'success',
                'player_id': player_id,
                'processed_seasons': results
            }
            
        except Exception as e:
            logger.error(f"Error in batch update for {player_name}: {str(e)}")
            return {
                'status': 'error',
                'error': str(e)
            }
    
    def schedule_updates(self, update_frequency: timedelta = timedelta(days=1)):
        """Schedule regular updates for all players."""
        cursor = self.conn.cursor()
        cursor.execute("""
            UPDATE player_last_update
            SET update_frequency = %s
        """, (update_frequency,))
        self.conn.commit()
    
    def get_players_needing_update(self) -> List[Dict[str, Any]]:
        """Get list of players that need updating."""
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT p.id, p.name, p.team, plu.last_update, plu.last_season
            FROM players p
            JOIN player_last_update plu ON p.id = plu.player_id
            WHERE plu.last_update + plu.update_frequency <= CURRENT_TIMESTAMP
        """)
        return [
            {
                'player_id': row[0],
                'name': row[1],
                'team': row[2],
                'last_update': row[3],
                'last_season': row[4]
            }
            for row in cursor.fetchall()
        ]
    
    def integrate_player_data(self, player_name: str, team: str, season: str) -> Dict[str, Any]:
        """Integrate data for a specific player from all sources."""
        try:
            # Get data from FBref
            fbref_data = self.fbref.get_player_data(player_name, team, season)
            if not fbref_data:
                logger.warning(f"No FBref data found for {player_name} ({team}) in {season}")
                return None
            
            # Get data from Understat
            understat_data = self.understat.get_player_data(player_name, team, season)
            if not understat_data:
                logger.warning(f"No Understat data found for {player_name} ({team}) in {season}")
                return None
            
            # Create player objects from both sources
            fbref_player = PlayerFactory.from_fbref(fbref_data)
            understat_player = PlayerFactory.from_understat(understat_data)
            
            # Merge the data
            merged_data = self._merge_player_data(fbref_player, understat_player)
            
            # Validate the merged data
            if not self.validator.validate_stats(merged_data):
                logger.error(f"Invalid merged data for {player_name}")
                return None
            
            # Store in database
            with PlayerBatch(self.conn) as batch:
                # First, ensure player exists
                cursor = self.conn.cursor()
                cursor.execute("""
                    INSERT INTO players (name, team, position)
                    VALUES (%s, %s, %s)
                    ON CONFLICT (name, team) DO UPDATE
                    SET position = EXCLUDED.position
                    RETURNING id
                """, (player_name, team, merged_data.get('position', 'Unknown')))
                player_id = cursor.fetchone()[0]
                self.conn.commit()
                
                # Add all stats
                batch.add_multiple_stats(player_id, merged_data, category='combined')
                batch.flush()
            
            # Create a revision
            with PlayerStatsVersion(self.conn) as version:
                version.create_revision(
                    player_id,
                    merged_data,
                    category='combined',
                    comment=f"Integrated data from FBref and Understat for {season}"
                )
            
            # Cache the result
            self.cache.set_player_stats(player_id, merged_data)
            
            return {
                'player_id': player_id,
                'name': player_name,
                'team': team,
                'season': season,
                'stats': merged_data
            }
            
        except Exception as e:
            logger.error(f"Error integrating data for {player_name}: {str(e)}")
            return None
    
    def _merge_player_data(self, fbref_player: Optional[Player], understat_player: Optional[Player]) -> Dict[str, Any]:
        """Merge data from different sources based on stat source mapping, using Player.get_stat."""
        merged_data = {}
        
        # Get FBref stats
        if fbref_player:
            print(f"[DEBUG] FBref Player categories: {list(fbref_player._categories.keys())}")
            for cat, cat_obj in fbref_player._categories.items():
                print(f"[DEBUG] FBref Player stats in category '{cat}': {list(cat_obj.stats.keys())}")
            fbref_stats = get_stats_for_source(DataSource.FBREF)
            print(f"[DEBUG] FBref stats to merge: {fbref_stats}")
            for stat in fbref_stats:
                # Search all categories for the stat
                value = None
                for category in fbref_player._categories.keys():
                    v = fbref_player.get_stat(stat, category)
                    if v is not None:
                        value = v
                        break
                if value is not None:
                    merged_data[stat] = value
                    print(f"[DEBUG] Added FBref stat {stat}: {value}")
        
        # Get Understat stats
        if understat_player:
            print(f"[DEBUG] Understat Player categories: {list(understat_player._categories.keys())}")
            for cat, cat_obj in understat_player._categories.items():
                print(f"[DEBUG] Understat Player stats in category '{cat}': {list(cat_obj.stats.keys())}")
            understat_stats = get_stats_for_source(DataSource.UNDERSTAT)
            print(f"[DEBUG] Understat stats to merge: {understat_stats}")
            for stat in understat_stats:
                value = None
                for category in understat_player._categories.keys():
                    v = understat_player.get_stat(stat, category)
                    if v is not None:
                        value = v
                        break
                if value is not None:
                    merged_data[stat] = value
                    print(f"[DEBUG] Added Understat stat {stat}: {value}")
        
        print(f"[DEBUG] Final merged data: {merged_data}")
        return merged_data
    
    def get_player_stats(self, player_id: int) -> Optional[Dict[str, Any]]:
        """Get player stats from cache or database."""
        # Try cache first
        cached_stats = self.cache.get_player_stats(player_id)
        if cached_stats:
            return cached_stats
        
        # If not in cache, get from database
        with PlayerBatch(self.conn) as batch:
            stats = batch.get_stats_batch([player_id])
            if player_id in stats:
                # Cache the result
                self.cache.set_player_stats(player_id, stats[player_id])
                return stats[player_id]
        
        return None
    
    def get_player_history(self, player_id: int, limit: int = 10) -> List[Dict[str, Any]]:
        """Get revision history for a player."""
        with PlayerStatsVersion(self.conn) as version:
            return version.get_player_revisions(player_id, limit=limit)
    
    def compare_player_versions(self, revision_id1: int, revision_id2: int) -> Dict[str, Any]:
        """Compare two versions of player stats."""
        with PlayerStatsVersion(self.conn) as version:
            return version.compare_revisions(revision_id1, revision_id2)
    
    def restore_player_version(self, revision_id: int) -> bool:
        """Restore a specific version of player stats."""
        try:
            with PlayerStatsVersion(self.conn) as version:
                version.restore_revision(revision_id)
            return True
        except Exception as e:
            logger.error(f"Error restoring revision {revision_id}: {str(e)}")
            return False 