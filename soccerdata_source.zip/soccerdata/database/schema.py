"""Database schema for player stats system."""

from typing import Optional
import psycopg2
from psycopg2.extras import DictCursor
from datetime import datetime

class DatabaseSchema:
    """Database schema management for player stats system."""
    
    def __init__(self, db_connection):
        """Initialize with database connection."""
        self.conn = db_connection
        self.cursor = self.conn.cursor()
    
    def create_tables(self):
        """Create all necessary tables if they don't exist."""
        # Create players table
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS players (
                id SERIAL PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                team VARCHAR(100) NOT NULL,
                position VARCHAR(50),
                date_of_birth TIMESTAMP,
                nationality VARCHAR(100),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(name, team)
            )
        """)
        
        # Create player_stats table
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS player_stats (
                id SERIAL PRIMARY KEY,
                player_id INTEGER REFERENCES players(id) ON DELETE CASCADE,
                category VARCHAR(50) NOT NULL,
                stat_name VARCHAR(100) NOT NULL,
                stat_value JSONB NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(player_id, category, stat_name)
            )
        """)
        
        # Create player_stats_revisions table
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS player_stats_revisions (
                revision_id SERIAL PRIMARY KEY,
                player_id INTEGER REFERENCES players(id) ON DELETE CASCADE,
                category VARCHAR(50) NOT NULL,
                comment TEXT,
                stats JSONB NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                created_by VARCHAR(100)
            )
        """)
        
        # Create player_last_update table
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS player_last_update (
                player_id INTEGER PRIMARY KEY REFERENCES players(id),
                last_update TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
                last_season VARCHAR(10),
                last_team VARCHAR(100),
                update_frequency INTERVAL DEFAULT '1 day'::interval,
                UNIQUE(player_id)
            )
        """)
        
        # Create indexes
        self.cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_player_stats_player_id 
            ON player_stats(player_id)
        """)
        
        self.cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_player_stats_category 
            ON player_stats(category)
        """)
        
        self.cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_player_stats_revisions_player_id 
            ON player_stats_revisions(player_id)
        """)
        
        self.conn.commit()
    
    def drop_tables(self):
        """Drop all tables (for testing/development)."""
        self.cursor.execute("""
            DROP TABLE IF EXISTS player_last_update CASCADE;
            DROP TABLE IF EXISTS player_stats_revisions CASCADE;
            DROP TABLE IF EXISTS player_stats CASCADE;
            DROP TABLE IF EXISTS players CASCADE;
        """)
        self.conn.commit()
    
    def __enter__(self):
        """Context manager entry."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.cursor.close() 