"""Version control for player stats."""

from typing import Dict, List, Any, Optional
from datetime import datetime
import json
from .validator import PlayerValidator

class PlayerStatsVersion:
    """Handle version control for player stats."""
    
    def __init__(self, db_connection):
        """Initialize with database connection."""
        self.conn = db_connection
        self.cursor = self.conn.cursor()
    
    def create_revision(self, player_id: int, stats: Dict[str, Any], category: str, comment: str = None) -> int:
        """Create a new revision of player stats."""
        try:
            self.cursor.execute("""
                INSERT INTO player_stats_revisions (player_id, category, comment, stats)
                VALUES (%s, %s, %s, %s)
                RETURNING revision_id
            """, (player_id, category, comment, json.dumps(stats)))
            revision_id = self.cursor.fetchone()[0]
            self.conn.commit()
            return revision_id
        except Exception as e:
            self.conn.rollback()
            raise Exception(f"Failed to create revision: {str(e)}")
    
    def get_revision(self, revision_id: int) -> Dict[str, Any]:
        """Get a specific revision by ID."""
        try:
            self.cursor.execute("""
                SELECT player_id, stats_data, category, comment, created_at
                FROM player_stats_revisions
                WHERE id = %s
            """, (revision_id,))
            
            row = self.cursor.fetchone()
            if not row:
                raise ValueError(f"Revision {revision_id} not found")
            
            player_id, stats_json, category, comment, created_at = row
            if isinstance(stats_json, dict):
                stats = stats_json
            else:
                stats = json.loads(stats_json)
            return {
                'revision_id': revision_id,
                'player_id': player_id,
                'stats': stats,
                'category': category,
                'comment': comment,
                'created_at': created_at
            }
            
        except Exception as e:
            raise Exception(f"Failed to get revision: {str(e)}")
    
    def get_player_revisions(self, player_id: int, 
                           category: Optional[str] = None,
                           limit: int = 10) -> List[Dict[str, Any]]:
        """Get revision history for a player."""
        try:
            if category:
                self.cursor.execute("""
                    SELECT id, stats_data, category, comment, created_at
                    FROM player_stats_revisions
                    WHERE player_id = %s AND category = %s
                    ORDER BY created_at DESC
                    LIMIT %s
                """, (player_id, category, limit))
            else:
                self.cursor.execute("""
                    SELECT id, stats_data, category, comment, created_at
                    FROM player_stats_revisions
                    WHERE player_id = %s
                    ORDER BY created_at DESC
                    LIMIT %s
                """, (player_id, limit))
            
            revisions = []
            for row in self.cursor.fetchall():
                revision_id, stats_json, category, comment, created_at = row
                if isinstance(stats_json, dict):
                    stats = stats_json
                else:
                    stats = json.loads(stats_json)
                revisions.append({
                    'revision_id': revision_id,
                    'stats': stats,
                    'category': category,
                    'comment': comment,
                    'created_at': created_at
                })
            
            return revisions
            
        except Exception as e:
            raise Exception(f"Failed to get player revisions: {str(e)}")
    
    def compare_revisions(self, revision_id1: int, revision_id2: int) -> Dict[str, Any]:
        """Compare two revisions and show differences."""
        try:
            # Get both revisions
            rev1 = self.get_revision(revision_id1)
            rev2 = self.get_revision(revision_id2)
            
            if rev1['player_id'] != rev2['player_id']:
                raise ValueError("Cannot compare revisions from different players")
            
            # Compare stats
            stats1 = rev1['stats']
            stats2 = rev2['stats']
            
            # Find added, removed, and modified stats
            added = {k: v for k, v in stats2.items() if k not in stats1}
            removed = {k: v for k, v in stats1.items() if k not in stats2}
            modified = {
                k: {'old': stats1[k], 'new': stats2[k]}
                for k in stats1
                if k in stats2 and stats1[k] != stats2[k]
            }
            
            return {
                'player_id': rev1['player_id'],
                'revision1': {
                    'id': revision_id1,
                    'created_at': rev1['created_at'],
                    'comment': rev1['comment']
                },
                'revision2': {
                    'id': revision_id2,
                    'created_at': rev2['created_at'],
                    'comment': rev2['comment']
                },
                'changes': {
                    'added': added,
                    'removed': removed,
                    'modified': modified
                }
            }
            
        except Exception as e:
            raise Exception(f"Failed to compare revisions: {str(e)}")
    
    def restore_revision(self, revision_id: int) -> None:
        """Restore a specific revision as current stats."""
        try:
            # Get the revision
            revision = self.get_revision(revision_id)
            
            # Update current stats
            self.cursor.execute("""
                DELETE FROM player_meta
                WHERE player_id = %s
            """, (revision['player_id'],))
            
            # Insert restored stats
            for meta_key, meta_value in revision['stats'].items():
                self.cursor.execute("""
                    INSERT INTO player_meta 
                    (player_id, meta_key, meta_value, category, updated_at)
                    VALUES (%s, %s, %s, %s, %s)
                """, (
                    revision['player_id'],
                    meta_key,
                    json.dumps(meta_value),
                    revision['category'],
                    datetime.utcnow()
                ))
            
            self.conn.commit()
            
        except Exception as e:
            self.conn.rollback()
            raise Exception(f"Failed to restore revision: {str(e)}")
    
    def __enter__(self):
        """Context manager entry."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.cursor.close() 