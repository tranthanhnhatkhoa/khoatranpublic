"""Batch operations for player stats."""

from typing import Dict, List, Any, Optional
from datetime import datetime
import json
from .validator import PlayerValidator

class PlayerBatch:
    """Handle batch operations for player stats."""
    
    def __init__(self, db_connection):
        """Initialize with database connection."""
        self.conn = db_connection
        self.cursor = self.conn.cursor()
        self.batch_size = 1000  # Default batch size
        self.current_batch = []
        self.total_processed = 0
    
    def set_batch_size(self, size: int) -> None:
        """Set the batch size for operations."""
        if size > 0:
            self.batch_size = size
    
    def add_to_batch(self, player_id: int, meta_key: str, meta_value: Any, category: str = 'general') -> None:
        """Add a single stat update to the current batch."""
        # Validate the stat value
        if not PlayerValidator.validate_stat_value(meta_key, meta_value):
            raise ValueError(f"Invalid value for stat {meta_key}")
        
        # Sanitize the value
        sanitized_value = PlayerValidator.sanitize_stat_value(meta_value)
        # Always serialize as JSON for jsonb column
        json_value = json.dumps(sanitized_value)
        
        self.current_batch.append({
            'player_id': player_id,
            'meta_key': meta_key,
            'meta_value': json_value,
            'category': category,
            'updated_at': datetime.utcnow()
        })
        
        if len(self.current_batch) >= self.batch_size:
            self.flush()
    
    def add_multiple_stats(self, player_id: int, stats: Dict[str, Any], category: str = 'general') -> None:
        """Add multiple stats for a player to the batch."""
        for meta_key, meta_value in stats.items():
            self.add_to_batch(player_id, meta_key, meta_value, category)
    
    def flush(self) -> None:
        """Execute the current batch of updates."""
        if not self.current_batch:
            return
        
        try:
            # Prepare the batch insert
            values = []
            for item in self.current_batch:
                values.append((
                    item['player_id'],
                    item['meta_key'],
                    item['meta_value'],
                    item['category'],
                    item['updated_at']
                ))
            
            # Execute batch insert with conflict handling
            self.cursor.executemany("""
                INSERT INTO player_meta (player_id, meta_key, meta_value, category, updated_at)
                VALUES (%s, %s, %s, %s, %s)
                ON CONFLICT (player_id, meta_key) 
                DO UPDATE SET 
                    meta_value = EXCLUDED.meta_value,
                    category = EXCLUDED.category,
                    updated_at = EXCLUDED.updated_at
            """, values)
            
            self.conn.commit()
            self.total_processed += len(self.current_batch)
            self.current_batch = []
            
        except Exception as e:
            self.conn.rollback()
            raise Exception(f"Batch operation failed: {str(e)}")
    
    def delete_stats(self, player_ids: List[int], meta_keys: Optional[List[str]] = None) -> None:
        """Delete stats for multiple players."""
        try:
            if meta_keys:
                # Delete specific stats for the players
                self.cursor.executemany("""
                    DELETE FROM player_meta 
                    WHERE player_id = %s AND meta_key = %s
                """, [(pid, key) for pid in player_ids for key in meta_keys])
            else:
                # Delete all stats for the players
                self.cursor.executemany("""
                    DELETE FROM player_meta 
                    WHERE player_id = %s
                """, [(pid,) for pid in player_ids])
            
            self.conn.commit()
            
        except Exception as e:
            self.conn.rollback()
            raise Exception(f"Batch delete failed: {str(e)}")
    
    def get_stats_batch(self, player_ids, category=None):
        """Retrieve stats for a batch of players, optionally filtered by category."""
        cursor = self.conn.cursor()
        if category:
            cursor.execute(
                """
                SELECT player_id, meta_value
                FROM player_meta
                WHERE player_id = ANY(%s) AND category = %s
                """,
                (player_ids, category)
            )
        else:
            cursor.execute(
                """
                SELECT player_id, meta_value
                FROM player_meta
                WHERE player_id = ANY(%s)
                """,
                (player_ids,)
            )
        rows = cursor.fetchall()
        return {row[0]: row[1] for row in rows}
    
    def __enter__(self):
        """Context manager entry."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        if self.current_batch:
            self.flush()
        self.cursor.close() 