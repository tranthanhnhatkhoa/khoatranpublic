"""Validation system for player stats."""

from typing import Any, Dict, Optional, Union
from datetime import datetime
import json

class PlayerValidator:
    """Validation and sanitization for player data."""
    
    # Define valid stat types and their validation rules
    STAT_VALIDATORS = {
        'goals': lambda x: isinstance(x, int) and x >= 0,
        'assists': lambda x: isinstance(x, int) and x >= 0,
        'minutes_played': lambda x: isinstance(x, int) and 0 <= x <= 120,
        'rating': lambda x: isinstance(x, (int, float)) and 0 <= x <= 10,
        'position': lambda x: x in ['Forward', 'Midfielder', 'Defender', 'Goalkeeper'],
        'date_of_birth': lambda x: isinstance(x, datetime),
        'yellow_cards': lambda x: isinstance(x, int) and 0 <= x <= 2,
        'red_cards': lambda x: isinstance(x, int) and 0 <= x <= 1,
        'passes_completed': lambda x: isinstance(x, int) and x >= 0,
        'passes_attempted': lambda x: isinstance(x, int) and x >= 0,
        'tackles': lambda x: isinstance(x, int) and x >= 0,
        'interceptions': lambda x: isinstance(x, int) and x >= 0,
        'clearances': lambda x: isinstance(x, int) and x >= 0,
        'saves': lambda x: isinstance(x, int) and x >= 0,
        'shots': lambda x: isinstance(x, int) and x >= 0,
        'shots_on_target': lambda x: isinstance(x, int) and x >= 0,
        'fouls_committed': lambda x: isinstance(x, int) and x >= 0,
        'fouls_drawn': lambda x: isinstance(x, int) and x >= 0,
        'offsides': lambda x: isinstance(x, int) and x >= 0,
        'crosses': lambda x: isinstance(x, int) and x >= 0,
        'dribbles': lambda x: isinstance(x, int) and x >= 0,
        'dribbles_completed': lambda x: isinstance(x, int) and x >= 0,
        'blocks': lambda x: isinstance(x, int) and x >= 0,
        'key_passes': lambda x: isinstance(x, int) and x >= 0,
        'aerials_won': lambda x: isinstance(x, int) and x >= 0,
        'aerials_lost': lambda x: isinstance(x, int) and x >= 0,
        'touches': lambda x: isinstance(x, int) and x >= 0,
        'pressures': lambda x: isinstance(x, int) and x >= 0,
        'pressure_regains': lambda x: isinstance(x, int) and x >= 0,
        'carries': lambda x: isinstance(x, int) and x >= 0,
        'carry_distance': lambda x: isinstance(x, (int, float)) and x >= 0,
        'progressive_carries': lambda x: isinstance(x, int) and x >= 0,
        'progressive_passes': lambda x: isinstance(x, int) and x >= 0,
        'pass_accuracy': lambda x: isinstance(x, (int, float)) and 0 <= x <= 100,
    }
    
    @classmethod
    def validate_stat_value(cls, stat_name: str, value: Any) -> bool:
        """Validate stat values based on their type."""
        if stat_name in cls.STAT_VALIDATORS:
            return cls.STAT_VALIDATORS[stat_name](value)
        return True  # Allow unknown stat types
    
    @staticmethod
    def sanitize_stat_value(value: Any) -> Any:
        """Sanitize stat values before storage."""
        if isinstance(value, str):
            return value.strip()
        if isinstance(value, (int, float)):
            return value
        if isinstance(value, datetime):
            return value.isoformat()
        if isinstance(value, (list, dict)):
            return json.dumps(value)
        return str(value)
    
    @classmethod
    def validate_player_data(cls, data: Dict[str, Any]) -> bool:
        """Validate all player data."""
        required_fields = ['name', 'team', 'position']
        
        # Check required fields
        if not all(field in data for field in required_fields):
            return False
        
        # Validate position
        if not cls.STAT_VALIDATORS['position'](data['position']):
            return False
        
        # Validate date_of_birth if present
        if 'date_of_birth' in data and not cls.STAT_VALIDATORS['date_of_birth'](data['date_of_birth']):
            return False
        
        return True
    
    @classmethod
    def validate_stats(cls, stats: Dict[str, Any]) -> bool:
        """Validate all stats in a dictionary."""
        for stat_name, value in stats.items():
            if not cls.validate_stat_value(stat_name, value):
                return False
        return True 