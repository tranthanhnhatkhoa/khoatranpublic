import json
from typing import Dict, List, Optional, Any
from contextlib import contextmanager
import psycopg2
from psycopg2.extras import DictCursor
from .db_config import DatabaseConfig, default_config
from ..player.player import Player

class DatabaseHandler:
    """Handler for PostgreSQL database operations."""
    
    def __init__(self, config: DatabaseConfig = default_config):
        self.config = config
    
    @contextmanager
    def get_connection(self):
        """Get a database connection."""
        conn = psycopg2.connect(self.config.connection_string)
        try:
            yield conn
        finally:
            conn.close()
    
    def save_player(self, player: Player, stat_type: str = 'overall', season: Optional[str] = None, match_id: Optional[str] = None, team: Optional[str] = None, opponent: Optional[str] = None, match_date: Optional[str] = None) -> int:
        """Save a player to the database and return the player ID. Supports stat_type, season, match_id, etc."""
        with self.get_connection() as conn:
            with conn.cursor() as cur:
                # Insert player
                cur.execute("""
                    INSERT INTO players (name, team, position, date_of_birth, nationality)
                    VALUES (%s, %s, %s, %s, %s)
                    ON CONFLICT (name, team) DO UPDATE SET updated_at = CURRENT_TIMESTAMP
                    RETURNING id
                """, (player.name, player.team, player.position, 
                      player.date_of_birth, player.nationality))
                player_id = cur.fetchone()[0]
                
                # Insert stats
                for category, stats in player.get_all_stats().items():
                    for stat_name, stat_value in stats.items():
                        if stat_type == 'overall':
                            sql = """
                                INSERT INTO player_stats (player_id, stat_type, category, stat_name, stat_value, season, team, match_id, opponent, match_date)
                                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                                ON CONFLICT ON CONSTRAINT idx_unique_overall_stats DO UPDATE SET 
                                    stat_value = EXCLUDED.stat_value,
                                    updated_at = CURRENT_TIMESTAMP
                            """
                        elif stat_type == 'season':
                            sql = """
                                INSERT INTO player_stats (player_id, stat_type, category, stat_name, stat_value, season, team, match_id, opponent, match_date)
                                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                                ON CONFLICT ON CONSTRAINT idx_unique_season_stats DO UPDATE SET 
                                    stat_value = EXCLUDED.stat_value,
                                    updated_at = CURRENT_TIMESTAMP
                            """
                        elif stat_type == 'match':
                            sql = """
                                INSERT INTO player_stats (player_id, stat_type, category, stat_name, stat_value, season, team, match_id, opponent, match_date)
                                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                                ON CONFLICT ON CONSTRAINT idx_unique_match_stats DO UPDATE SET 
                                    stat_value = EXCLUDED.stat_value,
                                    updated_at = CURRENT_TIMESTAMP
                            """
                        else:
                            raise ValueError(f"Unknown stat_type: {stat_type}")
                        cur.execute(
                            sql,
                            (player_id, stat_type, category, stat_name, json.dumps(stat_value), season, team, match_id, opponent, match_date)
                        )
                
                conn.commit()
                return player_id
    
    def load_player(self, player_id: int, stat_type: str = 'overall', season: Optional[str] = None, match_id: Optional[str] = None) -> Optional[Player]:
        """Load a player from the database, optionally filtering stats by stat_type, season, or match_id."""
        with self.get_connection() as conn:
            with conn.cursor(cursor_factory=DictCursor) as cur:
                # Get player info
                cur.execute("""
                    SELECT * FROM players WHERE id = %s
                """, (player_id,))
                player_data = cur.fetchone()
                if not player_data:
                    return None
                
                # Get player stats
                query = """
                    SELECT category, stat_name, stat_value 
                    FROM player_stats 
                    WHERE player_id = %s AND stat_type = %s
                """
                params = [player_id, stat_type]
                if stat_type == 'season' and season:
                    query += " AND season = %s"
                    params.append(season)
                if stat_type == 'match' and match_id:
                    query += " AND match_id = %s"
                    params.append(match_id)
                cur.execute(query, params)
                stats_data = cur.fetchall()
                
                # Create player object
                player = Player(
                    name=player_data['name'],
                    team=player_data['team'],
                    position=player_data['position'],
                    date_of_birth=player_data['date_of_birth'],
                    nationality=player_data['nationality']
                )
                
                # Add stats
                for row in stats_data:
                    player.add_stat(
                        row['stat_name'],
                        json.loads(row['stat_value']),
                        category=row['category']
                    )
                
                return player
    
    def search_players(self, 
                      name: Optional[str] = None,
                      team: Optional[str] = None,
                      position: Optional[str] = None) -> List[Player]:
        """Search for players based on criteria."""
        with self.get_connection() as conn:
            with conn.cursor(cursor_factory=DictCursor) as cur:
                query = "SELECT id FROM players WHERE 1=1"
                params = []
                
                if name:
                    query += " AND name ILIKE %s"
                    params.append(f"%{name}%")
                if team:
                    query += " AND team ILIKE %s"
                    params.append(f"%{team}%")
                if position:
                    query += " AND position ILIKE %s"
                    params.append(f"%{position}%")
                
                cur.execute(query, params)
                player_ids = [row['id'] for row in cur.fetchall()]
                
                return [self.load_player(pid) for pid in player_ids]
    
    def get_player_stats(self, 
                        player_id: int,
                        stat_type: str = 'overall',
                        season: Optional[str] = None,
                        match_id: Optional[str] = None,
                        category: Optional[str] = None) -> Dict[str, Any]:
        """Get player statistics, optionally filtered by stat_type, season, match_id, or category."""
        with self.get_connection() as conn:
            with conn.cursor(cursor_factory=DictCursor) as cur:
                query = """
                    SELECT category, stat_name, stat_value 
                    FROM player_stats 
                    WHERE player_id = %s AND stat_type = %s
                """
                params = [player_id, stat_type]
                if stat_type == 'season' and season:
                    query += " AND season = %s"
                    params.append(season)
                if stat_type == 'match' and match_id:
                    query += " AND match_id = %s"
                    params.append(match_id)
                if category:
                    query += " AND category = %s"
                    params.append(category)
                cur.execute(query, params)
                
                stats = {}
                for row in cur.fetchall():
                    if row['category'] not in stats:
                        stats[row['category']] = {}
                    stats[row['category']][row['stat_name']] = json.loads(row['stat_value'])
                
                return stats

# Example usage:
if __name__ == "__main__":
    # Create database handler
    db = DatabaseHandler()
    
    # Create a player
    player = Player(
        name="John Doe",
        team="Arsenal",
        position="Forward"
    )
    
    # Add some stats
    player.add_stat("attacking", "goals", 10)
    player.add_stat("attacking", "assists", 5)
    player.add_stat("defensive", "tackles", 20)
    
    # Save player to database
    player_id = db.save_player(player)
    print(f"Saved player with ID: {player_id}")
    
    # Load player from database
    loaded_player = db.load_player(player_id)
    print(f"Loaded player: {loaded_player}")
    
    # Search for players
    arsenal_players = db.search_players(team="Arsenal")
    print(f"Found {len(arsenal_players)} Arsenal players")
    
    # Get player stats
    stats = db.get_player_stats(player_id, category="attacking")
    print(f"Attacking stats: {stats}") 