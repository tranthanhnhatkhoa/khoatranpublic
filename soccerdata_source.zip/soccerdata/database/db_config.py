"""Database configuration module."""

import os
from dataclasses import dataclass
from pathlib import Path

@dataclass
class DatabaseConfig:
    """Database configuration."""
    host: str = "localhost"
    port: int = 5432
    database: str = "soccerdata"
    user: str = os.getenv("DB_USER", os.getenv("USER", "khoatran"))  # Use system username as default
    password: str = os.getenv("DB_PASSWORD", "")
    
    @property
    def connection_string(self) -> str:
        """Get the PostgreSQL connection string."""
        return f"postgresql://{self.user}:{self.password}@{self.host}:{self.port}/{self.database}"

# Default configuration
default_config = DatabaseConfig() 