"""Caching system for player stats."""

from datetime import datetime, timedelta
from typing import Any, Dict, Optional
import json

class PlayerCache:
    """Cache system for player data, similar to WordPress transients."""
    
    def __init__(self, expiration: int = 3600):  # 1 hour default expiration
        self.cache: Dict[str, Dict[str, Any]] = {}
        self.expiration = expiration
    
    def set(self, key: str, value: Any, expiration: Optional[int] = None) -> None:
        """Cache a value with optional custom expiration."""
        self.cache[key] = {
            'value': value,
            'expires': datetime.now() + timedelta(seconds=expiration or self.expiration)
        }
    
    def get(self, key: str) -> Optional[Any]:
        """Get a cached value if it exists and hasn't expired."""
        if key in self.cache:
            cache_data = self.cache[key]
            if datetime.now() < cache_data['expires']:
                return cache_data['value']
            del self.cache[key]
        return None
    
    def delete(self, key: str) -> None:
        """Delete a cached value."""
        if key in self.cache:
            del self.cache[key]
    
    def clear(self) -> None:
        """Clear all cached values."""
        self.cache.clear()
    
    def get_all(self) -> Dict[str, Any]:
        """Get all non-expired cached values."""
        now = datetime.now()
        return {
            key: data['value']
            for key, data in self.cache.items()
            if now < data['expires']
        }
    
    def set_player_stats(self, player_id: int, stats: Dict[str, Any]) -> None:
        """Cache player stats with a standard key format."""
        key = f"player_stats_{player_id}"
        self.set(key, stats)
    
    def get_player_stats(self, player_id: int) -> Optional[Dict[str, Any]]:
        """Get cached player stats."""
        key = f"player_stats_{player_id}"
        return self.get(key)
    
    def delete_player_stats(self, player_id: int) -> None:
        """Delete cached player stats."""
        key = f"player_stats_{player_id}"
        self.delete(key) 