def process_player_data(self, player_name, team, season):
    fbref_data = self.fbref.get_player_data(player_name, team, season)
    understat_data = self.understat.get_player_data(player_name, team, season)
    if fbref_data and understat_data:
        # Ensure correct key names are used
        fbref_data['player'] = player_name
        understat_data['player'] = player_name
        try:
            # DEBUG: Print the data being processed before batch update
            print(f"[DEBUG] Processing player data for {player_name}, {team}, {season}")
            print(f"[DEBUG] FBref data: {fbref_data}")
            print(f"[DEBUG] Understat data: {understat_data}")
            return fbref_data, understat_data
        except Exception as e:
            print(f"[DEBUG] Exception data: {locals()}")
            logger.error(f"Error in batch update for {player_name}: {e}")
            print(f"Failed to process {player_name}: {e}")
    return None, None 