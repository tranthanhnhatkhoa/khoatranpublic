"""Understat data source handler."""

import logging
from typing import Dict, Any, Optional
from soccerdata.data_sources.understat import Understat as UnderstatReader

logger = logging.getLogger(__name__)

class Understat:
    """Handler for Understat data source."""
    
    def __init__(self, leagues="ENG-Premier League", seasons=None):
        """Initialize Understat handler."""
        self.reader = UnderstatReader(leagues=leagues, seasons=seasons)
    
    def get_player_data(self, player_name: str, team: str, season: str) -> Optional[Dict[str, Any]]:
        """Get player data from Understat.
        
        This is a mock implementation that returns sample data.
        In a real implementation, this would fetch data from Understat's website or API.
        """
        df = self.reader.read_player_season_stats()
        print(f"[DEBUG] Understat DataFrame columns: {df.columns}")
        print(f"[DEBUG] Understat DataFrame index: {df.index.names}")
        print(f"[DEBUG] Looking for player: {player_name}, team: {team}, season: {season}")
        
        # Reset index to make team and player accessible as columns
        df = df.reset_index()
        print(f"[DEBUG] Reset index columns: {df.columns}")
        print(f"[DEBUG] Unique players: {df['player'].unique()}")
        print(f"[DEBUG] Unique teams: {df['team'].unique()}")
        print(f"[DEBUG] Unique seasons: {df['season'].unique()}")
        
        player_row = df[
            (df['player'] == player_name) &
            (df['team'] == team) &
            (df['season'] == season)
        ]
        print(f"[DEBUG] Found player row: {player_row}")
        
        if not player_row.empty:
            data = player_row.iloc[0].to_dict()
            data['player'] = player_name
            data['team'] = team
            print(f"[DEBUG] Returning Understat data: {data}")
            return data
        else:
            print(f"[DEBUG] No data found for player in Understat")
            return None 