"""Data source mappings for player statistics."""

from typing import Dict, List, Set
from enum import Enum

class DataSource(Enum):
    """Enum for different data sources."""
    FBREF = "fbref"
    UNDERSTAT = "understat"
    SOFASCORE = "sofascore"
    OPTA = "opta"

# Define which stats come from which data sources
STAT_SOURCE_MAPPING: Dict[str, DataSource] = {
    # FBref stats
    "games_played": DataSource.FBREF,
    "minutes": DataSource.FBREF,
    "goals": DataSource.FBREF,
    "assists": DataSource.FBREF,
    "yellow_cards": DataSource.FBREF,
    "red_cards": DataSource.FBREF,
    "shots": DataSource.FBREF,
    "shots_on_target": DataSource.FBREF,
    "passes_completed": DataSource.FBREF,
    "passes_attempted": DataSource.FBREF,
    "tackles": DataSource.FBREF,
    "interceptions": DataSource.FBREF,
    "clearances": DataSource.FBREF,
    "blocks": DataSource.FBREF,
    "fouls_committed": DataSource.FBREF,
    "fouls_drawn": DataSource.FBREF,
    "offsides": DataSource.FBREF,
    "crosses": DataSource.FBREF,
    "dribbles_completed": DataSource.FBREF,
    "dribbles_attempted": DataSource.FBREF,
    "duels_won": DataSource.FBREF,
    "duels_lost": DataSource.FBREF,
    "aerials_won": DataSource.FBREF,
    "aerials_lost": DataSource.FBREF,
    
    # Understat stats
    "xg": DataSource.UNDERSTAT,
    "xa": DataSource.UNDERSTAT,
    "xg_chain": DataSource.UNDERSTAT,
    "xg_buildup": DataSource.UNDERSTAT,
    "shots": DataSource.UNDERSTAT,
    "key_passes": DataSource.UNDERSTAT,
    "minutes": DataSource.UNDERSTAT,
    "goals": DataSource.UNDERSTAT,
    "assists": DataSource.UNDERSTAT,
    "yellow_cards": DataSource.UNDERSTAT,
    "red_cards": DataSource.UNDERSTAT,
    "own_goals": DataSource.UNDERSTAT,
    
    # Sofascore stats (to be implemented)
    "rating": DataSource.SOFASCORE,
    "accurate_passes_percentage": DataSource.SOFASCORE,
    "key_passes": DataSource.SOFASCORE,
    "long_balls": DataSource.SOFASCORE,
    "long_balls_accuracy": DataSource.SOFASCORE,
    "cross_accuracy": DataSource.SOFASCORE,
    "dribble_success": DataSource.SOFASCORE,
    "possession_lost": DataSource.SOFASCORE,
    "duel_success": DataSource.SOFASCORE,
    
    # Opta stats (to be implemented)
    "progressive_passes": DataSource.OPTA,
    "progressive_carries": DataSource.OPTA,
    "carries_into_final_third": DataSource.OPTA,
    "carries_into_penalty_area": DataSource.OPTA,
    "passes_into_final_third": DataSource.OPTA,
    "passes_into_penalty_area": DataSource.OPTA,
    "pressures": DataSource.OPTA,
    "pressure_regains": DataSource.OPTA,
    "touches": DataSource.OPTA,
    "touches_in_attacking_third": DataSource.OPTA,
    "touches_in_penalty_area": DataSource.OPTA,
}

def get_stats_for_source(source: DataSource) -> Set[str]:
    """Get all stats that come from a specific data source."""
    return {stat for stat, src in STAT_SOURCE_MAPPING.items() if src == source}

def get_source_for_stat(stat: str) -> DataSource:
    """Get the data source for a specific stat."""
    return STAT_SOURCE_MAPPING.get(stat)
