import soccerdata as sd
import pandas as pd

# Initialize Sofascore for Premier League 2023-24 season
sofascore = sd.Sofascore("ENG-Premier League", "23-24")

# 1. Get available leagues
print("\nAvailable Leagues:")
leagues = sofascore.read_leagues()
print(leagues)

# 2. Get available seasons
print("\nAvailable Seasons:")
seasons = sofascore.read_seasons()
print(seasons)

# 3. Get league table
print("\nPremier League Table:")
league_table = sofascore.read_league_table()
print(league_table)

# 4. Get match schedule
print("\nMatch Schedule:")
schedule = sofascore.read_schedule()
print(schedule)

# 5. Get detailed statistics for a specific match
# Get the first match ID from the schedule
if not schedule.empty:
    first_match_id = schedule.iloc[0]['game_id']
    print(f"\nDetailed statistics for match ID {first_match_id}:")
    # Note: This is just an example - the actual match details endpoint would need to be implemented
    print("Match details endpoint not implemented in the current version") 