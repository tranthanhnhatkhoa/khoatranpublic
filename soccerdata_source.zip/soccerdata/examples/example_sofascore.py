import soccerdata as sd

# Initialize Sofascore for Premier League 2023-24 season
sofascore = sd.Sofascore("ENG-Premier League", "23-24")

# Get league table
print("\nPremier League Table:")
league_table = sofascore.read_league_table()
print(league_table)

# Get match schedule
print("\nMatch Schedule:")
schedule = sofascore.read_schedule()
print(schedule.head())  # Show first few matches

# Get available leagues
print("\nAvailable Leagues:")
leagues = sofascore.read_leagues()
print(leagues)

# Get available seasons
print("\nAvailable Seasons:")
seasons = sofascore.read_seasons()
print(seasons) 