import soccerdata as sd

# Initialize Understat for Premier League 2022-23 and 2023-24 seasons
understat = sd.Understat("ENG-Premier League", ["22-23", "23-24"])

# Print all matches in the schedule
print("\nAll matches in schedule:")
schedule = understat.read_schedule()
print(schedule[['home_team', 'away_team', 'date']].head(10))

# Example 1: Find matches between Arsenal and Chelsea
print("\nArsenal vs Chelsea matches:")
matches = understat.find_match("Arsenal", "Chelsea")
print(matches)

# Print all matches involving Arsenal
print("\nAll matches involving Arsenal:")
arsenal_matches = schedule[
    (schedule['home_team'].str.contains('Arsenal', case=False, na=False)) |
    (schedule['away_team'].str.contains('Arsenal', case=False, na=False))
]
print(arsenal_matches[['home_team', 'away_team', 'date']])

# Print all matches involving Chelsea
print("\nAll matches involving Chelsea:")
chelsea_matches = schedule[
    (schedule['home_team'].str.contains('Chelsea', case=False, na=False)) |
    (schedule['away_team'].str.contains('Chelsea', case=False, na=False))
]
print(chelsea_matches[['home_team', 'away_team', 'date']])

# Example 2: Find matches between Manchester United and Liverpool
print("\nManchester United vs Liverpool matches:")
matches = understat.find_match("Manchester United", "Liverpool")
print(matches)

# Example 3: Find matches between two teams in a specific season
print("\nArsenal vs Chelsea matches in 2022-23 season:")
matches = understat.find_match(
    "Arsenal",
    "Chelsea",
    league="ENG-Premier League",
    season="22-23"
)
print(matches)

# Example 4: Try to find a non-existent match
print("\nNon-existent match:")
matches = understat.find_match("Team A", "Team B")
print(matches) 