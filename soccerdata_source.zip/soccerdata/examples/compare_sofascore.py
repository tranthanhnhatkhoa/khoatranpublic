import soccerdata as sd
import pandas as pd
from rich.console import Console
from rich.table import Table
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
import time

console = Console()

def get_web_data():
    """Get data from Sofascore website using Selenium with Tor proxy"""
    url = "https://www.sofascore.com/tournament/football/england/premier-league/17"
    
    # Set up Chrome options with Tor SOCKS5 proxy
    chrome_options = Options()
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--disable-dev-shm-usage')
    chrome_options.add_argument('--proxy-server=socks5://127.0.0.1:9050')
    
    try:
        # Initialize the driver
        driver = webdriver.Chrome(options=chrome_options)
        driver.get(url)
        
        # Wait for the page to load
        time.sleep(5)
        
        # Try to handle the popup/overlay
        try:
            # Wait for popup to appear (adjust the selector based on the actual popup)
            popup = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, "div[class*='modal'], div[class*='popup'], div[class*='overlay']"))
            )
            console.print("[yellow]Found popup, attempting to close it...[/yellow]")
            
            # Try different methods to close the popup
            try:
                # Method 1: Look for a close button
                close_button = popup.find_element(By.CSS_SELECTOR, "button[class*='close'], div[class*='close'], span[class*='close']")
                close_button.click()
            except NoSuchElementException:
                try:
                    # Method 2: Look for an "Accept" or "OK" button
                    accept_button = popup.find_element(By.XPATH, "//button[contains(text(), 'Accept') or contains(text(), 'OK') or contains(text(), 'Close')]")
                    accept_button.click()
                except NoSuchElementException:
                    # Method 3: Try to click outside the popup
                    driver.execute_script("arguments[0].style.display = 'none';", popup)
            
            console.print("[green]Popup handled[/green]")
        except TimeoutException:
            console.print("[yellow]No popup found or it disappeared quickly[/yellow]")
        
        # Wait for the standings table to load
        wait = WebDriverWait(driver, 60)
        wait.until(EC.presence_of_element_located((By.CLASS_NAME, 'standings')))
        
        # Give some extra time for data to load
        time.sleep(5)
        
        # Extract league table data
        table_data = []
        rows = driver.find_elements(By.CLASS_NAME, 'standings__row')
        
        for row in rows:
            try:
                team = row.find_element(By.CLASS_NAME, 'standings__team').text.strip()
                points = row.find_element(By.CLASS_NAME, 'standings__points').text.strip()
                table_data.append({
                    'team': team,
                    'points': points
                })
            except Exception as e:
                console.print(f"[yellow]Warning: Could not extract data from row: {str(e)}[/yellow]")
                continue
        
        driver.quit()
        return pd.DataFrame(table_data)
    except Exception as e:
        console.print(f"[red]Error fetching web data: {str(e)}[/red]")
        if 'driver' in locals():
            driver.quit()
        return None

def main():
    # Initialize Sofascore API
    sofascore = sd.Sofascore("ENG-Premier League", "23-24")
    
    # Get API data
    console.print("\n[bold blue]Fetching API data...[/bold blue]")
    api_table = sofascore.read_league_table()
    console.print("\n[bold green]API Data:[/bold green]")
    console.print(api_table)
    
    # Get web data
    console.print("\n[bold blue]Fetching web data...[/bold blue]")
    web_table = get_web_data()
    if web_table is not None and not web_table.empty:
        console.print("\n[bold green]Web Data:[/bold green]")
        console.print(web_table)
        
        # Compare data
        console.print("\n[bold yellow]Comparison:[/bold yellow]")
        comparison = pd.merge(
            api_table.reset_index()[['team', 'Pts']],
            web_table,
            on='team',
            how='outer',
            suffixes=('_api', '_web')
        )
        comparison['points_match'] = comparison['Pts'] == comparison['points'].astype(int)
        console.print(comparison)
    else:
        console.print("[red]Could not fetch web data for comparison[/red]")

if __name__ == "__main__":
    main() 