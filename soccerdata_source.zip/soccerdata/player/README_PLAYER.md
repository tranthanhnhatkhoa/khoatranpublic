# Player Data Management

This module provides tools for managing player data in soccer, including player statistics, database integration, and data source integration.

## Features

### Player Classes

1. **Basic Player Class** (`player.py`)
   - Simple player representation with dynamic attributes
   - Basic stat management

2. **Advanced Player Class** (`player_advanced.py`)
   - Type-hinted player representation
   - Categorized statistics
   - Flexible stat management
   - Date of birth and nationality support

### Player Factory

The `PlayerFactory` class (`player_factory.py`) provides methods to create Player objects from different data sources:

1. **Understat Integration**
   - Converts Understat player data to Player objects
   - Includes advanced metrics (xG, xA, etc.)

2. **FBref Integration**
   - Converts FBref player data to Player objects
   - Comprehensive stat categories (attacking, passing, defensive, etc.)

### Database Integration

1. **Database Configuration** (`db_config.py`)
   - PostgreSQL connection settings
   - Environment variable support
   - Default configuration

2. **Database Handler** (`db_handler.py`)
   - Player data persistence
   - Search functionality
   - Stat category management
   - Connection pooling

## Usage Examples

### Creating a Player

```python
from soccerdata import Player

# Basic player
player = Player(name="John Doe", team="Arsenal", position="Forward")

# Add stats
player.add_stat("attacking", "goals", 10)
player.add_stat("attacking", "assists", 5)
```

### Using Player Factory

```python
from soccerdata import PlayerFactory

# Create from Understat data
player = PlayerFactory.from_understat(understat_data)

# Create from FBref data
player = PlayerFactory.from_fbref(fbref_data)
```

### Database Operations

```python
from soccerdata import DatabaseHandler, Player

# Initialize database handler
db = DatabaseHandler()

# Save player
player = Player(name="John Doe", team="Arsenal", position="Forward")
player_id = db.save_player(player)

# Load player
loaded_player = db.load_player(player_id)

# Search players
arsenal_players = db.search_players(team="Arsenal")

# Get stats
stats = db.get_player_stats(player_id, category="attacking")
```

## Requirements

- PostgreSQL database
- Python 3.8+
- psycopg2-binary
- pandas
- python-dateutil

## Installation

1. Install PostgreSQL
2. Create database:
```sql
CREATE DATABASE soccerdata;
```

3. Install dependencies:
```bash
pip install -r requirements.txt
```

## Configuration

Database configuration can be set through environment variables:
- `DB_HOST`: Database host (default: localhost)
- `DB_PORT`: Database port (default: 5432)
- `DB_NAME`: Database name (default: soccerdata)
- `DB_USER`: Database user
- `DB_PASSWORD`: Database password 