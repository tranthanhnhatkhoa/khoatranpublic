"""Player class for managing player data and statistics."""

from typing import Dict, Any, Optional
from datetime import datetime
from dataclasses import dataclass, field

@dataclass
class StatCategory:
    """Category for grouping player statistics."""
    name: str
    description: str
    stats: Dict[str, Any] = field(default_factory=dict)

class Player:
    """Advanced player class with categorized statistics."""
    
    def __init__(self, 
                 name: str,
                 team: str,
                 position: Optional[str] = None,
                 date_of_birth: Optional[datetime] = None,
                 nationality: Optional[str] = None):
        """Initialize a new player."""
        self.name = name
        self.team = team
        self.position = position
        self.date_of_birth = date_of_birth
        self.nationality = nationality
        self._categories: Dict[str, StatCategory] = {}
    
    def add_category(self, name: str, description: str) -> None:
        """Add a new stat category."""
        if name not in self._categories:
            self._categories[name] = StatCategory(name, description)
    
    def add_stat(self, stat_name: str, value: Any, category: str = 'general') -> None:
        """Add a statistic to a category."""
        if category not in self._categories:
            self.add_category(category, f"Statistics for {category}")
        self._categories[category].stats[stat_name] = value
    
    def get_stat(self, stat_name: str, category: str = 'general') -> Optional[Any]:
        """Get a statistic from a category."""
        if category in self._categories:
            return self._categories[category].stats.get(stat_name)
        return None
    
    def get_category_stats(self, category: str) -> Dict[str, Any]:
        """Get all statistics for a category."""
        if category in self._categories:
            return self._categories[category].stats.copy()
        return {}
    
    def get_all_stats(self) -> Dict[str, Dict[str, Any]]:
        """Get all statistics organized by category."""
        return {
            category: cat.stats.copy()
            for category, cat in self._categories.items()
        }
    
    def get_categories(self) -> Dict[str, str]:
        """Get all categories with their descriptions."""
        return {
            category: cat.description
            for category, cat in self._categories.items()
        }
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert player to dictionary format."""
        return {
            'name': self.name,
            'team': self.team,
            'position': self.position,
            'date_of_birth': self.date_of_birth,
            'nationality': self.nationality,
            'stats': self.get_all_stats()
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Player':
        """Create a player from dictionary data."""
        player = cls(
            name=data['name'],
            team=data['team'],
            position=data.get('position'),
            date_of_birth=data.get('date_of_birth'),
            nationality=data.get('nationality')
        )
        
        # Add all stats
        for category, stats in data.get('stats', {}).items():
            for stat_name, value in stats.items():
                player.add_stat(stat_name, value, category)
        
        return player

# Example usage:
if __name__ == "__main__":
    # Create a player
    player = Player(
        name="John Doe",
        team="Arsenal",
        position="Forward",
        date_of_birth=datetime(1995, 1, 1),
        nationality="English"
    )
    
    # Add some stats
    player.add_stat("goals", 10, "attacking")
    player.add_stat("assists", 5, "attacking")
    player.add_stat("shots", 50, "attacking")
    
    player.add_stat("tackles", 20, "defensive")
    player.add_stat("interceptions", 15, "defensive")
    
    # Print player info
    print(player)
    
    # Get specific stats
    print(f"Goals: {player.get_stat('goals', 'attacking')}")
    print(f"Tackles: {player.get_stat('tackles', 'defensive')}")
    
    # Get all stats from a category
    print(f"Attacking stats: {player.get_category_stats('attacking')}")
    
    # Get all stats
    print(f"All stats: {player.get_all_stats()}")
    
    # Get categories
    print(f"Categories: {player.get_categories()}")
    
    # Convert player to dictionary
    player_dict = player.to_dict()
    print(f"Player dictionary: {player_dict}")
    
    # Create player from dictionary
    new_player = Player.from_dict(player_dict)
    print(f"New player: {new_player}") 