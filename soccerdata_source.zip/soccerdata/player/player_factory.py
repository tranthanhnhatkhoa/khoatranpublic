from typing import Dict, Any, Optional
from datetime import datetime
from .player import Player

class PlayerFactory:
    """Factory class to create Player objects from different data sources."""
    
    @staticmethod
    def from_understat(data: Dict[str, Any]) -> Player:
        """Create a Player object from Understat data."""
        player = Player(
            name=data.get('player', ''),
            team=data.get('team', ''),
            position=data.get('position', ''),
        )
        
        # Add basic stats
        player.add_stat('minutes', data.get('minutes', 0), 'basic')
        player.add_stat('position_id', data.get('position_id', 0), 'basic')
        
        # Add attacking stats
        player.add_stat('goals', data.get('goals', 0), 'attacking')
        player.add_stat('own_goals', data.get('own_goals', 0), 'attacking')
        player.add_stat('shots', data.get('shots', 0), 'attacking')
        player.add_stat('xg', data.get('xg', 0.0), 'attacking')
        player.add_stat('xg_chain', data.get('xg_chain', 0.0), 'attacking')
        player.add_stat('xg_buildup', data.get('xg_buildup', 0.0), 'attacking')
        player.add_stat('assists', data.get('assists', 0), 'attacking')
        player.add_stat('xa', data.get('xa', 0.0), 'attacking')
        player.add_stat('key_passes', data.get('key_passes', 0), 'attacking')
        
        # Add disciplinary stats
        player.add_stat('yellow_cards', data.get('yellow_cards', 0), 'disciplinary')
        player.add_stat('red_cards', data.get('red_cards', 0), 'disciplinary')
        
        return player
    
    @staticmethod
    def from_fbref(data: Dict[str, Any]) -> Player:
        """Create a Player object from FBref data."""
        player = Player(
            name=data.get('player', ''),
            team=data.get('team', ''),
            position=data.get('position', ''),
            nationality=data.get('nation', ''),
        )
        
        # Add basic stats
        player.add_stat('minutes', data.get('minutes', 0), 'basic')
        player.add_stat('games_played', data.get('games_played', 0), 'basic')
        player.add_stat('age', data.get('age', 0), 'basic')
        
        # Add attacking stats
        player.add_stat('goals', data.get('goals', 0), 'attacking')
        player.add_stat('assists', data.get('assists', 0), 'attacking')
        player.add_stat('shots', data.get('shots', 0), 'attacking')
        player.add_stat('shots_on_target', data.get('shots_on_target', 0), 'attacking')
        
        # Add passing stats
        player.add_stat('passes_completed', data.get('passes_completed', 0), 'passing')
        player.add_stat('passes_attempted', data.get('passes_attempted', 0), 'passing')
        
        # Add defensive stats
        player.add_stat('tackles', data.get('tackles', 0), 'defensive')
        player.add_stat('interceptions', data.get('interceptions', 0), 'defensive')
        player.add_stat('blocks', data.get('blocks', 0), 'defensive')
        player.add_stat('clearances', data.get('clearances', 0), 'defensive')
        
        # Add possession stats
        player.add_stat('touches', data.get('touches', 0), 'possession')
        player.add_stat('carries', data.get('carries', 0), 'possession')
        player.add_stat('progressive_carries', data.get('progressive_carries', 0), 'possession')
        
        # Add disciplinary stats
        player.add_stat('yellow_cards', data.get('yellow_cards', 0), 'disciplinary')
        player.add_stat('red_cards', data.get('red_cards', 0), 'disciplinary')
        player.add_stat('fouls_committed', data.get('fouls_committed', 0), 'disciplinary')
        player.add_stat('fouls_drawn', data.get('fouls_drawn', 0), 'disciplinary')
        
        return player

# Example usage:
if __name__ == "__main__":
    # Example Understat data
    understat_data = {
        'player': 'John Doe',
        'team': 'Arsenal',
        'position': 'FW',
        'minutes': 90,
        'goals': 2,
        'assists': 1,
        'xg': 1.8,
        'shots': 5,
        'key_passes': 3
    }
    
    # Example FBref data
    fbref_data = {
        'Player': 'John Doe',
        'team': 'Arsenal',
        'Pos': 'FW',
        'Nation': 'ENG',
        '#': 10,
        'Age': 25,
        'Min': 90,
        'Gls': 2,
        'Ast': 1,
        'Sh': 5,
        'SoT': 3,
        'KP': 3,
        'Cmp': 20,
        'Att': 25,
        'Cmp%': 80,
        'Tkl': 1,
        'Int': 2
    }
    
    # Create players from different sources
    player_understat = PlayerFactory.from_understat(understat_data)
    player_fbref = PlayerFactory.from_fbref(fbref_data)
    
    # Print players
    print("Understat Player:")
    print(player_understat)
    print("\nFBref Player:")
    print(player_fbref) 