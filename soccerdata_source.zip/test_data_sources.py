"""Test script for data source mappings."""

from soccerdata.data_sources import DataSource, STAT_SOURCE_MAPPING, get_stats_for_source, get_source_for_stat
from soccerdata.fbref import FBref
from soccerdata.understat import Understat
from soccerdata.data_integration import DataIntegrator
from soccerdata.database.db_config import default_config
from soccerdata.player.player_factory import PlayerFactory
import psycopg2
import logging
from psycopg2.extras import DictCursor

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Database connection details
db_config = {
    'host': 'localhost',
    'port': 5432,
    'database': 'soccerdata',
    'user': 'khoatran',
    'password': 'khoatran'
}

def test_data_source_mappings():
    """Test the data source mappings."""
    print("\n=== Testing Data Source Mappings ===")
    
    # Test 1: Check if all stats have a source
    print("\nTest 1: Verifying all stats have a source")
    for stat, source in STAT_SOURCE_MAPPING.items():
        print(f"✓ {stat} -> {source.value}")
    
    # Test 2: Check stats for each source
    print("\nTest 2: Checking stats for each source")
    for source in DataSource:
        stats = get_stats_for_source(source)
        print(f"\n{source.value.upper()} stats:")
        for stat in sorted(stats):
            print(f"  - {stat}")
    
    # Test 3: Test with real data
    print("\nTest 3: Testing with real player data")
    try:
        # Connect to database using configuration
        conn = psycopg2.connect(**db_config)
        
        # Initialize data integrator
        integrator = DataIntegrator(conn)
        
        # Test with a known player
        player_name = "Erling Haaland"
        team = "Manchester City"
        season = "2324"  # Updated to match the format in the data
        
        print(f"\nFetching data for {player_name} ({team}) in {season}")
        
        # Get data from sources
        fbref = FBref()
        understat = Understat()
        
        fbref_data = fbref.get_player_data(player_name, team, season)
        understat_data = understat.get_player_data(player_name, team, season)
        
        print("\n[DEBUG] Raw FBref data:")
        print(fbref_data)
        print("\n[DEBUG] Raw Understat data:")
        print(understat_data)
        
        if fbref_data:
            print("\nFBref data found:")
            for stat in get_stats_for_source(DataSource.FBREF):
                if stat in fbref_data:
                    print(f"  - {stat}: {fbref_data[stat]}")
        
        if understat_data:
            print("\nUnderstat data found:")
            for stat in get_stats_for_source(DataSource.UNDERSTAT):
                if stat in understat_data:
                    print(f"  - {stat}: {understat_data[stat]}")
        
        # Test data integration
        if fbref_data or understat_data:
            print("\nTesting data integration:")
            result = integrator._merge_player_data(
                PlayerFactory.from_fbref(fbref_data) if fbref_data else None,
                PlayerFactory.from_understat(understat_data) if understat_data else None
            )
            print("[DEBUG] Merged data:")
            for k, v in result.items():
                print(f"  {k}: {v} (type: {type(v)})")
            is_valid = integrator.validator.validate_stats(result)
            print(f"[DEBUG] Validation result: {is_valid}")
            if not is_valid:
                print("[DEBUG] Failing stats:")
                for k, v in result.items():
                    if not integrator.validator.validate_stat_value(k, v):
                        print(f"  {k}: {v} (type: {type(v)})")
            # Try full integration
            if is_valid:
                print("Integration successful!")
                print("Merged data values:")
                for stat, value in result.items():
                    print(f"  {stat}: {value}")
                for stat, value in result.items():
                    source = get_source_for_stat(stat)
                    if source:
                        print(f"  - {stat} ({source.value}): {value}")
            else:
                print("Integration failed!")
        
        # Extract player metadata
        def get_meta(key_fbref, key_understat=None):
            # Try FBref first
            val = fbref_data.get(key_fbref) if fbref_data else None
            if val is not None:
                return val
            # Try Understat
            if key_understat and understat_data:
                return understat_data.get(key_understat)
            return None

        # Prefer Understat for date_of_birth
        date_of_birth = understat_data.get('date_of_birth') if understat_data and 'date_of_birth' in understat_data else None

        player_metadata = {
            'name': get_meta('player'),
            'team': get_meta('team'),
            'position': get_meta(('pos', ''), 'position'),
            'date_of_birth': date_of_birth,
            'nationality': get_meta(('nation', ''), None)
        }
        player_metadata['stats'] = result

        save_player_data(player_metadata, conn)
        
        conn.close()
        
    except Exception as e:
        print(f"Error during testing: {str(e)}")

# Function to save player data to the database
def save_player_data(player_data, conn):
    cursor = conn.cursor()
    try:
        # Insert player
        cursor.execute("""
            INSERT INTO players (name, team, position, date_of_birth, nationality)
            VALUES (%s, %s, %s, %s, %s)
            RETURNING id
        """, (player_data['name'], player_data['team'], player_data['position'], 
              player_data['date_of_birth'], player_data['nationality']))
        player_id = cursor.fetchone()[0]
        
        # Insert stats
        for stat_name, stat_value in player_data['stats'].items():
            cursor.execute("""
                INSERT INTO player_stats (player_id, category, stat_name, stat_value)
                VALUES (%s, %s, %s, %s)
            """, (player_id, 'general', stat_name, stat_value))
        
        conn.commit()
        print("Player data saved successfully.")
    except Exception as e:
        conn.rollback()
        print(f"Error saving player data: {e}")
    finally:
        cursor.close()

if __name__ == "__main__":
    test_data_source_mappings() 