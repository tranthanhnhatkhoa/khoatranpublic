"""Test script to verify all imports work correctly."""

def test_imports():
    # Test core imports
    from soccerdata.core import _common, _config
    
    # Test data source imports
    from soccerdata.data_sources import (
        clubelo, espn, fbref, fotmob, match_history,
        sofascore, sofifa, understat, whoscored
    )
    
    # Test player imports
    from soccerdata.player import (
        player, player_factory
    )
    
    # Test database imports
    from soccerdata.database import db_config, db_handler
    
    print("All imports successful!")

if __name__ == "__main__":
    test_imports() 