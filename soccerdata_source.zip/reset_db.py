import psycopg2
from soccerdata.database.schema import DatabaseSchema

def reset_database():
    # Connect to the database
    conn = psycopg2.connect(
        dbname="soccerdata",
        user="khoatran",  # Using your system username
        password="",      # Empty password for local development
        host="localhost",
        port="5432"
    )
    
    try:
        # Create schema instance
        schema = DatabaseSchema(conn)
        
        # Drop all tables
        print("Dropping all tables...")
        schema.drop_tables()
        
        # Create tables with new schema
        print("Creating tables with new schema...")
        schema.create_tables()
        
        # Commit changes
        conn.commit()
        print("Database reset complete!")
        
    except Exception as e:
        print(f"Error resetting database: {e}")
        conn.rollback()
    finally:
        conn.close()

if __name__ == "__main__":
    reset_database() 