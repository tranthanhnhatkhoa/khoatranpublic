"""Test script for the player stats system."""

import psycopg2
from datetime import datetime
from soccerdata.database.schema import DatabaseSchema
from soccerdata.database.validator import PlayerValidator
from soccerdata.database.batch import PlayerBatch
from soccerdata.database.version import PlayerStatsVersion
from soccerdata.database.cache import PlayerCache

def test_database_connection():
    """Test database connection and table creation."""
    print("\n=== Testing Database Connection ===")
    try:
        # Connect to database
        conn = psycopg2.connect(
            dbname="soccerdata",
            user="khoatran",
            password="",
            host="localhost",
            port="5432"
        )
        print("✓ Database connection successful")
        
        # Drop and create tables for a clean schema
        schema = DatabaseSchema(conn)
        schema.drop_tables()
        print("✓ Tables dropped (clean start)")
        schema.create_tables()
        print("✓ Tables created successfully")
        
        return conn
    except Exception as e:
        print(f"✗ Database connection failed: {str(e)}")
        raise

def test_validation():
    """Test the validation system."""
    print("\n=== Testing Validation System ===")
    
    # Test valid stats
    valid_stats = {
        'goals': 5,
        'assists': 3,
        'minutes_played': 90,
        'rating': 8.5,
        'position': 'Forward',
        'yellow_cards': 1,
        'red_cards': 0,
        'passes_completed': 45,
        'pass_accuracy': 85.5
    }
    
    # Test invalid stats
    invalid_stats = {
        'goals': -1,  # Negative goals
        'minutes_played': 150,  # Too many minutes
        'rating': 11,  # Rating > 10
        'position': 'Striker',  # Invalid position
        'yellow_cards': 3  # Too many yellow cards
    }
    
    # Test validation
    print("Testing valid stats...")
    assert PlayerValidator.validate_stats(valid_stats), "Valid stats should pass validation"
    print("✓ Valid stats passed validation")
    
    print("Testing invalid stats...")
    assert not PlayerValidator.validate_stats(invalid_stats), "Invalid stats should fail validation"
    print("✓ Invalid stats caught by validation")
    
    # Test sanitization
    test_value = "  test value  "
    sanitized = PlayerValidator.sanitize_stat_value(test_value)
    assert sanitized == "test value", "String should be stripped"
    print("✓ Sanitization working correctly")

def test_batch_operations(conn):
    """Test batch operations."""
    print("\n=== Testing Batch Operations ===")
    
    # Create test player
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO players (name, team, position)
        VALUES (%s, %s, %s)
        RETURNING id
    """, ("Test Player", "Test Team", "Forward"))
    player_id = cursor.fetchone()[0]
    conn.commit()
    
    # Test batch operations
    with PlayerBatch(conn) as batch:
        # Add multiple stats
        test_stats = {
            'goals': 5,
            'assists': 3,
            'minutes_played': 90,
            'rating': 8.5
        }
        batch.add_multiple_stats(player_id, test_stats)
        print("✓ Added multiple stats in batch")
        batch.flush()  # Ensure data is written before retrieval
        # Test batch retrieval
        retrieved_stats = batch.get_stats_batch([player_id])
        print("retrieved_stats:", retrieved_stats)  # Debug print
        assert player_id in retrieved_stats, "Should retrieve stats for player"
        print("✓ Batch retrieval working")
        
        # Test batch deletion
        batch.delete_stats([player_id], ['goals', 'assists'])
        remaining_stats = batch.get_stats_batch([player_id])
        assert 'goals' not in remaining_stats[player_id], "Goals should be deleted"
        print("✓ Batch deletion working")

def test_version_control(conn):
    """Test version control system."""
    print("\n=== Testing Version Control ===")
    
    # Create test player
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO players (name, team, position)
        VALUES (%s, %s, %s)
        RETURNING id
    """, ("Version Test Player", "Test Team", "Midfielder"))
    player_id = cursor.fetchone()[0]
    conn.commit()
    
    with PlayerStatsVersion(conn) as version:
        # Create initial revision
        initial_stats = {
            'goals': 5,
            'assists': 3,
            'minutes_played': 90
        }
        rev1_id = version.create_revision(player_id, initial_stats, comment="Initial stats")
        print("✓ Created initial revision")
        
        # Create updated revision
        updated_stats = {
            'goals': 6,
            'assists': 4,
            'minutes_played': 90,
            'rating': 8.5
        }
        rev2_id = version.create_revision(player_id, updated_stats, comment="Updated stats")
        print("✓ Created updated revision")
        
        # Test revision comparison
        comparison = version.compare_revisions(rev1_id, rev2_id)
        assert 'goals' in comparison['changes']['modified'], "Should detect modified stats"
        print("✓ Revision comparison working")
        
        # Test revision restoration
        version.restore_revision(rev1_id)
        print("✓ Revision restoration working")

def test_caching(conn):
    """Test caching system."""
    print("\n=== Testing Caching System ===")
    
    cache = PlayerCache()
    
    # Test setting and getting cache
    test_data = {'goals': 5, 'assists': 3}
    cache.set('test_key', test_data)
    retrieved = cache.get('test_key')
    assert retrieved == test_data, "Cached data should match original"
    print("✓ Basic caching working")
    
    # Test cache expiration
    cache.set('expire_key', test_data, expiration=1)  # 1 second expiration
    import time
    time.sleep(2)
    expired = cache.get('expire_key')
    assert expired is None, "Cache should expire"
    print("✓ Cache expiration working")
    
    # Test player stats caching
    player_id = 1
    cache.set_player_stats(player_id, test_data)
    cached_stats = cache.get_player_stats(player_id)
    assert cached_stats == test_data, "Player stats should be cached"
    print("✓ Player stats caching working")

def cleanup(conn):
    """Clean up test data."""
    print("\n=== Cleaning Up ===")
    cursor = conn.cursor()
    cursor.execute("DELETE FROM players WHERE name LIKE 'Test%'")
    conn.commit()
    print("✓ Test data cleaned up")

def main():
    """Run all tests."""
    try:
        # Test database connection and setup
        conn = test_database_connection()
        
        # Run all tests
        test_validation()
        test_batch_operations(conn)
        test_version_control(conn)
        test_caching(conn)
        
        # Cleanup
        cleanup(conn)
        
        print("\n=== All Tests Passed Successfully! ===")
        
    except Exception as e:
        print(f"\n✗ Test failed: {str(e)}")
        raise
    finally:
        if 'conn' in locals():
            conn.close()

if __name__ == "__main__":
    main() 